"""
face_monitor.py
Watches the webcam, finds faces, recognises enrolled crew members and estimates a
rough expression signal for companion.py.  Everything stays on this computer.

Install (one time):
    pip install opencv-python numpy
    pip install mediapipe        (recommended: much better faces and expressions;
                                  the 3.6 MB face model downloads once, then works offline)

Enroll a crew member (look at the camera, move your head a little, smile once):
    python face_monitor.py enroll --name Farhan
Check it works (shows a window, press Q to quit):
    python face_monitor.py test
Forget someone:
    python face_monitor.py forget --name Farhan

How it works
  * With mediapipe: 468 face landmarks per frame.  Expression comes from geometry
    (mouth-corner lift, mouth width, lip gap, brow height, eye opening), compared with
    that person's OWN calm baseline, so a naturally serious face isn't read as "sad".
    Identity comes from a normalised landmark "shape signature" (distances between
    stable points such as eye corners, nose, chin), matched against enrolled crew.
  * Without mediapipe: OpenCV face + smile + eye detectors and an LBPH or pixel-based
    recogniser.  Works, but less accurate.

Honesty note: a facial expression is only a weak hint about how someone feels.
This module never diagnoses anything; companion.py only uses it to decide when to
offer a chat, a joke or a message from Earth.
"""

import argparse
import collections
import json
import os
import threading
import time

import numpy as np

try:
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None

try:
    import mediapipe as mp
except Exception:
    mp = None

HERE = os.path.dirname(os.path.abspath(__file__))
FACES_DIR = os.path.join(HERE, "crew_faces")

# landmark ids (MediaPipe FaceMesh)
L_EYE_OUT, L_EYE_IN, R_EYE_IN, R_EYE_OUT = 33, 133, 362, 263
L_EYE_TOP, L_EYE_BOT, R_EYE_TOP, R_EYE_BOT = 159, 145, 386, 374
MOUTH_L, MOUTH_R, LIP_TOP, LIP_BOT = 61, 291, 13, 14
L_BROW, R_BROW = 105, 334
NOSE, CHIN, FOREHEAD = 1, 152, 10
SIG_POINTS = [33, 133, 362, 263, 1, 4, 61, 291, 152, 10, 234, 454, 105, 334, 168, 6, 197, 2, 98, 327]


def _dist(a, b):
    return float(np.linalg.norm(np.asarray(a) - np.asarray(b)))


class _Expression:
    """Turns landmarks into raw features, then into positive/negative scores vs a baseline."""

    def __init__(self, baseline_frames=40):
        self.base = None
        self.buf = []
        self.n = baseline_frames

    @staticmethod
    def features(p):
        iod = _dist(p[L_EYE_OUT], p[R_EYE_OUT]) + 1e-6
        mouth_w = _dist(p[MOUTH_L], p[MOUTH_R]) / iod
        lip_mid_y = (p[LIP_TOP][1] + p[LIP_BOT][1]) / 2
        corner_lift = (lip_mid_y - (p[MOUTH_L][1] + p[MOUTH_R][1]) / 2) / iod   # + = corners up (smile)
        lip_gap = _dist(p[LIP_TOP], p[LIP_BOT]) / iod
        eye_open = (_dist(p[L_EYE_TOP], p[L_EYE_BOT]) + _dist(p[R_EYE_TOP], p[R_EYE_BOT])) / (2 * iod)
        brow = ((p[L_EYE_TOP][1] - p[L_BROW][1]) + (p[R_EYE_TOP][1] - p[R_BROW][1])) / (2 * iod)
        head_down = (p[NOSE][1] - (p[L_EYE_OUT][1] + p[R_EYE_OUT][1]) / 2) / iod
        return np.array([mouth_w, corner_lift, lip_gap, eye_open, brow, head_down])

    def score(self, f):
        if self.base is None:
            self.buf.append(f)
            if len(self.buf) >= self.n:
                arr = np.array(self.buf)
                self.base = (np.median(arr, 0), arr.std(0) + 1e-3)
            mu, sd = np.median(np.array(self.buf), 0), np.array([0.04, 0.02, 0.03, 0.02, 0.03, 0.05])
        else:
            mu, sd = self.base
            # slowly adapt so lighting / posture drift doesn't stick
            self.base = (mu * 0.998 + f * 0.002, sd)
        z = (f - mu) / np.maximum(sd, [0.02, 0.01, 0.015, 0.01, 0.015, 0.03])
        smile = max(0.0, z[1]) * 0.6 + max(0.0, z[0]) * 0.4
        frown = max(0.0, -z[1]) * 0.5
        brow_down = max(0.0, -z[4]) * 0.35
        droopy = max(0.0, -z[3]) * 0.25
        head_low = max(0.0, z[5]) * 0.2
        positive = 1 - np.exp(-smile / 2.2)
        negative = 1 - np.exp(-(frown + brow_down + droopy + head_low) / 2.4)
        if positive > 0.5:                 # a real smile outweighs a lowered brow
            negative *= 0.4
        return float(np.clip(positive, 0, 1)), float(np.clip(negative, 0, 1))


class _Identity:
    """Enrolled crew members and matching."""

    def __init__(self, folder=FACES_DIR):
        self.folder = folder
        self.people = {}       # name -> {"sig": np.array [k, d] or None, "img": np.array [k, 64*64] or None}
        self.lbph = None
        self.load()

    def load(self):
        self.people = {}
        if not os.path.isdir(self.folder):
            return
        for fn in os.listdir(self.folder):
            if fn.endswith(".npz"):
                d = np.load(os.path.join(self.folder, fn))
                self.people[fn[:-4]] = {"sig": d["sig"] if "sig" in d and d["sig"].size else None,
                                        "img": d["img"] if "img" in d and d["img"].size else None}
        self._train_lbph()

    def _train_lbph(self):
        self.lbph = None
        if cv2 is None or not hasattr(cv2, "face"):
            return
        imgs, labels, self.lbph_names = [], [], []
        for i, (n, d) in enumerate(self.people.items()):
            self.lbph_names.append(n)
            if d["img"] is not None:
                for v in d["img"]:
                    imgs.append(v.reshape(64, 64).astype(np.uint8)); labels.append(i)
        if imgs:
            self.lbph = cv2.face.LBPHFaceRecognizer_create()
            self.lbph.train(imgs, np.array(labels))

    def save(self, name, sigs, imgs):
        os.makedirs(self.folder, exist_ok=True)
        safe = "".join(c for c in name if c.isalnum() or c in "-_ ").strip() or "crew"
        np.savez(os.path.join(self.folder, safe + ".npz"),
                 sig=np.array(sigs, dtype=np.float32), img=np.array(imgs, dtype=np.uint8))
        self.load()
        return safe

    def forget(self, name):
        p = os.path.join(self.folder, name + ".npz")
        if os.path.exists(p):
            os.remove(p)
        self.load()

    @staticmethod
    def signature(p):
        pts = np.array([p[i][:2] for i in SIG_POINTS], dtype=np.float64)
        iod = _dist(p[L_EYE_OUT], p[R_EYE_OUT]) + 1e-6
        d = [np.linalg.norm(pts[i] - pts[j]) / iod for i in range(len(pts)) for j in range(i + 1, len(pts))]
        v = np.array(d)
        return (v - v.mean()) / (v.std() + 1e-6)

    @staticmethod
    def crop(gray, box):
        x, y, w, h = box
        c = gray[max(0, y):y + h, max(0, x):x + w]
        if c.size == 0:
            return None
        c = cv2.resize(c, (64, 64))
        return cv2.equalizeHist(c)

    def match(self, sig=None, img=None):
        if not self.people:
            return "unknown", 0.0
        if sig is not None and any(d["sig"] is not None for d in self.people.values()):
            best, bd = "unknown", 1e9
            for n, d in self.people.items():
                if d["sig"] is None:
                    continue
                dist = float(np.min(np.linalg.norm(d["sig"] - sig, axis=1)) / np.sqrt(sig.size))
                if dist < bd:
                    best, bd = n, dist
            conf = float(np.clip(1 - bd / 0.55, 0, 1))
            return (best if bd < 0.38 else "unknown"), conf
        if img is not None:
            if self.lbph is not None:
                label, dist = self.lbph.predict(img)
                return (self.lbph_names[label] if dist < 70 else "unknown"), float(np.clip(1 - dist / 120, 0, 1))
            v = img.astype(np.float32).ravel(); v = (v - v.mean()) / (v.std() + 1e-6)
            best, bs = "unknown", -1
            for n, d in self.people.items():
                if d["img"] is None:
                    continue
                m = d["img"].astype(np.float32); m = (m - m.mean(1, keepdims=True)) / (m.std(1, keepdims=True) + 1e-6)
                s = float(np.max(m @ v) / v.size)
                if s > bs:
                    best, bs = n, s
            return (best if bs > 0.62 else "unknown"), float(np.clip(bs, 0, 1))
        return "unknown", 0.0


CASCADE_URL = "https://raw.githubusercontent.com/opencv/opencv/4.x/data/haarcascades/"


def _cascade(fname):
    """OpenCV's bundled detector if present, else a local copy, else download it once (OpenCV 5 dropped them)."""
    base = getattr(getattr(cv2, "data", None), "haarcascades", "")
    for path in (os.path.join(base, fname) if base else "", os.path.join(FACES_DIR, fname)):
        if path and os.path.exists(path):
            c = cv2.CascadeClassifier(path)
            if not c.empty():
                return c
    try:
        import urllib.request
        os.makedirs(FACES_DIR, exist_ok=True)
        dst = os.path.join(FACES_DIR, fname)
        urllib.request.urlretrieve(CASCADE_URL + fname, dst + ".part")
        os.replace(dst + ".part", dst)
        return cv2.CascadeClassifier(dst)
    except Exception:
        return cv2.CascadeClassifier()


MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"


def _landmarker_model():
    """Downloads the 3.6 MB face model once (to crew_faces/), then reuses it offline."""
    os.makedirs(FACES_DIR, exist_ok=True)
    path = os.path.join(FACES_DIR, "face_landmarker.task")
    if not os.path.exists(path) or os.path.getsize(path) < 100000:
        import urllib.request
        print("[face] downloading the face model once (3.6 MB)...")
        urllib.request.urlretrieve(MODEL_URL, path + ".part")
        os.replace(path + ".part", path)
    return path


class FaceMonitor:
    """Background webcam watcher.  Call get_status() any time (thread-safe)."""

    def __init__(self, camera_index=0, window_seconds=20, fps=8, show=False):
        self.camera_index = camera_index
        self.window = window_seconds
        self.fps = fps
        self.show = show
        self.ident = _Identity()
        self.expr = {}                     # name -> _Expression (per-person baseline)
        self.hist = collections.defaultdict(collections.deque)
        self.status = {"timestamp": time.time(), "camera_ok": False, "privacy_mode": False,
                       "faces": [], "error": None, "mood": {}, "engine": "starting"}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._privacy = False
        self._thread = None
        self._mesh = None
        self._tasks = None
        self._haar = None

    # ---- public ------------------------------------------------------------
    def start(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)

    def set_privacy(self, on):
        self._privacy = bool(on)
        with self._lock:
            self.status["privacy_mode"] = self._privacy
            if on:
                self.status["faces"], self.status["mood"] = [], {}
                self.hist.clear()

    def get_status(self):
        with self._lock:
            return json.loads(json.dumps(self.status))

    # ---- engine ------------------------------------------------------------
    def _setup(self):
        self._mesh = self._tasks = None
        if mp is not None:
            try:  # mediapipe <= 0.10.14 style
                self._mesh = mp.solutions.face_mesh.FaceMesh(max_num_faces=4, refine_landmarks=True,
                                                             min_detection_confidence=0.5, min_tracking_confidence=0.5)
                return
            except Exception:
                pass
            try:  # newer mediapipe: FaceLandmarker task (adds expression "blendshape" scores)
                from mediapipe.tasks import python as mpt
                from mediapipe.tasks.python import vision
                model = _landmarker_model()
                opts = vision.FaceLandmarkerOptions(base_options=mpt.BaseOptions(model_asset_path=model), num_faces=4,
                                                    output_face_blendshapes=True, running_mode=vision.RunningMode.IMAGE)
                self._tasks = vision.FaceLandmarker.create_from_options(opts)
                return
            except Exception as exc:
                print("[face] mediapipe could not start (%s); using OpenCV detectors." % exc)
        if True:
            self._haar = {"face": _cascade("haarcascade_frontalface_default.xml"),
                          "smile": _cascade("haarcascade_smile.xml"),
                          "eye": _cascade("haarcascade_eye.xml")}
            if self._haar["face"].empty():
                raise RuntimeError("OpenCV face detector files are missing and could not be downloaded. "
                                   "Fix: pip install mediapipe")

    def analyse(self, frame):
        """Returns a list of faces: {box, name, confidence, positive, negative, sig, crop}."""
        h, w = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        out = []
        if self._mesh is not None or self._tasks is not None:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if self._mesh is not None:
                res = self._mesh.process(rgb)
                found = [([(q.x * w, q.y * h, q.z * w) for q in lm.landmark], None) for lm in (res.multi_face_landmarks or [])]
            else:
                res = self._tasks.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))
                found = []
                for i, lm in enumerate(res.face_landmarks or []):
                    bs = {c.category_name: c.score for c in res.face_blendshapes[i]} if res.face_blendshapes else None
                    found.append(([(q.x * w, q.y * h, q.z * w) for q in lm], bs))
            for p, bs in found:
                xs, ys = [a[0] for a in p], [a[1] for a in p]
                box = (int(min(xs)), int(min(ys)), int(max(xs) - min(xs)), int(max(ys) - min(ys)))
                sig = _Identity.signature(p)
                crop = _Identity.crop(gray, box)
                name, conf = self.ident.match(sig=sig, img=crop)
                f = _Expression.features(p)
                ex = self.expr.setdefault(name, _Expression())
                pos, neg = ex.score(f)
                if bs:  # blendshapes are a stronger signal; blend them with the geometry, relative to this person's baseline
                    bpos = (bs.get("mouthSmileLeft", 0) + bs.get("mouthSmileRight", 0)) / 2
                    bneg = 0.45 * (bs.get("mouthFrownLeft", 0) + bs.get("mouthFrownRight", 0)) / 2 \
                        + 0.35 * (bs.get("browDownLeft", 0) + bs.get("browDownRight", 0)) / 2 \
                        + 0.35 * bs.get("browInnerUp", 0) + 0.15 * (bs.get("mouthPressLeft", 0) + bs.get("mouthPressRight", 0)) / 2
                    b0 = ex.__dict__.setdefault("bs_base", [])
                    if len(b0) < 40:
                        b0.append((bpos, bneg))
                    m0 = np.median(np.array(b0), 0)
                    bpos = float(np.clip((bpos - m0[0] * 0.7) * 1.6, 0, 1)); bneg = float(np.clip((bneg - m0[1] * 0.8) * 2.2, 0, 1))
                    pos, neg = 0.65 * bpos + 0.35 * pos, 0.6 * bneg + 0.4 * neg
                    if pos > 0.5:
                        neg *= 0.4
                out.append({"box": box, "name": name, "confidence": round(conf, 2), "positive": pos,
                            "negative": neg, "sig": sig, "crop": crop})
        else:
            faces = self._haar["face"].detectMultiScale(cv2.equalizeHist(gray), 1.15, 6, minSize=(80, 80))
            for (x, y, fw, fh) in faces:
                roi = gray[y:y + fh, x:x + fw]
                lower = roi[fh // 2:, :]
                smiles = self._haar["smile"].detectMultiScale(lower, 1.7, 22, minSize=(fw // 4, fh // 10))
                eyes = self._haar["eye"].detectMultiScale(roi[: fh // 2, :], 1.1, 8)
                crop = _Identity.crop(gray, (x, y, fw, fh))
                name, conf = self.ident.match(img=crop)
                pos = 0.8 if len(smiles) else 0.05
                neg = 0.15 + (0.25 if len(eyes) < 2 else 0.0) if not len(smiles) else 0.05
                out.append({"box": (int(x), int(y), int(fw), int(fh)), "name": name, "confidence": round(conf, 2),
                            "positive": pos, "negative": neg, "sig": None, "crop": crop})
        return out

    def _run(self):
        if cv2 is None:
            with self._lock:
                self.status["error"] = "opencv-python is not installed (pip install opencv-python)"
            return
        try:
            self._setup()
            with self._lock:
                self.status["engine"] = "mediapipe" if (self._mesh or self._tasks) else "opencv"
        except Exception as exc:
            with self._lock:
                self.status["error"] = "face engine failed: %s" % exc
            return
        cap = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW) if os.name == "nt" else cv2.VideoCapture(self.camera_index)
        if not cap or not cap.isOpened():
            with self._lock:
                self.status["error"] = "camera %s could not be opened" % self.camera_index
            return
        period = 1.0 / self.fps
        try:
            while not self._stop.is_set():
                t0 = time.time()
                if self._privacy:
                    time.sleep(0.3)
                    continue
                ok, frame = cap.read()
                if not ok:
                    with self._lock:
                        self.status["camera_ok"] = False
                    time.sleep(0.5)
                    continue
                faces = self.analyse(frame)
                now = time.time()
                for f in faces:
                    dq = self.hist[f["name"]]
                    dq.append((now, f["positive"], f["negative"]))
                    while dq and now - dq[0][0] > self.window:
                        dq.popleft()
                mood = {}
                for name, dq in self.hist.items():
                    while dq and now - dq[0][0] > self.window:
                        dq.popleft()
                    if not dq:
                        continue
                    pos = float(np.mean([d[1] for d in dq])); neg = float(np.mean([d[2] for d in dq]))
                    mood[name] = {"negative_score": round(neg, 3), "positive_score": round(pos, 3),
                                  "samples": len(dq), "low_mood_signal": neg >= 0.45}
                with self._lock:
                    self.status.update(timestamp=now, camera_ok=True, error=None, mood=mood,
                                       faces=[{"name": f["name"], "confidence": f["confidence"], "box": list(f["box"]),
                                               "positive": round(f["positive"], 2), "negative": round(f["negative"], 2)}
                                              for f in faces])
                if self.show:
                    for f in faces:
                        x, y, w, h = f["box"]
                        col = (80, 220, 120) if f["positive"] > 0.5 else ((80, 120, 255) if f["negative"] > 0.45 else (255, 200, 80))
                        cv2.rectangle(frame, (x, y), (x + w, y + h), col, 2)
                        cv2.putText(frame, "%s  +%.2f -%.2f" % (f["name"], f["positive"], f["negative"]),
                                    (x, max(20, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, col, 2)
                    cv2.imshow("face_monitor (Q to quit)", frame)
                    if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q")):
                        self._stop.set()
                time.sleep(max(0.0, period - (time.time() - t0)))
        finally:
            cap.release()
            if self.show:
                cv2.destroyAllWindows()


def enroll(name, camera_index=0, shots=40):
    mon = FaceMonitor(camera_index)
    mon._setup()
    cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW) if os.name == "nt" else cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print("Camera could not be opened.")
        return
    sigs, imgs = [], []
    print("Look at the camera. Turn your head a little left and right, and smile once. Capturing...")
    t_end = time.time() + 40
    while len(imgs) < shots and time.time() < t_end:
        ok, frame = cap.read()
        if not ok:
            continue
        faces = mon.analyse(frame)
        if len(faces) == 1:
            f = faces[0]
            if f["crop"] is not None:
                imgs.append(f["crop"].ravel())
            if f["sig"] is not None:
                sigs.append(f["sig"])
            x, y, w, h = f["box"]
            cv2.rectangle(frame, (x, y), (x + w, y + h), (80, 220, 120), 2)
        cv2.putText(frame, "Enrolling %s: %d/%d" % (name, len(imgs), shots), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (80, 220, 120), 2)
        cv2.imshow("enroll", frame)
        if cv2.waitKey(120) & 0xFF in (ord("q"), ord("Q")):
            break
    cap.release()
    cv2.destroyAllWindows()
    if len(imgs) < 10:
        print("Not enough clear shots (only one face should be in view). Try again with better light.")
        return
    saved = mon.ident.save(name, sigs, imgs)
    print("Enrolled %s with %d samples (%s engine)." % (saved, len(imgs), "mediapipe" if mp else "opencv"))


def main():
    ap = argparse.ArgumentParser(description="Webcam face + expression monitor")
    ap.add_argument("cmd", nargs="?", default="test", choices=["test", "enroll", "forget", "list"])
    ap.add_argument("--name")
    ap.add_argument("--camera", type=int, default=0)
    a = ap.parse_args()
    if cv2 is None:
        print("Install OpenCV first: pip install opencv-python numpy")
        return
    if a.cmd == "enroll":
        if not a.name:
            print("Use: python face_monitor.py enroll --name YourName")
            return
        enroll(a.name, a.camera)
    elif a.cmd == "forget":
        _Identity().forget(a.name or "")
        print("Forgotten.")
    elif a.cmd == "list":
        print(", ".join(_Identity().people) or "Nobody enrolled yet.")
    else:
        print("Engine:", "mediapipe (best)" if mp else "opencv (install mediapipe for better results)")
        m = FaceMonitor(a.camera, show=True)
        m.start()
        try:
            while m._thread.is_alive():
                time.sleep(2)
                s = m.get_status()
                if s.get("error"):
                    print("Error:", s["error"]); break
                print({k: (v["positive_score"], v["negative_score"]) for k, v in s["mood"].items()})
        except KeyboardInterrupt:
            pass
        m.stop()


if __name__ == "__main__":
    main()
