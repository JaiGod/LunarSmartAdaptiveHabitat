"""
companion.py
AI companion for the lunar habitat project. It reacts to the crew member's mood
(read by face_monitor.py) and talks with them.

What it does
  - Looks sad or low  -> tells a joke OR relays a message from someone back on Earth
                         (it alternates), then invites them to talk.
  - Looks happy       -> starts a friendly conversation.
  - Any other time    -> still starts a conversation every so often, and you can
                         type to it whenever you want.
  - Repeated low mood -> ASKS permission to alert the mission psychologist.
  - Crisis words      -> immediately alerts a human and shares emergency info.

Install (one time):
    pip install opencv-python numpy mediapipe pyserial anthropic pyttsx3
    (mediapipe = much better face + expression reading; optional.)
    Teach it your face (optional, lets it greet you by name):
    python face_monitor.py enroll --name Farhan
    (anthropic = real AI conversation, pyttsx3 = spoken voice, pyserial = Arduino.
     All three are optional. Without anthropic it uses simple built-in replies.
     Without pyttsx3 it uses your computer's built-in voice instead.)

AI conversation (optional but recommended):
    Windows:  setx ANTHROPIC_API_KEY "your-key"   (then reopen the terminal)
    Mac/Linux: export ANTHROPIC_API_KEY="your-key"
    Optional: set COMPANION_MODEL to change the model (default claude-sonnet-5-5).

Run it:
    python companion.py add-message --from "Mom" --text "Proud of you. Dinner is waiting."
    python companion.py                 # camera + companion
    python companion.py --no-camera     # practice mode: type /mood low, /mood happy, ...
    python companion.py --demo          # short timers so you can show judges quickly
    python companion.py --serial COM3 --camera 0
    python companion.py speak-test      # check you can hear it first
    python companion.py --mute          # silent, text only

The voice is ON by default: every line the companion says is spoken out loud.

While it runs, type to talk to it. Commands:
    /mood low|happy|neutral   (practice mode only)    /joke    /earth
    /mute  voice off or on    /privacy  camera off or on    /quit

Use inside your main application:
    from face_monitor import FaceMonitor
    from companion import Companion

    def say(text):   print("Companion:", text)           # or show it in your app / speak it
    def alert(name, reason): print("ALERT", name, reason)  # notify the mission psychologist

    comp = Companion(say=say, escalate=alert)
    monitor = FaceMonitor(window_seconds=20)
    monitor.start()
    # every ~2 seconds:
    comp.tick(monitor.get_status())
    # whenever the crew member types or speaks:
    reply = comp.chat("Farhan", "I miss home")

Privacy and honesty notes (put these in your write-up)
  - Camera frames never leave this computer and are never saved.
  - With the AI conversation on, the TYPED TEXT and the mood label (not images) go to
    the Anthropic API. Use --offline to keep everything on this computer.
  - A facial expression is only a weak hint about how someone feels. The companion
    offers and asks. It never tells someone how they feel and never diagnoses.
  - It supports the crew and does not replace a human psychologist.
"""

import argparse
import json
import os
import queue
import random
import re
import shutil
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
EARTH_FILE = os.path.join(HERE, "earth_messages.json")
LOG_FILE = os.path.join(HERE, "companion_log.jsonl")
ESCALATION_FILE = os.path.join(HERE, "escalations.txt")

JOKES = [
    # space + science, written to land out loud (short setup, clean punchline)
    "I tried to start a band on the Moon. Great acoustics in the habitat, but the crowd outside? No atmosphere.",
    "Why did the astronaut break up with the Moon? It kept going through phases.",
    "I asked mission control for a joke about gravity. They said I wouldn't take it lightly. Up here, I take everything lightly.",
    "What's an astronaut's favourite key on the keyboard? The space bar. Mine's the escape key, but they disabled it.",
    "How do you organise a party on the Moon? You planet. Then you realise nobody can come because it's a 3-day trip.",
    "The Sun skipped college. Said it already had millions of degrees.",
    "Why don't astronauts tell secrets in space? Too many satellites listening.",
    "I'd tell you a joke about the vacuum outside, but it sucks.",
    "Why is the Moon so broke? It spends its last quarter every month.",
    "Saturn has a ring, Jupiter has a red spot, and I have a coffee stain on my flight suit. We all have our features.",
    "Why did the photon skip airport security? It was travelling light.",
    "What do you call a tick on the Moon? A luna-tick. Don't worry, the airlock filters them out.",
    "Mars and Venus walk into a bar. The bartender says: sorry, we only serve full Moons on Fridays.",
    "Why did the astronaut bring a ladder to the Moon? Heard the prices of real estate were sky high.",
    "I'm reading a book about anti-gravity. I can't put it down. Up here that's literally true, it just floats.",
    "Why did the cow go to the space station? To see the Moooon up close.",
    "An astronaut walks into the habitat cafe. 'One ice cream, please.' 'Sure, what flavour?' 'Freeze-dried, obviously.'",
    "Why can't you trust atoms? They make up everything. Including this habitat.",
    "What did the Moon say to the Sun? You're so bright, but you never let me finish my sentences at night.",
    "Black holes are like my sock drawer. Things go in. Nothing comes out.",
    "Why did the rover get a promotion? It was outstanding in its field.",
    "How does the solar system hold up its trousers? With an asteroid belt.",
    "My plants in the greenhouse started telling jokes. Mostly corny ones.",
    "What do you call an alien with three eyes? An aliiien.",
    "Knock knock. Who's there? Orbit. Orbit who? Orbit-ter open the airlock, it's cold out here.",
    "Why did the comet get kicked out of class? Too much showing off its tail.",
    "I told the habitat AI a chemistry joke. No reaction. Then I realised it was a noble gas joke.",
    "Why did the astronaut nap on the job? Gravity was low, and so was the motivation. Kidding, the mission is going great.",
    "The ISS has a great view of Earth. The Moon base has a great view of Earth too, it's just a little more long distance.",
    "Why does the Moon never feel lonely? It's always surrounded by stars, and it's got us now.",
    "How do astronauts keep their dinner warm? A heat shield. Also a microwave, but that's less dramatic.",
    "What's the Moon's favourite TV show? Earth's Got Talent.",
    "Neil Armstrong took one small step. I took one small step into the greenhouse and stepped on a tomato.",
    "Why did the satellite go to therapy? It had trouble letting go of old orbits.",
    "Space jokes are the best. They're out of this world, but they never land.",
]

class _Deck:
    """Hands out items in random order without repeating until the deck is used up."""

    def __init__(self, items):
        self.items, self.pile = list(items), []

    def draw(self):
        if not self.pile:
            self.pile = self.items[:]
            random.shuffle(self.pile)
        return self.pile.pop()


_JOKE_DECK = _Deck(JOKES)


def next_joke():
    return _JOKE_DECK.draw()


HAPPY_OPENERS = [
    "You're glowing today. What's been the best part of your day so far?",
    "That smile is contagious. What's got you in a good mood?",
    "You look happy. If you could beam one thing up from Earth right now, what would it be?",
    "Good energy in here today. Want to play two truths and a lie? You go first.",
    "You seem in a great mood. What's something you're looking forward to?",
]

AMBIENT_OPENERS = [
    "Hey, how's your day going so far?",
    "Quick check-in: have you eaten and had some water recently?",
    "Random question: what food from home would you bring up here if you could?",
    "What's one thing you want to get done today?",
    "Want a fun space fact, or would you rather just chat?",
]

CRISIS = re.compile(
    r"\b(kill myself|suicid\w*|want to die|end it all|hurt myself|self[- ]?harm|"
    r"no reason to live|don'?t want to be here)\b",
    re.IGNORECASE,
)


# ----------------------------------------------------------------------------
# Messages from Earth
# ----------------------------------------------------------------------------
class EarthMessages:
    """Messages from family and friends, delivered one at a time (never all at once)."""

    def __init__(self, path=EARTH_FILE):
        self.path = path
        self.items = []
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    self.items = json.load(f)
            except (OSError, ValueError):
                self.items = []

    def _save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=2)

    def add(self, sender, text):
        self.items.append({"from": sender, "text": text, "delivered_at": None})
        self._save()

    def next(self):
        """Oldest unread message first. If all were read, repeat a random one. None if empty."""
        if not self.items:
            return None
        unread = [m for m in self.items if not m.get("delivered_at")]
        if unread:
            msg = unread[0]
            msg["delivered_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            self._save()
            return msg
        return random.choice(self.items)


# ----------------------------------------------------------------------------
# AI conversation (optional) and offline fallback
# ----------------------------------------------------------------------------
class LLM:
    def __init__(self, enabled=True):
        self.client = None
        self.model = os.environ.get("COMPANION_MODEL", "claude-sonnet-5-5")
        if not enabled:
            return
        if not os.environ.get("ANTHROPIC_API_KEY"):
            print("[companion] No ANTHROPIC_API_KEY set, using simple offline replies.")
            return
        try:
            import anthropic
            self.client = anthropic.Anthropic()
        except ImportError:
            print("[companion] 'anthropic' is not installed (pip install anthropic). Using offline replies.")

    @staticmethod
    def _normalize(history):
        """API wants the first message from the user and merges same-role neighbors."""
        out = []
        for m in history:
            if out and out[-1]["role"] == m["role"]:
                out[-1]["content"] += "\n" + m["content"]
            else:
                out.append({"role": m["role"], "content": m["content"]})
        if not out or out[0]["role"] != "user":
            out.insert(0, {"role": "user", "content": "(a crew member is nearby)"})
        return out

    def reply(self, system, history, max_tokens=200):
        if self.client is None:
            return None
        try:
            r = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=self._normalize(history),
            )
            return r.content[0].text.strip()
        except Exception as exc:  # network, key, or model problems must never crash the app
            print("[companion] AI error (using offline reply):", exc)
            return None


def offline_reply(text, mood):
    t = text.lower()
    if "joke" in t:
        return next_joke()
    if re.search(r"\b(tired|sleep|exhausted|insomnia)\b", t):
        return "Rest matters a lot up here. How many hours did you get last night?"
    if re.search(r"\b(miss|home|family|mom|dad|friend|earth)\b", t):
        return "Missing home makes sense. Who's the first person you'd call if the line were open right now?"
    if re.search(r"\b(sad|down|lonely|stressed|anxious|worried|bad|upset)\b", t):
        return "I'm sorry it feels heavy right now. Want to talk it through, hear a joke, or get a message from Earth?"
    if re.search(r"\b(great|good|happy|awesome|excited|fun|amazing)\b", t):
        return "Love that. Tell me more about what made it good."
    if mood == "low":
        return "I'm listening. Take your time."
    return random.choice([
        "Tell me more about that.",
        "That's interesting. What do you think about it?",
        "I'm all ears. What else is on your mind?",
    ])


# ----------------------------------------------------------------------------
# The companion
# ----------------------------------------------------------------------------
class Companion:
    def __init__(
        self,
        say,                      # function(text): show or speak a line
        escalate=None,            # function(name, reason): alert a human
        console_ping=None,        # function(): e.g. make the Arduino check-in console prompt
        llm=None,
        earth=None,
        companion_name="Luna",
        low_cooldown=600,         # seconds between support moments for a low mood
        happy_cooldown=300,       # seconds between happy-mood chats
        ambient_interval=1200,    # seconds between "just chatting" openers
        stable_seconds=8,         # a mood must hold this long before the companion acts
        low_level=0.45,           # negative-expression share that counts as low
        happy_level=0.35,         # happiness share that counts as happy
        min_samples=10,
        log=False,                # save a local log (off by default for privacy)
    ):
        self.say = say
        self.escalate_cb = escalate
        self.console_ping = console_ping
        self.llm = llm or LLM(enabled=False)
        self.earth = earth or EarthMessages()
        self.cname = companion_name
        self.low_cooldown = low_cooldown
        self.happy_cooldown = happy_cooldown
        self.ambient_interval = ambient_interval
        self.stable_seconds = stable_seconds
        self.low_level = low_level
        self.happy_level = happy_level
        self.min_samples = min_samples
        self.log = log
        self.people = {}
        self._lock = threading.Lock()

    # ---- bookkeeping ------------------------------------------------------
    def _p(self, name, now=None):
        now = now if now is not None else time.time()
        if name not in self.people:
            self.people[name] = {
                "cand": None, "cand_since": now, "mood": None,
                "last_low": float("-inf"), "last_happy": float("-inf"), "last_ambient": now,
                "low_times": [], "toggle": 0, "history": [], "ask_escalate": False,
            }
        return self.people[name]

    @staticmethod
    def _greet(name):
        return "Hey" if name in (None, "", "unknown") else "Hey %s" % name

    def _remember(self, p, role, text):
        p["history"].append({"role": role, "content": text})
        del p["history"][:-12]

    def _speak(self, name, p, text):
        self.say(text)
        self._remember(p, "assistant", text)
        self._log(name, "companion", text)

    def _log(self, name, kind, text):
        if not self.log:
            return
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps({"t": time.strftime("%Y-%m-%d %H:%M:%S"),
                                    "name": name, "kind": kind, "text": text}) + "\n")
        except OSError:
            pass

    def escalate(self, name, reason):
        line = "%s | %s | %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), name, reason)
        try:
            with open(ESCALATION_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass
        if self.escalate_cb:
            self.escalate_cb(name, reason)

    # ---- mood -> action ---------------------------------------------------
    def classify(self, info):
        if not info or info.get("samples", 0) < self.min_samples:
            return None
        if info["negative_score"] >= self.low_level:
            return "low"
        if info["positive_score"] >= self.happy_level:
            return "happy"
        return "neutral"

    def tick(self, status, now=None):
        """Call every ~2 seconds with FaceMonitor.get_status()."""
        now = now if now is not None else time.time()
        if status.get("privacy_mode") or status.get("error"):
            return
        with self._lock:
            for name, info in status.get("mood", {}).items():
                p = self._p(name, now)
                label = self.classify(info)
                p["mood"] = label
                if label != p["cand"]:
                    p["cand"], p["cand_since"] = label, now
                    continue
                if label is None or now - p["cand_since"] < self.stable_seconds:
                    continue
                if label == "low" and now - p["last_low"] >= self.low_cooldown:
                    self._support_low(name, p, now)
                elif label == "happy" and now - p["last_happy"] >= self.happy_cooldown:
                    self._chat_happy(name, p, now)
                elif now - p["last_ambient"] >= self.ambient_interval:
                    self._ambient(name, p, now)

    def _support_low(self, name, p, now):
        p["last_low"] = p["last_ambient"] = now
        p["low_times"] = [t for t in p["low_times"] if now - t < 3600] + [now]
        want_earth = p["toggle"] % 2 == 0
        p["toggle"] += 1
        msg = self.earth.next() if want_earth else None
        if msg:
            body = 'A message from %s: "%s"' % (msg["from"], msg["text"])
            self._log(name, "earth_message", msg["from"])
        else:
            body = next_joke()
        self._speak(name, p, "%s, just checking in on you. %s" % (self._greet(name), body))
        self._speak(name, p, "I'm here if you want to talk. What's on your mind?")
        if self.console_ping:
            self.console_ping()
        if len(p["low_times"]) >= 3 and not p["ask_escalate"]:
            p["ask_escalate"] = True
            self._speak(name, p,
                        "I've noticed you've seemed down a few times lately. Would you like me to "
                        "let the mission psychologist know so they can check in? Say yes or no.")

    def _chat_happy(self, name, p, now):
        p["last_happy"] = p["last_ambient"] = now
        opener = self._opener(name, p, "happy", HAPPY_OPENERS)
        self._speak(name, p, "%s! %s" % (self._greet(name), opener))

    def _ambient(self, name, p, now):
        p["last_ambient"] = now
        opener = self._opener(name, p, "neutral", AMBIENT_OPENERS)
        self._speak(name, p, opener)

    def _opener(self, name, p, mood, fallback_list):
        if self.llm.client is not None:
            prompt = ("Start a short, friendly conversation with the crew member. They look %s right now. "
                      "One or two sentences, end with a question. Do not mention cameras or expressions." % mood)
            text = self.llm.reply(self._system(name, mood), p["history"] + [{"role": "user", "content": prompt}], 120)
            if text:
                return text
        return random.choice(fallback_list)

    # ---- conversation -----------------------------------------------------
    def _system(self, name, mood):
        who = "a crew member" if name in (None, "", "unknown") else name
        return (
            "You are %s, a friendly AI companion for astronauts living in a lunar habitat. "
            "(This is a high school NASA HUNCH design project.) Talk like a warm, funny friend. "
            "Keep replies to one to three short sentences and usually end with a gentle question "
            "so the conversation keeps going. You are talking with %s. A camera's expression reading "
            "says they look: %s. That is only a weak hint, so never tell them how they feel; ask "
            "instead. If they look low, be gentle, offer comfort, a joke, or a message from Earth, "
            "and do not push. If they look happy, match their energy and be playful: ask about their "
            "day, hobbies, favorite Earth memories. You are not a therapist and never diagnose. If "
            "someone sounds hopeless or mentions hurting themselves, urge them to talk to the mission "
            "psychologist or another real person right away. Do not claim abilities you lack. "
            "No emojis." % (self.cname, who, mood or "unknown")
        )

    def chat(self, name, text):
        with self._lock:
            p = self._p(name)
            self._log(name, "crew", text)
            if CRISIS.search(text):
                return self._crisis(name, p)
            if p["ask_escalate"]:
                t = text.strip().lower()
                if re.match(r"(yes|yeah|yep|sure|ok|okay|please)\b", t):
                    p["ask_escalate"] = False
                    self.escalate(name, "crew agreed to notify the mission psychologist (repeated low mood)")
                    reply = "Okay, I've let them know. Reaching out was a good move. I'm still here."
                    self._remember(p, "user", text)
                    self._remember(p, "assistant", reply)
                    return reply
                if re.match(r"(no|nah|nope|not now)\b", t):
                    p["ask_escalate"] = False
                    reply = "That's okay. The offer stands whenever you want it. What would help right now?"
                    self._remember(p, "user", text)
                    self._remember(p, "assistant", reply)
                    return reply
            self._remember(p, "user", text)
            if re.match(r"/?joke\b", text.strip().lower()):
                reply = next_joke()
            else:
                reply = self.llm.reply(self._system(name, p["mood"]), p["history"]) \
                    or offline_reply(text, p["mood"])
            self._remember(p, "assistant", reply)
            self._log(name, "companion", reply)
            return reply

    def _crisis(self, name, p):
        self.escalate(name, "CRISIS language detected in conversation. A human should check in now.")
        reply = ("I'm really glad you told me, and I'm taking it seriously. I'm alerting the mission "
                 "psychologist right now so a real person reaches out. Are you safe right now? "
                 "If you're in the US and in danger, call or text 988 right away.")
        self._remember(p, "assistant", reply)
        return reply

    def joke(self):
        return next_joke()

    def earth_message(self):
        msg = self.earth.next()
        if not msg:
            return "No messages from Earth yet. Add one with: python companion.py add-message --from Mom --text \"...\""
        return 'A message from %s: "%s"' % (msg["from"], msg["text"])


# ----------------------------------------------------------------------------
# Voice
# ----------------------------------------------------------------------------
class Speaker:
    """Speaks every line out loud, one at a time, on its own thread.

    Order of tries: pyttsx3 (pip install pyttsx3), then the computer's built-in
    voice: Windows speech (PowerShell), macOS 'say', or Linux espeak. The voice
    engine is created INSIDE the voice thread, which is what makes it work on Windows.
    """

    def __init__(self, enabled=True, rate=175):
        self.enabled = enabled
        self.rate = rate
        self.mode = None            # "pyttsx3", "windows", "mac", "espeak" or None
        self.ready = threading.Event()
        self._q = queue.Queue()
        self._engine = None
        threading.Thread(target=self._run, daemon=True).start()

    # -- setup --
    def _pick_cli_mode(self):
        if os.name == "nt" and shutil.which("powershell"):
            return "windows"
        if sys.platform == "darwin" and shutil.which("say"):
            return "mac"
        for exe in ("espeak-ng", "espeak"):
            if shutil.which(exe):
                return exe
        return None

    def _cli_speak(self, text):
        mode = self.mode
        if mode == "windows":
            ps = ("Add-Type -AssemblyName System.Speech; "
                  "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  "$s.Speak([Console]::In.ReadToEnd())")
            cmd = ["powershell", "-NoProfile", "-Command", ps]
        elif mode == "mac":
            cmd = ["say", "-r", str(self.rate)]
        else:
            cmd = [mode, "--stdin"]
        subprocess.run(cmd, input=text.encode("utf-8"), check=False, timeout=120)

    def _run(self):
        if os.name == "nt" and shutil.which("powershell") and not os.environ.get("COMPANION_PYTTSX3"):
            self.mode = "windows"          # most reliable on Windows; set COMPANION_PYTTSX3=1 to use pyttsx3
            self.ready.set()
            return self._loop()
        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            self._engine.setProperty("rate", self.rate)
            self.mode = "pyttsx3"
        except Exception:
            self._engine = None
            self.mode = self._pick_cli_mode()
        self.ready.set()
        self._loop()

    def _loop(self):
        while True:
            text = self._q.get()
            try:
                if text is None:
                    return
                if not self.enabled:
                    continue
                if self._engine is not None:
                    try:
                        self._engine.say(text)
                        self._engine.runAndWait()
                        continue
                    except Exception as exc:
                        print("[voice] pyttsx3 failed (%s), switching to the built-in voice" % exc)
                        self._engine = None
                        self.mode = self._pick_cli_mode()
                if self.mode:
                    self._cli_speak(text)
            except Exception as exc:
                print("[voice] could not speak:", exc)
            finally:
                self._q.task_done()

    # -- use --
    def say(self, text):
        if self.enabled:
            self._q.put(text)

    def wait(self, timeout=60):
        end = time.time() + timeout
        while self._q.unfinished_tasks and time.time() < end:
            time.sleep(0.1)

    def close(self):
        self.wait()
        self._q.put(None)


# ----------------------------------------------------------------------------
# Command line
# ----------------------------------------------------------------------------
def build_status(name, mood):
    table = {"low": (0.8, 0.0), "happy": (0.05, 0.7), "neutral": (0.1, 0.1)}
    neg, pos = table[mood]
    return {
        "timestamp": time.time(), "camera_ok": True, "privacy_mode": False,
        "faces": [], "error": None,
        "mood": {name: {"negative_score": neg, "positive_score": pos, "samples": 99,
                        "low_mood_signal": mood == "low"}},
    }


def main():
    parser = argparse.ArgumentParser(description="Mood-aware AI companion for the habitat")
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--no-camera", action="store_true", help="practice mode, use /mood commands")
    parser.add_argument("--name", default="Crew", help="name used in practice mode or when the face is unknown")
    parser.add_argument("--companion-name", default="Luna")
    parser.add_argument("--serial", help="Arduino check-in console port, e.g. COM3")
    parser.add_argument("--mute", action="store_true", help="turn the spoken voice off (it is on by default)")
    parser.add_argument("--voice-rate", type=int, default=175, help="speaking speed, default 175")
    parser.add_argument("--voice", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--offline", action="store_true", help="no AI service, built-in replies only")
    parser.add_argument("--demo", action="store_true", help="short timers for presentations")
    parser.add_argument("--log", action="store_true", help="save a local conversation log (off by default)")
    sub = parser.add_subparsers(dest="cmd")
    p_add = sub.add_parser("add-message", help="add a message from Earth")
    p_add.add_argument("--from", dest="sender", required=True)
    p_add.add_argument("--text", required=True)
    sub.add_parser("list-messages", help="show messages from Earth")
    sub.add_parser("speak-test", help="check that you can hear the voice")
    args = parser.parse_args()

    if args.cmd == "speak-test":
        speaker = Speaker(enabled=True, rate=args.voice_rate)
        speaker.ready.wait(timeout=15)
        if speaker.mode is None:
            print("No voice engine found. Run: pip install pyttsx3")
            return
        print("Voice engine: %s. Speaking now..." % speaker.mode)
        speaker.say("Hello, I'm %s. If you can hear this, my voice is working." % args.companion_name)
        speaker.close()
        return

    if args.cmd == "add-message":
        EarthMessages().add(args.sender, args.text)
        print("Saved. It will be delivered on a low-mood moment.")
        return
    if args.cmd == "list-messages":
        for m in EarthMessages().items:
            print("%s: %s  [%s]" % (m["from"], m["text"], m.get("delivered_at") or "not delivered yet"))
        return

    out_lock = threading.Lock()
    speaker = Speaker(enabled=not args.mute, rate=args.voice_rate)
    speaker.ready.wait(timeout=15)
    if args.mute:
        print("[voice] muted (remove --mute to hear it)")
    elif speaker.mode is None:
        print("[voice] No voice engine found, so it can only type. Fix: pip install pyttsx3")
    else:
        print("[voice] on (%s). Type /mute to silence it." % speaker.mode)

    def say(text):
        with out_lock:
            print("\n%s: %s\n> " % (args.companion_name, text), end="", flush=True)
        speaker.say(text)

    def alert(name, reason):
        with out_lock:
            print("\n[ALERT -> mission psychologist] %s: %s\n> " % (name, reason), end="", flush=True)

    ser = None
    if args.serial:
        try:
            import serial
            ser = serial.Serial(args.serial, 9600, timeout=0.1)
            time.sleep(2)
        except Exception as exc:
            print("[companion] Could not open serial port:", exc)

    def ping():
        if ser:
            ser.write(b"P")  # makes the Arduino check-in console ask "How are you?"

    timers = dict(low_cooldown=600, happy_cooldown=300, ambient_interval=1200, stable_seconds=8)
    if args.demo:
        timers = dict(low_cooldown=25, happy_cooldown=25, ambient_interval=60, stable_seconds=2)
    comp = Companion(say=say, escalate=alert, console_ping=ping if ser else None,
                     llm=LLM(enabled=not args.offline), companion_name=args.companion_name,
                     log=args.log, **timers)

    if not comp.earth.items:
        print('[companion] No messages from Earth yet. Add one: python companion.py add-message --from Mom --text "..."')

    monitor = None
    sim = {"mood": "neutral"}
    state = {"who": args.name, "stop": False}
    if not args.no_camera:
        try:
            from face_monitor import FaceMonitor  # needs face_monitor.py in the same folder
            monitor = FaceMonitor(camera_index=args.camera, window_seconds=20)
            monitor.start()
            time.sleep(2.5)
            err = monitor.get_status().get("error")
            if err:
                print("[camera] %s. Switching to practice mode (/mood low|happy|neutral)." % err)
                monitor.stop()
                monitor = None
            else:
                print("[camera] on (%s engine). Faces stay on this computer." % monitor.get_status().get("engine", "opencv"))
        except Exception as exc:
            print("[camera] not available (%s). Switching to practice mode (/mood low|happy|neutral)." % exc)
            monitor = None

    def watch():
        while not state["stop"]:
            if monitor is not None:
                status = monitor.get_status()
                named = [f["name"] for f in status.get("faces", []) if f["name"] != "unknown"]
                if named:
                    state["who"] = named[0]
            else:
                status = build_status(state["who"], sim["mood"])
            try:
                comp.tick(status)
            except Exception as exc:
                print("[companion] tick error:", exc)
            time.sleep(2)

    threading.Thread(target=watch, daemon=True).start()
    print("%s is ready. Type to talk. /joke /earth /mute /privacy /quit%s" %
          (args.companion_name, "  /mood low|happy|neutral" if monitor is None else ""))
    say("Hi, I'm %s. I'm here whenever you want to talk." % args.companion_name)
    privacy = False
    try:
        while True:
            try:
                text = input("> ").strip()
            except EOFError:
                break
            if not text:
                continue
            if text == "/quit":
                break
            if text == "/mute":
                speaker.enabled = not speaker.enabled
                print("Voice:", "ON" if speaker.enabled else "OFF (muted)")
            elif text == "/joke":
                say(comp.joke())
            elif text == "/earth":
                say(comp.earth_message())
            elif text.startswith("/mood") and monitor is None:
                parts = text.split()
                if len(parts) == 2 and parts[1] in ("low", "happy", "neutral"):
                    sim["mood"] = parts[1]
                    print("(practice mode) mood set to", parts[1])
                else:
                    print("Use: /mood low | happy | neutral")
            elif text == "/privacy":
                privacy = not privacy
                if monitor is not None:
                    monitor.set_privacy(privacy)
                print("Privacy mode:", "ON (camera off)" if privacy else "OFF")
            else:
                say(comp.chat(state["who"], text))
    except KeyboardInterrupt:
        pass
    finally:
        state["stop"] = True
        speaker.close()
        if monitor is not None:
            monitor.stop()
        if ser:
            ser.close()


if __name__ == "__main__":
    main()
