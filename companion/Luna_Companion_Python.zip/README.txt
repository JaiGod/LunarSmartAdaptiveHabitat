LUNA - AI CREW COMPANION  (NASA HUNCH Project ARES, SIM-06)
by Jaineil R., with Angel C. and Farhan K.

1) Install Python 3.10+ from python.org (tick "Add to PATH").
2) In this folder run:
     pip install opencv-python numpy mediapipe pyttsx3 anthropic pyserial
   (only opencv-python + numpy are required; the rest are optional extras)
3) Optional - teach it your face so it greets you by name:
     python face_monitor.py enroll --name YourName
4) Run it:
     python companion.py            camera + companion
     python companion.py --demo     short timers for showing judges
     python companion.py --no-camera   practice mode (/mood low, /mood happy)
     python companion.py speak-test    check the voice
5) Add a message from Earth:
     python companion.py add-message --from "Mom" --text "Proud of you!"

Commands while running: /joke  /earth  /mute  /privacy  /quit
Optional real AI conversation: set ANTHROPIC_API_KEY (see top of companion.py).
Privacy: camera frames never leave the computer and are never saved.
Browser version: https://jaigod.github.io/LunarSmartAdaptiveHabitat/companion/
