LUNA VR - Lunar Smart Adaptive Habitat (NASA HUNCH, Project ARES)
© 2026 Jaineil R. - with thanks to Angel C. and Farhan K.

PC VR (Meta Quest through Quest Link or Air Link, or any OpenXR headset):
  1. Connect the headset to the PC (Quest Link / Air Link) so the OpenXR runtime is active.
  2. Double-click LUNA_VR.exe. The game starts in VR automatically.
Without a headset it runs on the desktop: WASD to move, mouse to look, click or E to use.

VR controls: left stick move, right stick snap-turn, trigger to use things and click screens,
A = yes / B = no to LUNA's offers, Y = fast-forward.

New in this version (round 3: every object does something, plus the realistic features of our
Unity 3 "Moon_Base_Final" and Lunar Habitat Commander games)
  - Every usable object has a glowing ring (cyan = press, green = grab / use, amber = a crewmate).
    Point at it to see what it does (in VR the label floats next to it). About 25 new things to use.
  - Check on a crewmate: walk up to them (or press I). They choose whether to share; then you see
    their readings and where each comes from, the six condition bars, and a Help button.
  - Governance wall in Ops: AI OFF switch (LUNA stops and undoes everything; only a human turns it
    back on), floor plan A/B selector, safety drill alarm, AI dashboard (break a sensor, test a hard
    limit), review board (Q1-Q6 run live, D1-D6, rubric checklist, 72-hour tabletop).
  - Night watch: on night 2 the hardware watchdog catches LUNA breaking a bedtime rule, switches it
    off and wakes you. You decide when it comes back on.
  - Team meeting at the wardroom table, safety drill to the muster point, CMO console (Tier 3).
  - Room controls in five rooms: light, sound, temperature, scent. A crew override LUNA respects.
  - Your pod: "LUNA may adjust my pod" switch, music, photo from home; pod desk "My data" tab
    (opt out of sensors, pause LUNA for you, export or delete your own log).
  - Keys: G guide me (gold path) - B path to bed - I check in - O AI OFF - C floor plan A/B
    J rubric - Z zone card - K all keys. VR: Guide me / Rubric / AI OFF buttons on your wrist.

Realism pass (realism first: everything aboard has a job, upkeep, a resource cost and limits)
  - Point at anything: the prompt shows what it uses (power, water, mass, consumables).
    Press X (desktop) for the full card: why it's aboard, upkeep, resources, limits.
  - No "dust storms": the Moon has no weather. Dust comes from lander plumes, rover traffic,
    EVA boots and electrostatic lofting at the terminator.
  - Paper books replaced by 0.3 kg e-readers (every kg costs about $1M to land).
  - Skylab-style 3 L shower; ISSpresso-style coffee; a 3D printer in the maintenance bay prints
    non-structural spare parts from recycled plastic (feedstock runs out).
  - The Earth view is a display fed by a mast camera (the habitat is under regolith shielding).

Earlier in this version
  - Wellness Operations Center: a live 3D twin of the habitat (crew pucks move, rooms glow with
    their real lighting) and an intervention planning station for crew-wide plans.
  - Wellness Dock (exercise bay): 1-minute scan + the Reaction Self Test used on the ISS.
  - EVA Prep Bay (airlock): suit consumables + LUNA's fatigue read before every EVA.
  - Earth Connection corner (social hub): live Earth window and family messages.
  - SELENE link: LUNA can use SELENE (the face + voice wellness app) as a live sensor.

SELENE link (optional)
  1. Copy selene_bridge.py into the SELENE folder (next to selene_app.py).
  2. Run:  python selene_bridge.py      (instead of python selene_app.py)
  3. Start LUNA VR. Screens show "SELENE live" and LUNA reacts to your real check-ins.
  No SELENE? Test it with:  python selene_bridge.py --demo
  Only three scores leave SELENE (no images, no audio), and only on this computer (127.0.0.1).
