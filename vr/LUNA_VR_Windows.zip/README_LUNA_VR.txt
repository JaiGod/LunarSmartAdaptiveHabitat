LUNA VR - Lunar Smart Adaptive Habitat (NASA HUNCH, Project ARES)
© 2026 Jaineil R. - with thanks to Angel C. and Farhan K.

PC VR (Meta Quest through Quest Link or Air Link, or any OpenXR headset):
  1. Connect the headset to the PC (Quest Link / Air Link) so the OpenXR runtime is active.
  2. Double-click LUNA_VR.exe. The game starts in VR automatically.
Without a headset it runs on the desktop: WASD to move, mouse to look, click or E to use.

VR controls: left stick move, right stick snap-turn, trigger to use things and click screens,
A = yes / B = no to LUNA's offers, Y = fast-forward.

New in this version
  - Wellness Operations Center: a live 3D twin of the habitat (crew pucks move, rooms glow with
    their real lighting) and an intervention planning station for crew-wide plans.
  - Wellness Dock (exercise bay): 1-minute scan + the Reaction Self Test used on the ISS.
  - EVA Prep Bay (airlock): suit consumables + LUNA's fatigue read before every EVA.
  - Earth Connection corner (social hub): live Earth window and family messages.
  - SELENE link: LUNA can use SELENE (the face + voice wellness app) as a live sensor.

SELENE link (optional)
  1. Copy selene_bridge.py into the SELENE folder (next to selene_app.py).
  2. Run:  python selene_bridge.py      (instead of python selene_app.py)
  3. Start LUNA VR. Screens show "SELENE live" and LUNA reacts to your real check-ins.
  No SELENE? Test it with:  python selene_bridge.py --demo
  Only three scores leave SELENE (no images, no audio), and only on this computer (127.0.0.1).
