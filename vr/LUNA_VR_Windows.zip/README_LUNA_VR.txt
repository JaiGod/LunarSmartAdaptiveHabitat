LUNA VR - Lunar Smart Adaptive Habitat (NASA HUNCH, Project ARES)
© 2026 Jaineil R. - with thanks to Angel C. and Farhan K.

PC VR (Meta Quest through Quest Link or Air Link, or any OpenXR headset):
  1. Connect the headset to the PC (Quest Link / Air Link) so the OpenXR runtime is active.
  2. Double-click LUNA_VR.exe. The game starts in VR automatically.
Without a headset it runs on the desktop: WASD to move, mouse to look, click or E to use.

VR controls: left stick move, right stick snap-turn, trigger to use things and click screens,
A = yes / B = no to LUNA's offers, Y = fast-forward.
