LUNA-X Lunar Habitat Operations Uniform - NASA HUNCH Project ARES
Designed and modeled by Jaineil R., with Angel C. and Farhan K.

LHC_Crew_Uniform.blend  - Blender 5.x scene. Keep the "textures" folder next to it.
                          The grey body ("Body"/"FitForm_Smooth") is a hidden fitting form, not part of the design.
                          The animation (frames 1-240): chest module power-on, color cycle, scan ring, pulse, turntable.
model/lhc_uniform.glb   - web-ready glTF (Draco compressed)
renders/                - Cycles renders + power-on turntable video
