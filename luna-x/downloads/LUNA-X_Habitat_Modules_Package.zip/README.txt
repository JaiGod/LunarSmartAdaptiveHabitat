NASA HUNCH Project ARES - LUNA-X habitat modules
Designed by Jaineil R. (with Angel C. and Farhan K.)
GLB models open in Blender (File > Import > glTF), Unity, Godot or any 3D viewer.
