Astronaut Voice Log (Windows program)

Voice-controlled crew logs with an estimated mood for each log.
Part of the NASA HUNCH Lunar Smart Adaptive Habitat project.

HOW TO RUN
1. Install Python 3 from https://www.python.org/downloads/
   (tick "Add python.exe to PATH" during setup).
2. Unzip this folder.
3. Double-click "Start Voice Log.bat".
   The first run installs the needed packages and downloads a 40 MB speech model.
4. Pick your microphone from the list, then click Start Listening.

VOICE COMMANDS
  "start log"  "stop log"  "set baseline"  "play last log"

Speech is turned into text on your computer with Vosk. Nothing is sent online.
Recordings and logs are saved in the "data" folder.

The mood result is an estimate for a school prototype.
It is NOT a medical or psychological diagnosis.
