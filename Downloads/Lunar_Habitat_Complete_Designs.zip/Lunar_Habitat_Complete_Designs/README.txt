LUNAR HABITAT - COMPLETE 3D DESIGNS (both games)
NASA HUNCH - Project ARES - Lunar Smart Adaptive Habitat
(c) 2026 Jaineil R. - with thanks to Angel C. and Farhan K.

1_Realistic - Lunar Smart Adaptive Habitat
   Habitat.fbx              the full flight-sized base: core hub (2 decks), 4 crew quarters,
                            4 sleep pods, galley ring, lab, command, medical/storm shelter,
                            hygiene, greenhouse, VR retreat, airlock and connecting tubes
   Terrain.fbx              the lunar ground around it
   Floor_plan_to_scale.png  dimensioned floor plan (57.0 x 72.3 m, ~740 m3 per crew)

2_SciFi - Lunar Habitat Commander
   Lunar_Base.fbx           the full sci-fi base: two-level core habitat, centre dome and hub
                            tower, greenhouse, medical, logistics, spaceport and outposts
   Floor_plan_to_scale.png  dimensioned site plan (160 x 142 m)

HOW TO OPEN
   Blender: File > Import > FBX (.fbx)
   Unity:   drag the .fbx into the Assets folder
   Windows: double-click to view in 3D Viewer
   Units are metres.

Play both games in the browser: https://jaigod.github.io/LunarSmartAdaptiveHabitat/
