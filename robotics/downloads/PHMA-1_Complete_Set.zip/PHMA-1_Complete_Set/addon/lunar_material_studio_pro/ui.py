"""Lunar Habitat Material Control Center - 3D Viewport sidebar (N panel), tab 'Lunar MSP'."""
import bpy, os
from bpy.props import (StringProperty, IntProperty, FloatProperty, EnumProperty, CollectionProperty, PointerProperty)
from bpy.types import Operator, Panel, PropertyGroup, UIList
from . import materials, assign, decals, pipeline, lighting, render, preview
from .core import AGE_PROP, LED_PROP, ensure_scene_props

SHOTS = [
    ('HABITAT', "Habitat Exterior", "CAM_Habitat_Exterior", 'MOON_NOON'),
    ('ARM', "Robotic Arm", "CAM_Arm_Preview", 'MOON_NOON'),
    ('WATER', "Water System", "CAM_Water_System", None),
    ('RADIATION', "Radiation System", "CAM_Radiation_System", 'STORM_SHELTER'),
    ('AQUAPONICS', "Aquaponics", "CAM_Aquaponics", 'GREENHOUSE'),
    ('COLONY', "Colony", "CAM_Colony", 'MOON_SUNRISE'),
    ('HERO', "Hero Render", "CAM_Hero", None),
]


def _scope_objs(context):
    return assign.target_objects(context, context.scene.lmsp.scope)


class LMSP_MatItem(PropertyGroup):
    name: StringProperty()
    users: IntProperty()
    mtype: StringProperty()
    texres: StringProperty()
    mem_mb: FloatProperty()
    status: StringProperty()
    issues: StringProperty()
    nodes: IntProperty()
    tris: IntProperty()
    normal: IntProperty()
    rough: IntProperty()
    tex4k: IntProperty()


class LMSP_Settings(PropertyGroup):
    materials: CollectionProperty(type=LMSP_MatItem)
    mat_index: IntProperty()
    preview_shape: EnumProperty(name="Preview Geometry", items=preview.SHAPES, default='SPHERE')
    scope: EnumProperty(name="Scope", items=[('ALL', "Whole Scene", ""), ('SELECTED', "Selected", ""),
                                             ('COLLECTION', "Active Collection", "")], default='ALL')
    last_report: StringProperty()
    an_time: FloatProperty()
    an_vram: FloatProperty()
    an_tex: FloatProperty()
    an_complex: FloatProperty()
    an_score: IntProperty()
    an_tris: IntProperty()


# ------------------------------------------------------------------ operators
class LMSP_OT_build_library(Operator):
    bl_idname = "lmsp.build_library"
    bl_label = "Build Material Library"
    bl_description = "Generate every PHMA procedural material and the shared weathering node group"

    def execute(self, context):
        made, errors = materials.build_library(context.scene)
        self.report({'INFO'} if not errors else {'WARNING'}, "%d materials built, %d errors" % (len(made), len(errors)))
        bpy.ops.lmsp.refresh_browser()
        return {'FINISHED'}


class LMSP_OT_auto_configure(Operator):
    bl_idname = "lmsp.auto_configure"
    bl_label = "AUTO CONFIGURE ASSETS"
    bl_description = "Build library, assign materials, apply dust + wear tags, validate"

    def execute(self, context):
        st = pipeline.auto_configure(context, context.scene.lmsp.scope)
        rep = pipeline.validate_scene(context)
        context.scene.lmsp.last_report = "%s | %d assigned | %d errors | %d warnings" % (
            rep["status"], st["assigned"], len(rep["errors"]), len(rep["warnings"]))
        bpy.ops.lmsp.refresh_browser()
        self.report({'INFO'}, context.scene.lmsp.last_report)
        return {'FINISHED'}


class LMSP_OT_assign(Operator):
    bl_idname = "lmsp.assign_materials"
    bl_label = "Assign Materials"

    def execute(self, context):
        st = assign.assign_materials(_scope_objs(context))
        self.report({'INFO'}, "Assigned %d objects (%d fallback)" % (st["assigned"], len(st["fallback"])))
        return {'FINISHED'}


class LMSP_OT_dust(Operator):
    bl_idname = "lmsp.apply_dust"
    bl_label = "Apply Dust"

    def execute(self, context):
        n = assign.apply_dust(_scope_objs(context))
        self.report({'INFO'}, "Dust + exterior tags on %d objects" % n)
        return {'FINISHED'}


class LMSP_OT_wear(Operator):
    bl_idname = "lmsp.apply_wear"
    bl_label = "Apply Wear"

    def execute(self, context):
        n = assign.apply_wear(_scope_objs(context))
        self.report({'INFO'}, "Wear tags on %d objects" % n)
        return {'FINISHED'}


class LMSP_OT_decals(Operator):
    bl_idname = "lmsp.generate_decals"
    bl_label = "Generate Decals"
    bl_description = "Place ID plates, maintenance stickers and QR tags on the selected objects"

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        n = decals.auto_decals(objs)
        self.report({'INFO'}, "%d decals generated" % n)
        return {'FINISHED'}


class LMSP_OT_validate(Operator):
    bl_idname = "lmsp.validate_scene"
    bl_label = "Validate Scene"

    def execute(self, context):
        d = os.path.join(os.path.dirname(bpy.data.filepath), "docs") if bpy.data.filepath else None
        rep = pipeline.validate_scene(context, True, d)
        context.scene.lmsp.last_report = "%s | %d errors | %d warnings | %d tris" % (
            rep["status"], len(rep["errors"]), len(rep["warnings"]), rep["tris"])
        self.report({'INFO'} if rep["status"] == "PASS" else {'WARNING'},
                    context.scene.lmsp.last_report + " (see Text: LMSP_Validation_Report)")
        return {'FINISHED'}


class LMSP_OT_optimize(Operator):
    bl_idname = "lmsp.optimize_render"
    bl_label = "Optimize For Rendering"

    def execute(self, context):
        self.report({'INFO'}, pipeline.optimize_for_rendering(context.scene))
        return {'FINISHED'}


class LMSP_OT_prepare(Operator):
    bl_idname = "lmsp.prepare_movie"
    bl_label = "Prepare Movie Assets"

    def execute(self, context):
        self.report({'INFO'}, pipeline.prepare_movie_assets(context))
        return {'FINISHED'}


class LMSP_OT_lods(Operator):
    bl_idname = "lmsp.generate_lods"
    bl_label = "Generate LOD Versions"

    def execute(self, context):
        objs = context.selected_objects or _scope_objs(context)
        n = pipeline.generate_lods(objs)
        self.report({'INFO'}, "%d LOD meshes created in LMSP_LODs" % n)
        return {'FINISHED'}


class LMSP_OT_refresh(Operator):
    bl_idname = "lmsp.refresh_browser"
    bl_label = "Refresh"

    def execute(self, context):
        s = context.scene.lmsp
        s.materials.clear()
        users = {}
        tris = {}
        for ob in context.scene.objects:
            if ob.type != 'MESH':
                continue
            for sl in ob.material_slots:
                if sl.material:
                    users[sl.material.name] = users.get(sl.material.name, 0) + 1
                    tris[sl.material.name] = tris.get(sl.material.name, 0) + len(ob.data.polygons)
        for m in sorted(bpy.data.materials, key=lambda m: m.name):
            if m.name.startswith("RT_") or not m.name.startswith("PHMA_"):
                continue
            e, w, info = pipeline._mat_issues(m)
            it = s.materials.add()
            it.name = m.name
            it.users = users.get(m.name, 0)
            it.mtype = m.get("lmsp_type", "-")
            sizes = [n.image.size[0] for n in m.node_tree.nodes if n.type == 'TEX_IMAGE' and n.image] if m.node_tree else []
            it.texres = ("%dK" % max(1, round(max(sizes) / 1024))) if sizes else "Procedural"
            it.mem_mb = sum(n.image.size[0] * n.image.size[1] * 4 / 1e6 for n in m.node_tree.nodes
                            if n.type == 'TEX_IMAGE' and n.image) if m.node_tree else 0
            it.status = "ERR" if e else ("WARN" if w else "OK")
            it.issues = "; ".join(e + w)
            it.nodes = info["nodes"]
            it.tris = tris.get(m.name, 0)
            it.normal, it.rough, it.tex4k = int(info["normal"]), int(info["rough"]), int(info["tex4k"])
        return {'FINISHED'}


class LMSP_OT_preview(Operator):
    bl_idname = "lmsp.preview_material"
    bl_label = "Preview"
    category: StringProperty()

    def execute(self, context):
        n = preview.show_preview(context, self.category, context.scene.lmsp.preview_shape)
        self.report({'INFO'}, "Preview: %s (%d)" % (self.category, n))
        return {'FINISHED'}


class LMSP_OT_set_age(Operator):
    bl_idname = "lmsp.set_age"
    bl_label = "Set Mission Age"
    years: FloatProperty()

    def execute(self, context):
        ensure_scene_props(context.scene)
        context.scene[AGE_PROP] = self.years
        context.scene.update_tag()
        for m in bpy.data.materials:
            if m.node_tree:
                m.node_tree.update_tag()
        return {'FINISHED'}


class LMSP_OT_env(Operator):
    bl_idname = "lmsp.environment"
    bl_label = "Environment"
    preset: EnumProperty(items=lighting.PRESET_ITEMS)

    def execute(self, context):
        lighting.apply_preset(context.scene, self.preset)
        return {'FINISHED'}


class LMSP_OT_highlight(Operator):
    bl_idname = "lmsp.highlight"
    bl_label = "Highlight"
    category: StringProperty()

    def execute(self, context):
        n = assign.highlight_category(context, self.category)
        self.report({'INFO'}, "%d objects highlighted (%s)" % (n, self.category))
        return {'FINISHED'}


class LMSP_OT_restore(Operator):
    bl_idname = "lmsp.restore_shading"
    bl_label = "Restore Shading"

    def execute(self, context):
        assign.restore_shading(context)
        return {'FINISHED'}


class LMSP_OT_diag(Operator):
    bl_idname = "lmsp.texture_diagnostics"
    bl_label = "Run Texture Diagnostics"

    def execute(self, context):
        bpy.ops.lmsp.refresh_browser()
        txt = bpy.data.texts.get("LMSP_Texture_Diagnostics") or bpy.data.texts.new("LMSP_Texture_Diagnostics")
        txt.clear()
        L = ["%-28s %-10s %-6s %-6s %-6s %s" % ("MATERIAL", "TEX", "NORMAL", "ROUGH", "STATUS", "ISSUES")]
        for it in context.scene.lmsp.materials:
            L.append("%-28s %-10s %-6s %-6s %-6s %s" % (it.name, it.texres, "yes" if it.normal else "no",
                                                         "yes" if it.rough else "no", it.status, it.issues))
        txt.write("\n".join(L))
        self.report({'INFO'}, "Diagnostics written to Text: LMSP_Texture_Diagnostics")
        return {'FINISHED'}


class LMSP_OT_render_preset(Operator):
    bl_idname = "lmsp.render_preset"
    bl_label = "Render Preset"
    preset: EnumProperty(items=render.PRESET_ITEMS)

    def execute(self, context):
        lbl = render.apply_render_preset(context.scene, self.preset)
        bpy.ops.lmsp.analyze_quality()
        self.report({'INFO'}, "Render preset: " + lbl)
        return {'FINISHED'}


class LMSP_OT_render_now(Operator):
    bl_idname = "lmsp.render_now"
    bl_label = "Render Still"

    def execute(self, context):
        bpy.ops.render.render('INVOKE_DEFAULT')
        return {'FINISHED'}


class LMSP_OT_analyze(Operator):
    bl_idname = "lmsp.analyze_quality"
    bl_label = "Analyze"

    def execute(self, context):
        a = render.analyze(context.scene)
        s = context.scene.lmsp
        s.an_time, s.an_vram, s.an_tex = a["est_seconds"], a["vram_gb"], a["tex_mb"]
        s.an_complex, s.an_score, s.an_tris = a["complexity"], a["score"], a["tris"]
        return {'FINISHED'}


class LMSP_OT_compare(Operator):
    bl_idname = "lmsp.build_comparison"
    bl_label = "Build NEW / 1 / 5 / 10 Year Comparison"

    def execute(self, context):
        n = preview.build_comparison(context)
        self.report({'INFO'}, "%d arms placed (camera CAM_LMSP_Comparison)" % n if n else "RIG_PHMA1_EXT not found")
        return {'FINISHED'}


class LMSP_OT_clear_compare(Operator):
    bl_idname = "lmsp.clear_comparison"
    bl_label = "Clear Comparison"

    def execute(self, context):
        preview.clear_comparison()
        return {'FINISHED'}


class LMSP_OT_shot(Operator):
    bl_idname = "lmsp.movie_shot"
    bl_label = "Movie Shot"
    shot: StringProperty()

    def execute(self, context):
        for key, label, cam, env in SHOTS:
            if key != self.shot:
                continue
            if key == 'HERO' and "LSAH_Hero_LunarSunrise" in bpy.data.scenes:
                context.window.scene = bpy.data.scenes["LSAH_Hero_LunarSunrise"]
                return {'FINISHED'}
            if "LSAH_Robotics" in bpy.data.scenes and context.scene.name != "LSAH_Robotics":
                context.window.scene = bpy.data.scenes["LSAH_Robotics"]
            sc = context.window.scene
            ob = bpy.data.objects.get(cam)
            if not ob:
                self.report({'WARNING'}, cam + " not found")
                return {'CANCELLED'}
            sc.camera = ob
            if "lmsp_frame" in ob.keys():
                sc.frame_set(int(ob["lmsp_frame"]))
            if env:
                lighting.apply_preset(sc, env)
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.spaces.active.region_3d.view_perspective = 'CAMERA'
        return {'FINISHED'}


class LMSP_OT_select_users(Operator):
    bl_idname = "lmsp.select_material_users"
    bl_label = "Select Objects Using Material"

    def execute(self, context):
        s = context.scene.lmsp
        if not s.materials:
            return {'CANCELLED'}
        name = s.materials[s.mat_index].name
        bpy.ops.object.select_all(action='DESELECT')
        for ob in context.scene.objects:
            if ob.type == 'MESH' and any(sl.material and sl.material.name == name for sl in ob.material_slots):
                try:
                    ob.select_set(True)
                except Exception:
                    pass
        return {'FINISHED'}


class LMSP_OT_export(Operator):
    bl_idname = "lmsp.export_glb"
    bl_label = "Export Game-Ready GLB (baked)"
    bl_description = "Merge parts per bone + material, bake procedural materials, export rig and animations"

    def execute(self, context):
        sel_rigs = [o for o in context.selected_objects if o.type == 'ARMATURE']
        if not sel_rigs:
            self.report({'WARNING'}, "Select a robot rig (RIG_*) first")
            return {'CANCELLED'}
        rig = sel_rigs[0]
        cols = list({c.name for o in rig.children_recursive for c in o.users_collection})
        folder = os.path.join(os.path.dirname(bpy.data.filepath) or os.path.expanduser("~"), "exports_glb")
        r = pipeline.export_glb(rig.name.replace("RIG_", ""), cols, [rig], os.path.join(folder, rig.name.replace("RIG_", "") + ".glb"))
        self.report({'INFO'} if r["ok"] else {'ERROR'}, str(r))
        return {'FINISHED'}


# ------------------------------------------------------------------ UI
class LMSP_UL_materials(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        ic = {'OK': 'CHECKMARK', 'WARN': 'ERROR', 'ERR': 'CANCEL'}.get(item.status, 'DOT')
        row = layout.row(align=True)
        row.label(text=item.name.replace("PHMA_", ""), icon=ic)
        sub = row.row()
        sub.alignment = 'RIGHT'
        sub.label(text="%d obj" % item.users)
        sub.label(text=item.texres)


class _Base:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Lunar MSP"


class LMSP_PT_main(_Base, Panel):
    bl_label = "Lunar Habitat Material Control Center"
    bl_idname = "LMSP_PT_main"

    def draw(self, context):
        L = self.layout
        s = context.scene.lmsp
        box = L.box()
        box.label(text="LUNAR MATERIAL STUDIO PRO", icon='WORLD')
        box.scale_y = 1.0
        r = box.row()
        r.scale_y = 1.8
        r.operator("lmsp.auto_configure", icon='SHADERFX')
        box.prop(s, "scope")
        if s.last_report:
            box.label(text=s.last_report, icon='INFO')


class LMSP_PT_pipeline(_Base, Panel):
    bl_label = "Film Pipeline"
    bl_parent_id = "LMSP_PT_main"

    def draw(self, context):
        c = self.layout.column(align=True)
        c.operator("lmsp.build_library", icon='MATERIAL')
        c.operator("lmsp.assign_materials", icon='BRUSH_DATA')
        r = c.row(align=True)
        r.operator("lmsp.apply_dust", icon='PARTICLES')
        r.operator("lmsp.apply_wear", icon='MOD_NOISE')
        c.operator("lmsp.generate_decals", icon='IMAGE_DATA')
        c.operator("lmsp.validate_scene", icon='CHECKBOX_HLT')
        c.operator("lmsp.optimize_render", icon='RENDER_STILL')
        c.operator("lmsp.prepare_movie", icon='SEQUENCE')
        c.operator("lmsp.generate_lods", icon='MOD_DECIM')
        c.operator("lmsp.export_glb", icon='EXPORT')


class LMSP_PT_browser(_Base, Panel):
    bl_label = "Material Browser"
    bl_parent_id = "LMSP_PT_main"

    def draw(self, context):
        L = self.layout
        s = context.scene.lmsp
        L.operator("lmsp.refresh_browser", icon='FILE_REFRESH')
        L.template_list("LMSP_UL_materials", "", s, "materials", s, "mat_index", rows=8)
        if s.materials and 0 <= s.mat_index < len(s.materials):
            it = s.materials[s.mat_index]
            m = bpy.data.materials.get(it.name)
            b = L.box()
            b.label(text=it.name, icon='MATERIAL')
            g = b.grid_flow(columns=2, align=True)
            g.label(text="Type: " + it.mtype)
            g.label(text="Objects: %d" % it.users)
            g.label(text="Textures: " + it.texres)
            g.label(text="Memory: %.1f MB" % it.mem_mb)
            g.label(text="Nodes: %d" % it.nodes)
            g.label(text="Poly ref: %d" % it.tris)
            for flag, lbl in ((it.tex4k, "4K Texture Loaded"), (it.normal, "Normal Map Connected"),
                              (it.rough, "Roughness Map Connected"), (it.status != "ERR", "Procedural Nodes Valid")):
                b.label(text=lbl, icon='CHECKMARK' if flag else 'X')
            if it.issues:
                b.label(text=it.issues, icon='ERROR')
            b.operator("lmsp.select_material_users", icon='RESTRICT_SELECT_OFF')
            if m:
                b.template_preview(m, show_buttons=True)


class LMSP_PT_preview(_Base, Panel):
    bl_label = "Live Material Preview"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        L = self.layout
        L.prop(context.scene.lmsp, "preview_shape")
        c = L.column(align=True)
        for cat, lbl in (("Titanium", "Preview Titanium"), ("Carbon", "Preview Carbon Fiber"), ("Glass", "Preview Glass"),
                         ("Dust", "Preview Dust"), ("Hydraulics", "Preview Hydraulics"),
                         ("Thermal", "Preview Thermal Blankets"), ("FULL", "Preview Full Asset")):
            c.operator("lmsp.preview_material", text=lbl).category = cat


class LMSP_PT_aging(_Base, Panel):
    bl_label = "Wear & Aging"
    bl_parent_id = "LMSP_PT_main"

    def draw(self, context):
        L = self.layout
        sc = context.scene
        if "lmsp_mission_age" not in sc.keys():
            L.operator("lmsp.build_library")
            return
        L.prop(sc, '["lmsp_mission_age"]', text="Mission Age (years)", slider=True)
        r = L.row(align=True)
        for y, t in ((0, "New"), (2, "2 Yr"), (5, "5 Yr"), (10, "10 Yr"), (20, "20 Yr")):
            r.operator("lmsp.set_age", text=t).years = y
        c = L.column(align=True)
        c.prop(sc, '["lmsp_dust_global"]', text="Dust Accumulation", slider=True)
        c.prop(sc, '["lmsp_wear_global"]', text="Paint Wear / Scratches", slider=True)
        c.prop(sc, '["lmsp_impact_global"]', text="Impact Damage", slider=True)
        c.prop(sc, '["lmsp_led_state"]', text="Fleet LED State (0-3)", slider=True)


class LMSP_PT_env(_Base, Panel):
    bl_label = "Lunar Environment Preview"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        c = self.layout.column(align=True)
        for key, lbl, _ in lighting.PRESET_ITEMS:
            c.operator("lmsp.environment", text=lbl).preset = key


class LMSP_PT_highlight(_Base, Panel):
    bl_label = "Material Assignment Preview"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        c = self.layout.column(align=True)
        for cat, lbl in (("Titanium", "Highlight Titanium Objects"), ("Carbon", "Highlight Carbon Objects"),
                         ("Glass", "Highlight Glass Objects"), ("Unassigned", "Highlight Unassigned Objects"),
                         ("Duplicate", "Highlight Duplicate Materials")):
            c.operator("lmsp.highlight", text=lbl).category = cat
        c.operator("lmsp.restore_shading", icon='LOOP_BACK')


class LMSP_PT_diag(_Base, Panel):
    bl_label = "Texture Diagnostics"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        L = self.layout
        L.operator("lmsp.texture_diagnostics", icon='VIEWZOOM')
        s = context.scene.lmsp
        if s.materials:
            ok = sum(1 for i in s.materials if i.status == "OK")
            warn = sum(1 for i in s.materials if i.status == "WARN")
            err = sum(1 for i in s.materials if i.status == "ERR")
            L.label(text="%d OK   %d warnings   %d errors" % (ok, warn, err))
            for i in s.materials:
                if i.status != "OK":
                    L.label(text="%s: %s" % (i.name.replace("PHMA_", ""), i.issues), icon='ERROR')


class LMSP_PT_render(_Base, Panel):
    bl_label = "Render Preview"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        L = self.layout
        c = L.column(align=True)
        for key, lbl, _ in render.PRESET_ITEMS:
            c.operator("lmsp.render_preset", text=lbl).preset = key
        L.operator("lmsp.render_now", icon='RENDER_STILL')


class LMSP_PT_analyzer(_Base, Panel):
    bl_label = "Cycles Quality Analyzer"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        L = self.layout
        s = context.scene.lmsp
        L.operator("lmsp.analyze_quality", icon='GRAPH')
        g = L.grid_flow(columns=1, align=True)
        g.label(text="Estimated Render Time: %.0f s / frame" % s.an_time)
        g.label(text="VRAM Usage (est.): %.2f GB" % s.an_vram)
        g.label(text="Texture Memory: %.0f MB" % s.an_tex)
        g.label(text="Triangles: {:,}".format(s.an_tris))
        g.label(text="Material Complexity Score: %.0f nodes avg" % s.an_complex)
        g.label(text="Optimization Score: %d / 100" % s.an_score, icon='CHECKMARK' if s.an_score >= 70 else 'ERROR')


class LMSP_PT_inspect(_Base, Panel):
    bl_label = "Asset Inspection"
    bl_parent_id = "LMSP_PT_main"

    def draw(self, context):
        L = self.layout
        ob = context.active_object
        if not ob:
            L.label(text="Select an object")
            return
        sc = context.scene
        mats = [sl.material for sl in ob.material_slots if sl.material]
        m = mats[0] if mats else None
        tex = sum(1 for n in m.node_tree.nodes if n.type == 'TEX_IMAGE') if m and m.node_tree else 0
        nodes = (len(m.node_tree.nodes) + sum(len(n.node_tree.nodes) for n in m.node_tree.nodes
                 if n.type == 'GROUP' and n.node_tree)) if m and m.node_tree else 0
        age = (ob["lmsp_age_ovr"] - 1) if ob.get("lmsp_age_ovr", 0) > 0.5 else sc.get("lmsp_mission_age", 0)
        b = L.box()
        b.label(text=ob.name, icon='OBJECT_DATA')
        b.label(text="Material: " + (m.name if m else "NONE"))
        b.label(text="Assigned by: " + str(ob.get("lmsp_assigned_by", "-")))
        b.label(text="Texture Count: %d   Node Count: %d" % (tex, nodes))
        if ob.type == 'MESH':
            b.label(text="Polygons: {:,}".format(len(ob.data.polygons)))
        b.label(text="LOD Level: %d" % ob.get("lmsp_lod", 0))
        b.label(text="Asset Age: %.1f years" % age)
        b.label(text="Exterior: %s   Dust x%.2f   Wear x%.2f" % ("yes" if ob.get("lmsp_exterior") else "no",
                                                                 ob.get("lmsp_dust", 1.0), ob.get("lmsp_wear", 1.0)))
        if "lmsp_spec" in ob.keys():
            b.label(text=str(ob["lmsp_spec"]), icon='INFO')


class LMSP_PT_compare(_Base, Panel):
    bl_label = "Cinematic Comparison"
    bl_parent_id = "LMSP_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        c = self.layout.column(align=True)
        c.operator("lmsp.build_comparison", icon='SPLIT_HORIZONTAL')
        c.operator("lmsp.clear_comparison", icon='TRASH')


class LMSP_PT_movie(_Base, Panel):
    bl_label = "Movie Production"
    bl_parent_id = "LMSP_PT_main"

    def draw(self, context):
        c = self.layout.column(align=True)
        for key, lbl, cam, env in SHOTS:
            c.operator("lmsp.movie_shot", text=lbl + " Preview", icon='CAMERA_DATA').shot = key


classes = (LMSP_MatItem, LMSP_Settings, LMSP_OT_build_library, LMSP_OT_auto_configure, LMSP_OT_assign, LMSP_OT_dust,
           LMSP_OT_wear, LMSP_OT_decals, LMSP_OT_validate, LMSP_OT_optimize, LMSP_OT_prepare, LMSP_OT_lods,
           LMSP_OT_refresh, LMSP_OT_preview, LMSP_OT_set_age, LMSP_OT_env, LMSP_OT_highlight, LMSP_OT_restore,
           LMSP_OT_diag, LMSP_OT_render_preset, LMSP_OT_render_now, LMSP_OT_analyze, LMSP_OT_compare,
           LMSP_OT_clear_compare, LMSP_OT_shot, LMSP_OT_select_users, LMSP_OT_export, LMSP_UL_materials,
           LMSP_PT_main, LMSP_PT_pipeline, LMSP_PT_browser, LMSP_PT_preview, LMSP_PT_aging, LMSP_PT_env,
           LMSP_PT_highlight, LMSP_PT_diag, LMSP_PT_render, LMSP_PT_analyzer, LMSP_PT_inspect, LMSP_PT_compare,
           LMSP_PT_movie)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.lmsp = PointerProperty(type=LMSP_Settings)


def unregister():
    del bpy.types.Scene.lmsp
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
