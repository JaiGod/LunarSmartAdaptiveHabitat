"""Lunar Material Studio Pro - core helpers (node builder, scene properties, drivers)."""
import bpy, math

AGE_PROP = "lmsp_mission_age"
LED_PROP = "lmsp_led_state"
SCENE_PROPS = {
    AGE_PROP: (3.5, 0.0, 20.0, "Mission age in years (0 = factory new)"),
    "lmsp_dust_global": (1.0, 0.0, 3.0, "Global lunar dust multiplier"),
    "lmsp_wear_global": (1.0, 0.0, 3.0, "Global wear/scratch multiplier"),
    "lmsp_impact_global": (1.0, 0.0, 3.0, "Global micrometeorite damage multiplier"),
    LED_PROP: (0.0, 0.0, 3.0, "Fleet LED state: 0 normal(blue) 1 active(green) 2 warning(yellow) 3 emergency(red)"),
}
PREFIX = "PHMA_"
WEATHER_GROUP = "LMSP_Weathering"


def main_scene():
    s = bpy.data.scenes.get("LSAH_Robotics")
    return s or bpy.context.scene


def ensure_scene_props(scene=None):
    scene = scene or main_scene()
    for k, (d, mn, mx, desc) in SCENE_PROPS.items():
        if k not in scene.keys():
            scene[k] = float(d)
        try:
            scene.id_properties_ui(k).update(min=mn, max=mx, soft_min=mn, soft_max=mx, description=desc)
        except Exception:
            pass
    return scene


def sock(coll, name, stype=None):
    for s in coll:
        if s.name == name and (stype is None or s.type == stype):
            return s
    raise KeyError(name)


def add_scene_driver(id_block, socket, prop, scene):
    fc = socket.driver_add("default_value")
    drv = fc.driver
    drv.type = 'AVERAGE'
    for v in list(drv.variables):
        drv.variables.remove(v)
    var = drv.variables.new()
    var.name = "v"
    var.type = 'SINGLE_PROP'
    t = var.targets[0]
    t.id_type = 'SCENE'
    t.id = scene
    t.data_path = '["%s"]' % prop
    return fc


class NB:
    """Small node-tree builder so every material is generated from Python."""

    def __init__(self, nt):
        self.nt = nt
        self.n = nt.nodes
        self.l = nt.links
        self._tc = None

    def new(self, t, x=0, y=0, label=None, **kw):
        nd = self.n.new(t)
        nd.location = (x, y)
        if label:
            nd.label = label
        for k, v in kw.items():
            setattr(nd, k, v)
        return nd

    def set(self, s, v):
        if v is None:
            return
        if isinstance(v, bpy.types.NodeSocket):
            self.l.new(v, s)
            return
        try:
            s.default_value = v
        except Exception:
            if isinstance(v, (int, float)):
                n = len(s.default_value)
                s.default_value = tuple([v] * n) if n != 4 else (v, v, v, 1.0)
            elif len(v) == 3:
                s.default_value = (v[0], v[1], v[2], 1.0)
            else:
                raise

    def tc(self):
        if self._tc is None:
            self._tc = self.new("ShaderNodeTexCoord", -1600, 0)
        return self._tc

    def value(self, v, x=0, y=0, label=None):
        nd = self.new("ShaderNodeValue", x, y, label=label)
        nd.outputs[0].default_value = v
        return nd.outputs[0]

    def rgb(self, c, x=0, y=0):
        nd = self.new("ShaderNodeRGB", x, y)
        nd.outputs[0].default_value = (c[0], c[1], c[2], 1.0)
        return nd.outputs[0]

    def math(self, op, a, b=None, c=None, x=0, y=0, clamp=False):
        nd = self.new("ShaderNodeMath", x, y, operation=op)
        nd.use_clamp = clamp
        self.set(nd.inputs[0], a)
        if b is not None:
            self.set(nd.inputs[1], b)
        if c is not None:
            self.set(nd.inputs[2], c)
        return nd.outputs[0]

    def vmath(self, op, a, b=None, x=0, y=0):
        nd = self.new("ShaderNodeVectorMath", x, y, operation=op)
        self.set(nd.inputs[0], a)
        if b is not None:
            self.set(nd.inputs[1], b)
        return nd.outputs["Value"] if op in ('DOT_PRODUCT', 'LENGTH', 'DISTANCE') else nd.outputs["Vector"]

    def mixf(self, f, a, b, x=0, y=0, clamp=True):
        nd = self.new("ShaderNodeMix", x, y, data_type='FLOAT')
        nd.clamp_factor = clamp
        self.set(sock(nd.inputs, "Factor", 'VALUE'), f)
        self.set(sock(nd.inputs, "A", 'VALUE'), a)
        self.set(sock(nd.inputs, "B", 'VALUE'), b)
        return sock(nd.outputs, "Result", 'VALUE')

    def mixc(self, f, a, b, blend='MIX', x=0, y=0):
        nd = self.new("ShaderNodeMix", x, y, data_type='RGBA', blend_type=blend)
        nd.clamp_factor = True
        self.set(sock(nd.inputs, "Factor", 'VALUE'), f)
        self.set(sock(nd.inputs, "A", 'RGBA'), a)
        self.set(sock(nd.inputs, "B", 'RGBA'), b)
        return sock(nd.outputs, "Result", 'RGBA')

    def mr(self, v, a, b, c=0.0, d=1.0, x=0, y=0, clamp=True, interp='LINEAR'):
        nd = self.new("ShaderNodeMapRange", x, y, interpolation_type=interp)
        nd.clamp = clamp
        self.set(sock(nd.inputs, "Value", 'VALUE'), v)
        self.set(sock(nd.inputs, "From Min", 'VALUE'), a)
        self.set(sock(nd.inputs, "From Max", 'VALUE'), b)
        self.set(sock(nd.inputs, "To Min", 'VALUE'), c)
        self.set(sock(nd.inputs, "To Max", 'VALUE'), d)
        return sock(nd.outputs, "Result", 'VALUE')

    def ramp(self, fac, stops, x=0, y=0, interp='LINEAR'):
        nd = self.new("ShaderNodeValToRGB", x, y)
        cr = nd.color_ramp
        cr.interpolation = interp
        els = cr.elements
        while len(els) > 1:
            els.remove(els[-1])
        els[0].position = stops[0][0]
        els[0].color = tuple(stops[0][1]) + ((1.0,) if len(stops[0][1]) == 3 else ())
        for pos, col in stops[1:]:
            e = els.new(pos)
            e.color = tuple(col) + ((1.0,) if len(col) == 3 else ())
        self.set(nd.inputs["Fac"], fac)
        return nd.outputs["Color"]

    def mapping(self, vec, scale=(1, 1, 1), rot=(0, 0, 0), loc=(0, 0, 0), x=0, y=0):
        nd = self.new("ShaderNodeMapping", x, y)
        self.set(nd.inputs["Vector"], vec)
        nd.inputs["Location"].default_value = loc
        nd.inputs["Rotation"].default_value = rot
        nd.inputs["Scale"].default_value = scale
        return nd.outputs["Vector"]

    def noise(self, vec, scale, detail=4.0, rough=0.5, dist=0.0, x=0, y=0):
        nd = self.new("ShaderNodeTexNoise", x, y)
        self.set(nd.inputs["Vector"], vec)
        nd.inputs["Scale"].default_value = scale
        nd.inputs["Detail"].default_value = detail
        nd.inputs["Roughness"].default_value = rough
        nd.inputs["Distortion"].default_value = dist
        return nd

    def voronoi(self, vec, scale, feature='F1', rand=1.0, x=0, y=0):
        nd = self.new("ShaderNodeTexVoronoi", x, y, feature=feature)
        self.set(nd.inputs["Vector"], vec)
        nd.inputs["Scale"].default_value = scale
        nd.inputs["Randomness"].default_value = rand
        return nd

    def wave(self, vec, scale, kind='BANDS', direction='X', dist=0.0, detail=2.0, x=0, y=0, profile='SIN'):
        nd = self.new("ShaderNodeTexWave", x, y, wave_type=kind, wave_profile=profile)
        if kind == 'BANDS':
            nd.bands_direction = direction
        else:
            nd.rings_direction = 'SPHERICAL' if direction == 'S' else direction
        self.set(nd.inputs["Vector"], vec)
        nd.inputs["Scale"].default_value = scale
        nd.inputs["Distortion"].default_value = dist
        nd.inputs["Detail"].default_value = detail
        return nd

    def bump(self, height, strength=0.3, distance=0.02, normal=None, x=0, y=0):
        nd = self.new("ShaderNodeBump", x, y)
        nd.inputs["Strength"].default_value = strength
        nd.inputs["Distance"].default_value = distance
        self.set(nd.inputs["Height"], height)
        if normal is not None:
            self.set(nd.inputs["Normal"], normal)
        return nd.outputs["Normal"]

    def sep(self, v, x=0, y=0):
        nd = self.new("ShaderNodeSeparateXYZ", x, y)
        self.set(nd.inputs[0], v)
        return nd

    def comb(self, a, b, c, x=0, y=0):
        nd = self.new("ShaderNodeCombineXYZ", x, y)
        self.set(nd.inputs[0], a)
        self.set(nd.inputs[1], b)
        self.set(nd.inputs[2], c)
        return nd.outputs[0]

    def attr(self, name, kind='OBJECT', x=0, y=0):
        nd = self.new("ShaderNodeAttribute", x, y, attribute_type=kind, attribute_name=name)
        return nd

    def cyl_uv(self, x=-1400, y=0, density=160.0):
        """Cylindrical (u around Z, v along Z) object-space coords, in metres*density."""
        o = self.tc().outputs["Object"]
        s = self.sep(o, x, y)
        ang = self.math('ARCTAN2', s.outputs[1], s.outputs[0], x=x + 180, y=y)
        rad = self.vmath('LENGTH', self.comb(s.outputs[0], s.outputs[1], 0.0, x + 180, y - 120), x=x + 360, y=y - 120)
        u = self.math('MULTIPLY', self.math('MULTIPLY', ang, rad, x=x + 540, y=y), density, x=x + 720, y=y)
        v = self.math('MULTIPLY', s.outputs[2], density, x=x + 540, y=y - 160)
        return u, v
