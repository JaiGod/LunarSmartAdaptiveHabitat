bl_info = {
    "name": "Lunar Material Studio Pro",
    "author": "Jaineil R. (Lunar Smart Adaptive Habitat) - generated with Claude",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar (N) > Lunar MSP",
    "description": "Procedural PBR material pipeline for the Lunar Smart Adaptive Habitat: auto-assignment, "
                   "mission aging, dust, wear, micrometeorite damage, decals, validation, LODs, baked GLB export",
    "category": "Material",
}
from . import core, materials, assign, decals, pipeline, lighting, render, preview, ui


def register():
    ui.register()


def unregister():
    ui.unregister()
