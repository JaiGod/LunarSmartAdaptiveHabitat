"""Procedural decals: NASA-style warning labels, asset IDs, serials, inspection stickers,
QR-style identification tags and docking targets, drawn into images with a built-in 5x7 font."""
import bpy, bmesh, zlib, random
import numpy as np
from mathutils import Vector, Matrix
from .core import WEATHER_GROUP, NB
from .materials import _weather, _start

G = {
 "A": ".###.|#...#|#...#|#####|#...#|#...#|#...#", "B": "####.|#...#|#...#|####.|#...#|#...#|####.",
 "C": ".###.|#...#|#....|#....|#....|#...#|.###.", "D": "####.|#...#|#...#|#...#|#...#|#...#|####.",
 "E": "#####|#....|#....|####.|#....|#....|#####", "F": "#####|#....|#....|####.|#....|#....|#....",
 "G": ".###.|#...#|#....|#.###|#...#|#...#|.####", "H": "#...#|#...#|#...#|#####|#...#|#...#|#...#",
 "I": ".###.|..#..|..#..|..#..|..#..|..#..|.###.", "J": "..###|...#.|...#.|...#.|...#.|#..#.|.##..",
 "K": "#...#|#..#.|#.#..|##...|#.#..|#..#.|#...#", "L": "#....|#....|#....|#....|#....|#....|#####",
 "M": "#...#|##.##|#.#.#|#.#.#|#...#|#...#|#...#", "N": "#...#|#...#|##..#|#.#.#|#..##|#...#|#...#",
 "O": ".###.|#...#|#...#|#...#|#...#|#...#|.###.", "P": "####.|#...#|#...#|####.|#....|#....|#....",
 "Q": ".###.|#...#|#...#|#...#|#.#.#|#..#.|.##.#", "R": "####.|#...#|#...#|####.|#.#..|#..#.|#...#",
 "S": ".####|#....|#....|.###.|....#|....#|####.", "T": "#####|..#..|..#..|..#..|..#..|..#..|..#..",
 "U": "#...#|#...#|#...#|#...#|#...#|#...#|.###.", "V": "#...#|#...#|#...#|#...#|#...#|.#.#.|..#..",
 "W": "#...#|#...#|#...#|#.#.#|#.#.#|#.#.#|.#.#.", "X": "#...#|#...#|.#.#.|..#..|.#.#.|#...#|#...#",
 "Y": "#...#|#...#|.#.#.|..#..|..#..|..#..|..#..", "Z": "#####|....#|...#.|..#..|.#...|#....|#####",
 "0": ".###.|#...#|#..##|#.#.#|##..#|#...#|.###.", "1": "..#..|.##..|..#..|..#..|..#..|..#..|.###.",
 "2": ".###.|#...#|....#|...#.|..#..|.#...|#####", "3": "#####|...#.|..#..|...#.|....#|#...#|.###.",
 "4": "...#.|..##.|.#.#.|#..#.|#####|...#.|...#.", "5": "#####|#....|####.|....#|....#|#...#|.###.",
 "6": "..##.|.#...|#....|####.|#...#|#...#|.###.", "7": "#####|....#|...#.|..#..|.#...|.#...|.#...",
 "8": ".###.|#...#|#...#|.###.|#...#|#...#|.###.", "9": ".###.|#...#|#...#|.####|....#|...#.|.##..",
 "-": ".....|.....|.....|#####|.....|.....|.....", ".": ".....|.....|.....|.....|.....|.##..|.##..",
 "/": "....#|....#|...#.|..#..|.#...|#....|#....", ":": ".....|.##..|.##..|.....|.##..|.##..|.....",
 "#": ".#.#.|.#.#.|#####|.#.#.|#####|.#.#.|.#.#.", "(": "...#.|..#..|.#...|.#...|.#...|..#..|...#.",
 ")": ".#...|..#..|...#.|...#.|...#.|..#..|.#...", "+": ".....|..#..|..#..|#####|..#..|..#..|.....",
 "%": "##..#|##..#|...#.|..#..|.#...|#..##|#..##", "!": "..#..|..#..|..#..|..#..|..#..|.....|..#..",
 " ": ".....|.....|.....|.....|.....|.....|.....",
}
GLYPH = {k: np.array([[c == "#" for c in row] for row in v.split("|")], dtype=bool) for k, v in G.items()}

BLACK = (0.02, 0.02, 0.02, 1.0)
WHITE = (0.92, 0.92, 0.9, 1.0)
YELLOW = (0.95, 0.72, 0.02, 1.0)
RED = (0.75, 0.04, 0.03, 1.0)
GREEN = (0.05, 0.5, 0.15, 1.0)
BLUE = (0.05, 0.25, 0.65, 1.0)
SILVER = (0.72, 0.73, 0.74, 1.0)


def text_width(text, s):
    return len(text) * 6 * s - s


def draw_text(img, text, x, y, s, col):
    H = img.shape[0]
    cx = x
    for ch in text.upper():
        g = GLYPH.get(ch, GLYPH[" "])
        for r in range(7):
            for c in range(5):
                if g[r, c]:
                    y0 = y + r * s
                    x0 = cx + c * s
                    img[y0:y0 + s, x0:x0 + s] = col
        cx += 6 * s


def fit_scale(lines, w, h, pad):
    s = 64
    while s > 1:
        tw = max(text_width(t, s) for t in lines)
        th = len(lines) * 9 * s
        if tw <= w - 2 * pad and th <= h - 2 * pad:
            return s
        s -= 1
    return 1


def rect(img, x0, y0, x1, y1, col):
    img[y0:y1, x0:x1] = col


def frame(img, t, col):
    img[:t, :] = col
    img[-t:, :] = col
    img[:, :t] = col
    img[:, -t:] = col


def label_image(name, kind, lines, w=1024, h=256):
    img = np.zeros((h, w, 4), dtype=np.float32)
    if kind == "warning":
        img[:] = YELLOW
        frame(img, h // 18, BLACK)
        tri = h // 2
        for i in range(tri):
            x0 = h // 6 + tri // 2 - i // 2
            img[h // 4 + i, x0:x0 + i + 1] = BLACK
        draw_text(img, "!", h // 6 + tri // 2 - 7, h // 4 + tri // 3, max(2, tri // 18), YELLOW)
        area_x = h // 6 + tri + h // 10
        s = fit_scale(lines, w - area_x, h, h // 10)
        y = (h - len(lines) * 9 * s) // 2
        for t in lines:
            draw_text(img, t, area_x, y, s, BLACK)
            y += 9 * s
    elif kind in ("danger", "override"):
        img[:] = RED
        frame(img, h // 18, YELLOW if kind == "override" else WHITE)
        s = fit_scale(lines, w, h, h // 8)
        y = (h - len(lines) * 9 * s) // 2
        for t in lines:
            draw_text(img, t, (w - text_width(t, s)) // 2, y, s, WHITE)
            y += 9 * s
    elif kind in ("inspect", "maint"):
        img[:] = WHITE
        hdr = GREEN if kind == "inspect" else BLUE
        rect(img, 0, 0, w, h // 3, hdr)
        frame(img, max(2, h // 40), BLACK)
        s0 = fit_scale([lines[0]], w, h // 3, h // 20)
        draw_text(img, lines[0], (w - text_width(lines[0], s0)) // 2, (h // 3 - 7 * s0) // 2, s0, WHITE)
        rest = lines[1:] or [" "]
        s = fit_scale(rest, w, h - h // 3, h // 14)
        y = h // 3 + (h - h // 3 - len(rest) * 9 * s) // 2
        for t in rest:
            draw_text(img, t, h // 14, y, s, BLACK)
            y += 9 * s
    elif kind == "hazard":
        img[:] = YELLOW
        yy, xx = np.mgrid[0:h, 0:w]
        img[((xx + yy) // (h // 3)) % 2 == 0] = BLACK
    elif kind == "target":
        img[:] = BLACK
        c = w // 2
        rect(img, c - w // 30, h // 10, c + w // 30, h - h // 10, WHITE)
        rect(img, w // 10, h // 2 - h // 30, w - w // 10, h // 2 + h // 30, WHITE)
        yy, xx = np.mgrid[0:h, 0:w]
        d = np.sqrt((xx - c) ** 2 + (yy - h // 2) ** 2)
        img[(d > h * 0.36) & (d < h * 0.42)] = WHITE
    else:  # plate / id
        img[:] = SILVER
        frame(img, max(2, h // 40), BLACK)
        s = fit_scale(lines, w, h, h // 10)
        y = (h - len(lines) * 9 * s) // 2
        for t in lines:
            draw_text(img, t, h // 10, y, s, BLACK)
            y += 9 * s
    return to_image(name, img)


def qr_matrix(payload, n=25):
    rng = random.Random(zlib.crc32(payload.encode()))
    M = np.array([[rng.random() < 0.5 for _ in range(n)] for _ in range(n)], dtype=bool)

    def finder(r0, c0):
        M[r0:r0 + 7, c0:c0 + 7] = False
        M[r0:r0 + 7, c0] = M[r0:r0 + 7, c0 + 6] = True
        M[r0, c0:c0 + 7] = M[r0 + 6, c0:c0 + 7] = True
        M[r0 + 2:r0 + 5, c0 + 2:c0 + 5] = True
    for (r, c) in ((0, 0), (0, n - 7), (n - 7, 0)):
        rs, cs = max(r - 1, 0), max(c - 1, 0)
        M[rs:r + 8, cs:c + 8] = False
        finder(r, c)
    for i in range(8, n - 8):
        M[6, i] = M[i, 6] = (i % 2 == 0)
    a = n - 7
    M[a - 2:a + 3, a - 2:a + 3] = True
    M[a - 1:a + 2, a - 1:a + 2] = False
    M[a, a] = True
    return M


def qr_image(name, payload, label, mod=12, n=25):
    M = qr_matrix(payload, n)
    q = 3
    side = (n + 2 * q) * mod
    th = 9 * 4 + 16
    img = np.zeros((side + th, side, 4), dtype=np.float32)
    img[:] = WHITE
    for r in range(n):
        for c in range(n):
            if M[r, c]:
                y0 = (r + q) * mod
                x0 = (c + q) * mod
                img[y0:y0 + mod, x0:x0 + mod] = BLACK
    s = fit_scale([label], side, th, 6)
    draw_text(img, label, (side - text_width(label, s)) // 2, side + (th - 7 * s) // 2 - 4, s, BLACK)
    frame(img, 3, BLACK)
    return to_image(name, img)


def to_image(name, arr):
    arr = np.flipud(arr).copy()
    h, w = arr.shape[:2]
    img = bpy.data.images.get(name)
    if img and (img.size[0] != w or img.size[1] != h):
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(name, w, h, alpha=True)
    img.pixels.foreach_set(arr.ravel())
    img.update()
    try:
        img.pack()
    except Exception:
        pass
    img["lmsp_decal"] = 1
    return img


def decal_material(img, rough=0.45, metallic=0.0):
    name = "PHMA_Decal_" + img.name.replace("IMG_", "")
    m = bpy.data.materials.get(name)
    if m:
        return m
    w, h = img.size
    m, nb, out = _start(name, "Decal", dict(base=(0.8, 0.8, 0.8), metal=metallic, rough=rough))
    tex = nb.new("ShaderNodeTexImage", -600, 0)
    tex.image = img
    tex.interpolation = 'Cubic'
    g = _weather(nb, tex.outputs["Color"], rough, metallic, (0.58, 0.6, 0.62), 1.0, dust=1.0, wear=1.2, impacts=0.6)
    bsdf = nb.new("ShaderNodeBsdfPrincipled", 1250, 0)
    for a, b in (("Color", "Base Color"), ("Roughness", "Roughness"), ("Metallic", "Metallic")):
        nb.l.new(g.outputs[a], bsdf.inputs[b])
    nb.l.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    nb.l.new(nb.bump(g.outputs["Height"], 0.3, 0.003, x=1000, y=-400), bsdf.inputs["Normal"])
    nb.l.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    m["lmsp_decal_image"] = img.name
    m["lmsp_rt_image"] = img.name
    m.use_fake_user = True
    return m


def asset_id(name):
    return "LSAH-%05d" % (zlib.crc32(name.encode()) % 100000)


def make_decal_object(target, mat, center, normal, up, w, h, tag):
    n = Vector(normal).normalized()
    u = Vector(up)
    u = (u - n * u.dot(n))
    if u.length < 1e-6:
        u = n.orthogonal()
    u.normalize()
    r = u.cross(n).normalized()
    c = Vector(center) + n * 0.0015
    me = bpy.data.meshes.new(target.name + "_Decal_" + tag)
    vs = [c - r * w / 2 - u * h / 2, c + r * w / 2 - u * h / 2, c + r * w / 2 + u * h / 2, c - r * w / 2 + u * h / 2]
    me.from_pydata([tuple(v) for v in vs], [], [(0, 1, 2, 3)])
    uvl = me.uv_layers.new(name="UVMap")
    for i, uv in enumerate(((0, 0), (1, 0), (1, 1), (0, 1))):
        uvl.data[i].uv = uv
    me.materials.append(mat)
    ob = bpy.data.objects.new(me.name, me)
    for col in target.users_collection:
        col.objects.link(ob)
    ob.parent = target
    ob.matrix_parent_inverse = Matrix.Identity(4)
    ob["lmsp_material"] = mat.name
    ob["lmsp_decal"] = 1
    for k in ("lmsp_exterior",):
        if k in target.keys():
            ob[k] = target[k]
    try:
        ob.visible_shadow = False
    except Exception:
        pass
    return ob


PRESETS = {
    "pinch": ("warning", ["CAUTION", "PINCH POINT"]),
    "nostep": ("warning", ["NO STEP"]),
    "hv": ("danger", ["DANGER", "120 VDC BUS"]),
    "override": ("override", ["EMERGENCY", "OVERRIDE"]),
    "lift": ("plate", ["LIFT POINT", "2500 KG LUNAR"]),
    "eva": ("warning", ["EVA HANDHOLD", "TETHER POINT"]),
    "laser": ("warning", ["LASER", "CLASS 4"]),
    "hazard": ("hazard", []),
    "target": ("target", []),
}


def preset_decal(target, key, center, normal, up, w, h, extra=None):
    kind, lines = PRESETS[key]
    lines = list(extra or lines)
    img = label_image("IMG_" + key + ("_" + "_".join(extra).replace(" ", "")[:24] if extra else ""), kind, lines,
                      1024, max(64, int(1024 * h / w)))
    return make_decal_object(target, decal_material(img), center, normal, up, w, h, key)


def id_plate(target, center, normal, up, w=0.16, h=0.05, title=None, sub=None):
    aid = asset_id(target.name)
    lines = [title or "PHMA-1", sub or ("SN " + aid)]
    img = label_image("IMG_plate_" + aid, "plate", lines, 1024, 320)
    return make_decal_object(target, decal_material(img, 0.3, 0.6), center, normal, up, w, h, "plate")


def inspection_sticker(target, center, normal, up, w=0.08, h=0.06, date="2031-03-14", maint=False):
    aid = asset_id(target.name)
    if maint:
        lines = ["MAINT DUE", date, "TORQUE 45 NM"]
    else:
        lines = ["INSPECTED", date, "BY LUNA-AI " + aid[-3:]]
    img = label_image("IMG_%s_%s" % ("maint" if maint else "insp", aid), "maint" if maint else "inspect", lines, 512, 384)
    return make_decal_object(target, decal_material(img, 0.4), center, normal, up, w, h, "maint" if maint else "insp")


def qr_tag(target, center, normal, up, size=0.06):
    aid = asset_id(target.name)
    img = qr_image("IMG_qr_" + aid, "https://lsah.local/asset/" + aid, aid)
    hh = size * img.size[1] / img.size[0]
    return make_decal_object(target, decal_material(img, 0.35), center, normal, up, size, hh, "qr")


def best_face(ob):
    """Largest roughly-flat, non-downward face in object space."""
    me = ob.data
    best = None
    for p in me.polygons:
        if p.normal.z < -0.5:
            continue
        if best is None or p.area > best.area:
            best = p
    return best


def auto_decals(objs, max_per_object=1):
    made = 0
    for ob in objs:
        if ob.type != 'MESH' or ob.get("lmsp_decal") or ob.get("lmsp_preview") or ob.get("lmsp_has_decal"):
            continue
        p = best_face(ob)
        if p is None or p.area < 0.002:
            continue
        verts = [ob.data.vertices[i].co for i in p.vertices]
        edges = [(verts[(i + 1) % len(verts)] - verts[i]) for i in range(len(verts))]
        up = max(edges, key=lambda e: e.length)
        size = max(0.04, min(0.18, (p.area ** 0.5) * 0.45))
        toks = ob.name.lower()
        if any(t in toks for t in ("sensor", "camera", "lidar", "scanner")):
            qr_tag(ob, p.center, p.normal, up, size)
        elif any(t in toks for t in ("panel", "access", "hatch", "avionics", "box")):
            inspection_sticker(ob, p.center, p.normal, up, size, size * 0.75, maint=True)
        else:
            id_plate(ob, p.center, p.normal, up, size * 1.6, size * 0.5)
        ob["lmsp_has_decal"] = 1
        made += 1
    return made
