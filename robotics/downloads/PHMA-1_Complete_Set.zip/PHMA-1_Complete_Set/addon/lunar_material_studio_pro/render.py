"""Render presets + Cycles quality analyser."""
import bpy, math

PRESETS = {
    'QUICK': dict(samples=32, res=(1920, 1080), pct=50, thr=0.05, bounces=6, label="Quick Preview"),
    'HD': dict(samples=256, res=(1920, 1080), pct=100, thr=0.02, bounces=8, label="HD Preview"),
    'MOVIE_CLOSEUP': dict(samples=1024, res=(1920, 1080), pct=100, thr=0.01, bounces=12, label="Movie Closeup"),
    'POSTER': dict(samples=1024, res=(2160, 3840), pct=100, thr=0.01, bounces=12, label="Poster Render"),
    'HERO': dict(samples=1024, res=(3840, 1608), pct=100, thr=0.01, bounces=12, label="Hero Shot (2.39:1 4K)"),
}
PRESET_ITEMS = [(k, v["label"], "") for k, v in PRESETS.items()]


def enable_gpu():
    try:
        prefs = bpy.context.preferences.addons['cycles'].preferences
        for t in ('OPTIX', 'CUDA', 'HIP', 'METAL', 'ONEAPI'):
            try:
                prefs.compute_device_type = t
                prefs.refresh_devices()
                gpus = [d for d in prefs.devices if d.type == t]
                if gpus:
                    for d in prefs.devices:
                        d.use = (d.type == t)
                    return t
            except Exception:
                continue
    except Exception:
        pass
    return None


def apply_render_preset(scene, key):
    p = PRESETS[key]
    scene.render.engine = 'CYCLES'
    c = scene.cycles
    if enable_gpu():
        c.device = 'GPU'
    c.samples = p["samples"]
    c.use_adaptive_sampling = True
    c.adaptive_threshold = p["thr"]
    c.use_denoising = True
    try:
        c.denoiser = 'OPENIMAGEDENOISE'
    except Exception:
        pass
    c.max_bounces = p["bounces"]
    c.diffuse_bounces = min(4, p["bounces"])
    c.glossy_bounces = min(6, p["bounces"])
    c.transmission_bounces = p["bounces"]
    c.volume_bounces = 4
    c.transparent_max_bounces = 16
    c.caustics_reflective = False
    c.caustics_refractive = False
    scene.render.resolution_x, scene.render.resolution_y = p["res"]
    scene.render.resolution_percentage = p["pct"]
    scene.render.use_persistent_data = False  # see pipeline.optimize_for_rendering
    scene.render.use_motion_blur = key in ('MOVIE_CLOSEUP', 'HERO')
    scene["lmsp_render_preset"] = key
    return p["label"]


def analyze(scene):
    tris, objs, mats = 0, 0, set()
    seen = set()
    for ob in scene.objects:
        if ob.type != 'MESH' or ob.hide_render:
            continue
        objs += 1
        if ob.data.name not in seen:
            seen.add(ob.data.name)
            tris += sum(len(p.vertices) - 2 for p in ob.data.polygons)
        for s in ob.material_slots:
            if s.material:
                mats.add(s.material)
    tex_bytes = 0
    for img in bpy.data.images:
        if img.users and img.size[0]:
            tex_bytes += img.size[0] * img.size[1] * 4 * (2 if img.is_float else 1) * 1.33
    nodes = [len(m.node_tree.nodes) + sum(len(n.node_tree.nodes) for n in m.node_tree.nodes
             if n.type == 'GROUP' and n.node_tree) for m in mats if m.node_tree]
    cx = (sum(nodes) / len(nodes)) if nodes else 0
    c = scene.cycles
    px = scene.render.resolution_x * scene.render.resolution_y * (scene.render.resolution_percentage / 100) ** 2
    spp = c.samples * (0.55 if c.use_adaptive_sampling else 1.0)
    gpu = c.device == 'GPU'
    complexity = 1.0 + math.log10(max(tris, 1000) / 1000) * 0.35 + cx / 400.0
    est = px * spp * (0.6 + c.max_bounces / 20) * complexity * (1.1e-9 if gpu else 1.4e-8)
    vram = 0.55e9 + tris * 140 + tex_bytes + len(mats) * 2e5
    score = 100
    score -= min(25, max(0, (tris - 2e6) / 2e5))
    score -= min(20, max(0, (cx - 120) / 10))
    score -= 10 if not c.use_adaptive_sampling else 0
    score -= 10 if not c.use_denoising else 0
    score -= 10 if (c.caustics_reflective or c.caustics_refractive) else 0
    score -= 10 if not gpu else 0
    return {"est_seconds": est, "vram_gb": vram / 1e9, "tex_mb": tex_bytes / 1e6, "tris": tris, "objects": objs,
            "materials": len(mats), "complexity": round(cx, 1), "score": max(0, int(score))}
