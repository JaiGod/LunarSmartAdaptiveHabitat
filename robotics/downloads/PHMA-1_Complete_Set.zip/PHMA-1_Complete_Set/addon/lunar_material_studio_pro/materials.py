"""Lunar Material Studio Pro - procedural PBR material library.

Every material is generated from bpy node trees. All weathering (dust, wear,
scratches, micrometeorite pitting, heat discoloration) runs through one shared
node group, LMSP_Weathering, whose MissionAge value is driven by the scene
property lmsp_mission_age (0-20 years). Per-object overrides:
    obj["lmsp_age_ovr"]  = age + 1   (0/absent = use scene age)
    obj["lmsp_dust"]     = dust multiplier   (absent = 1)
    obj["lmsp_wear"]     = wear multiplier   (absent = 1)
    obj["lmsp_exterior"] = 1 for vacuum-exposed parts (impacts + full dust)
"""
import bpy, math
from .core import (NB, sock, add_scene_driver, ensure_scene_props, main_scene,
                   AGE_PROP, LED_PROP, WEATHER_GROUP)

DUST_RGB = (0.42, 0.42, 0.40)
LED_RGB = {"Blue": (0.05, 0.3, 1.0), "Green": (0.05, 1.0, 0.2),
           "Yellow": (1.0, 0.75, 0.05), "Red": (1.0, 0.05, 0.03)}


def _iface(ng, name, io, stype, default=None):
    it = ng.interface.new_socket(name=name, in_out=io, socket_type=stype)
    if default is not None:
        try:
            it.default_value = default
        except Exception:
            pass
    return it


def build_weathering_group(scene=None):
    scene = ensure_scene_props(scene)
    old = bpy.data.node_groups.get(WEATHER_GROUP)
    if old:
        bpy.data.node_groups.remove(old)
    ng = bpy.data.node_groups.new(WEATHER_GROUP, 'ShaderNodeTree')
    for n, t, d in (("Color", 'NodeSocketColor', (0.5, 0.5, 0.5, 1)), ("Roughness", 'NodeSocketFloat', 0.4),
                    ("Metallic", 'NodeSocketFloat', 0.0), ("Wear Color", 'NodeSocketColor', (0.6, 0.6, 0.62, 1)),
                    ("Wear Metallic", 'NodeSocketFloat', 1.0), ("Dust", 'NodeSocketFloat', 1.0),
                    ("Wear", 'NodeSocketFloat', 1.0), ("Impacts", 'NodeSocketFloat', 1.0),
                    ("Heat", 'NodeSocketFloat', 0.0), ("Exterior", 'NodeSocketFloat', 0.0)):
        _iface(ng, n, 'INPUT', t, d)
    for n, t in (("Color", 'NodeSocketColor'), ("Roughness", 'NodeSocketFloat'), ("Metallic", 'NodeSocketFloat'),
                 ("Height", 'NodeSocketFloat'), ("Dust Mask", 'NodeSocketFloat'), ("Wear Mask", 'NodeSocketFloat')):
        _iface(ng, n, 'OUTPUT', t)
    nb = NB(ng)
    gi = nb.new("NodeGroupInput", -2600, 0)
    go = nb.new("NodeGroupOutput", 2600, 0)
    I = lambda n: gi.outputs[n]
    # ---- global drivers -------------------------------------------------
    age_g = nb.value(3.5, -2600, 900, "MissionAge")
    add_scene_driver(ng, age_g, AGE_PROP, scene)
    dust_g = nb.value(1.0, -2600, 1000, "DustGlobal")
    add_scene_driver(ng, dust_g, "lmsp_dust_global", scene)
    wear_g = nb.value(1.0, -2600, 1100, "WearGlobal")
    add_scene_driver(ng, wear_g, "lmsp_wear_global", scene)
    imp_g = nb.value(1.0, -2600, 1200, "ImpactGlobal")
    add_scene_driver(ng, imp_g, "lmsp_impact_global", scene)
    # ---- per-object overrides -------------------------------------------
    ovr = nb.attr("lmsp_age_ovr", 'OBJECT', -2600, 1400).outputs["Fac"]
    age = nb.mixf(nb.math('GREATER_THAN', ovr, 0.5, x=-2400, y=1400), age_g,
                  nb.math('SUBTRACT', ovr, 1.0, x=-2400, y=1300), -2200, 1300)

    def objk(name, y):
        a = nb.attr(name, 'OBJECT', -2600, y).outputs["Fac"]
        return nb.mixf(nb.math('GREATER_THAN', a, 0.0001, x=-2400, y=y), 1.0, a, -2200, y)
    dust_k = objk("lmsp_dust", 1600)
    wear_k = objk("lmsp_wear", 1700)
    ext = nb.math('MAXIMUM', I("Exterior"), nb.attr("lmsp_exterior", 'OBJECT', -2600, 1800).outputs["Fac"],
                  x=-2400, y=1800)
    # ---- amounts vs mission age -------------------------------------------
    dust_amt = nb.math('POWER', nb.mr(age, 0.0, 8.0, x=-2000, y=1300), 0.7, x=-1850, y=1300)
    dust_amt = nb.math('MULTIPLY', dust_amt, nb.math('MULTIPLY', I("Dust"), dust_k, x=-1850, y=1450), x=-1700, y=1300)
    dust_amt = nb.math('MULTIPLY', dust_amt, dust_g, x=-1550, y=1300)
    dust_amt = nb.math('MULTIPLY', dust_amt, nb.math('MULTIPLY_ADD', ext, 0.7, 0.3, x=-1550, y=1450), x=-1400, y=1300)
    wear_amt = nb.mr(age, 0.0, 12.0, x=-2000, y=1150)
    wear_amt = nb.math('MULTIPLY', wear_amt, nb.math('MULTIPLY', I("Wear"), wear_k, x=-1850, y=1100), x=-1700, y=1150)
    wear_amt = nb.math('MULTIPLY', wear_amt, wear_g, x=-1550, y=1150)
    imp_amt = nb.mr(age, 0.0, 20.0, x=-2000, y=1000)
    imp_amt = nb.math('MULTIPLY', imp_amt, nb.math('MULTIPLY', I("Impacts"), imp_g, x=-1850, y=950), x=-1700, y=1000)
    imp_amt = nb.math('MULTIPLY', imp_amt, ext, x=-1550, y=1000)
    heat_amt = nb.math('MULTIPLY', nb.mr(age, 0.0, 10.0, x=-2000, y=850), I("Heat"), x=-1700, y=850)
    obj = nb.tc().outputs["Object"]
    geo = nb.new("ShaderNodeNewGeometry", -2200, -200)
    # ---- dust mask: up-facing (>20 deg) + crevices (AO), patchy, powdery edge
    nz = nb.sep(geo.outputs["Normal"], -2000, -200).outputs[2]
    up = nb.mr(nz, 0.34, 0.9, x=-1800, y=-200)
    ao = nb.new("ShaderNodeAmbientOcclusion", -2000, -420, samples=8)
    ao.inputs["Distance"].default_value = 0.25
    crev = nb.math('MULTIPLY', nb.math('SUBTRACT', 1.0, ao.outputs["AO"], x=-1800, y=-420), 0.85, x=-1650, y=-420)
    patch = nb.mr(nb.noise(obj, 2.2, 6, 0.6, x=-2000, y=-640).outputs["Fac"], 0.38, 0.68, 0.25, 1.0, -1800, -640)
    grain = nb.noise(obj, 90.0, 3, 0.6, x=-2000, y=-860).outputs["Fac"]
    concave = nb.math('MULTIPLY', nb.mr(geo.outputs["Pointiness"], 0.5, 0.42, x=-1700, y=-520), 0.3, x=-1550, y=-520)
    dbase = nb.math('MAXIMUM', nb.math('MAXIMUM', up, crev, x=-1500, y=-300), concave, x=-1400, y=-400)
    draw = nb.math('MULTIPLY', nb.math('MULTIPLY', dbase, patch, x=-1350, y=-300), dust_amt, x=-1200, y=-300)
    draw = nb.math('MULTIPLY_ADD', nb.math('SUBTRACT', grain, 0.5, x=-1350, y=-860), 0.35, draw, x=-1050, y=-300)
    dmask = nb.mr(draw, 0.16, 0.55, x=-900, y=-300)
    # ---- edge wear (pointiness + bevel curvature), abrasion, scratches -----
    pt = nb.mr(geo.outputs["Pointiness"], 0.5, 0.58, x=-1800, y=-1100)
    bev = nb.new("ShaderNodeBevel", -2000, -1250, samples=6)
    bev.inputs["Radius"].default_value = 0.012
    dot = nb.vmath('DOT_PRODUCT', bev.outputs["Normal"], geo.outputs["Normal"], x=-1800, y=-1250)
    # Bevel-normal curvature works on any mesh density; Pointiness only feeds concave dust (low-poly safe)
    edge = nb.mr(dot, 0.985, 0.85, x=-1650, y=-1250)
    wn = nb.mr(nb.noise(obj, 9.0, 8, 0.7, x=-1800, y=-1450).outputs["Fac"], 0.42, 0.68, x=-1650, y=-1450)
    chips = nb.math('MULTIPLY', nb.math('MULTIPLY', edge, wn, x=-1350, y=-1200),
                    nb.math('MULTIPLY', wear_amt, 1.7, x=-1350, y=-1350), x=-1200, y=-1200, clamp=True)
    abr = nb.math('MULTIPLY', nb.mr(nb.noise(obj, 1.3, 4, x=-1800, y=-1650).outputs["Fac"], 0.55, 0.8, x=-1650, y=-1650),
                  wear_amt, x=-1500, y=-1650)
    s1 = nb.mr(nb.wave(obj, 18.0, 'BANDS', 'X', dist=14.0, detail=3, x=-1800, y=-1850).outputs["Fac"], 0.965, 1.0, x=-1650, y=-1850)
    s2 = nb.mr(nb.wave(nb.mapping(obj, rot=(0.4, 0.9, 0.7), x=-2000, y=-2050), 23.0, 'BANDS', 'Y', dist=11.0, detail=3,
                       x=-1800, y=-2050).outputs["Fac"], 0.97, 1.0, x=-1650, y=-2050)
    smask = nb.mr(nb.noise(obj, 4.0, 3, x=-1800, y=-2250).outputs["Fac"], 0.5, 0.72, x=-1650, y=-2250)
    scratch = nb.math('MULTIPLY', nb.math('MULTIPLY', nb.math('MAXIMUM', s1, s2, x=-1500, y=-1950), smask, x=-1350, y=-1950),
                      wear_amt, x=-1200, y=-1950, clamp=True)

    # ---- micrometeorite impacts: 85% small / 14% medium / 1% major ---------
    def crater(scale, prob, rad, depth, x, y):
        v = nb.voronoi(obj, scale, 'F1', 1.0, x, y)
        r = nb.sep(v.outputs["Color"], x + 180, y).outputs[0]
        active = nb.math('LESS_THAN', r, nb.math('MULTIPLY', imp_amt, prob, x=x + 180, y=y - 120), x=x + 360, y=y)
        d = v.outputs["Distance"]
        pit = nb.mr(d, rad * 0.15, rad, 1.0, 0.0, x + 360, y - 150)
        rim = nb.math('MULTIPLY', nb.mr(d, rad * 0.8, rad, x=x + 360, y=y - 300),
                      nb.mr(d, rad, rad * 1.6, 1.0, 0.0, x + 360, y - 450), x=x + 540, y=y - 300)
        burn = nb.math('MULTIPLY', nb.mr(d, rad, rad * 2.4, 1.0, 0.0, x + 360, y - 600), active, x=x + 540, y=y - 600)
        h = nb.math('MULTIPLY', nb.math('MULTIPLY_ADD', rim, 0.35, nb.math('MULTIPLY', pit, -1.0, x=x + 540, y=y - 150),
                                        x=x + 720, y=y - 200), nb.math('MULTIPLY', active, depth, x=x + 540, y=y), x=x + 900, y=y)
        return h, burn
    h1, b1 = crater(40.0, 0.90, 0.09, 1.0, -1900, -2500)
    h2, b2 = crater(10.0, 0.16, 0.12, 2.0, -1900, -3200)
    h3, b3 = crater(2.5, 0.012, 0.15, 4.0, -1900, -3900)
    fr = nb.voronoi(obj, 55.0, 'DISTANCE_TO_EDGE', 1.0, -1900, -4600)
    fract = nb.math('MULTIPLY', nb.mr(fr.outputs["Distance"], 0.0, 0.025, 1.0, 0.0, -1700, -4600), b3, x=-1500, y=-4600)
    imp_h = nb.math('ADD', nb.math('ADD', h1, h2, x=-800, y=-2800), h3, x=-650, y=-2800)
    burn = nb.math('MINIMUM', nb.math('ADD', nb.math('ADD', b1, b2, x=-800, y=-3000), b3, x=-650, y=-3000), 1.0, x=-500, y=-3000)
    # ---- heat discoloration (titanium oxide straw -> violet -> blue) -------
    hmask = nb.math('MULTIPLY', nb.mr(nb.noise(obj, 1.6, 5, x=-1800, y=300).outputs["Fac"], 0.5, 0.78, x=-1600, y=300),
                    heat_amt, x=-1400, y=300)
    tint = nb.ramp(nb.noise(obj, 0.8, 3, x=-1800, y=500).outputs["Fac"],
                   [(0.3, (0.62, 0.47, 0.22)), (0.55, (0.42, 0.30, 0.45)), (0.8, (0.32, 0.42, 0.62))], -1600, 500)
    # ---- compose ---------------------------------------------------------
    c1 = nb.mixc(nb.math('MULTIPLY', hmask, 0.55, x=-200, y=300), I("Color"), tint, x=0, y=300)
    c2 = nb.mixc(chips, c1, I("Wear Color"), x=200, y=300)
    c3 = nb.mixc(nb.math('MULTIPLY', burn, 0.85, x=200, y=100), c2, (0.08, 0.075, 0.07), x=400, y=300)
    c3 = nb.mixc(nb.math('MULTIPLY', fract, 0.9, x=400, y=100), c3, (0.03, 0.03, 0.03), x=600, y=300)
    dcol = nb.mixc(grain, (0.35, 0.35, 0.33), (0.48, 0.48, 0.46), x=600, y=100)
    c4 = nb.mixc(dmask, c3, dcol, x=800, y=300)
    r_in = I("Roughness")
    r1 = nb.mixf(chips, r_in, nb.math('MULTIPLY', r_in, 0.55, x=200, y=-100), x=400, y=-100)
    r1 = nb.math('MULTIPLY_ADD', scratch, 0.12, r1, x=600, y=-100)
    r1 = nb.math('MULTIPLY_ADD', abr, -0.08, r1, x=800, y=-100, clamp=True)
    r1 = nb.math('MULTIPLY_ADD', burn, 0.3, r1, x=950, y=-100, clamp=True)
    r2 = nb.mixf(dmask, r1, 0.96, x=1100, y=-100)
    m1 = nb.mixf(chips, I("Metallic"), I("Wear Metallic"), x=400, y=-300)
    m1 = nb.math('MULTIPLY', m1, nb.math('SUBTRACT', 1.0, nb.math('MULTIPLY', burn, 0.6, x=500, y=-450), x=650, y=-450), x=800, y=-300)
    m2 = nb.math('MULTIPLY', m1, nb.math('SUBTRACT', 1.0, dmask, x=950, y=-450), x=1100, y=-300)
    hh = nb.math('MULTIPLY_ADD', scratch, -0.25, imp_h, x=900, y=-600)
    hh = nb.math('MULTIPLY_ADD', fract, -0.5, hh, x=1050, y=-600)
    hh = nb.math('MULTIPLY_ADD', dmask, 0.15, hh, x=1200, y=-600)
    nb.l.new(c4, go.inputs["Color"])
    nb.l.new(r2, go.inputs["Roughness"])
    nb.l.new(m2, go.inputs["Metallic"])
    nb.l.new(hh, go.inputs["Height"])
    nb.l.new(dmask, go.inputs["Dust Mask"])
    nb.l.new(chips, go.inputs["Wear Mask"])
    return ng


# =========================================================================
# material helpers
# =========================================================================
def _start(name, mtype, rt):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    m.node_tree.nodes.clear()
    if m.node_tree.animation_data:
        m.node_tree.animation_data_clear()
    base = tuple(rt.get("base", (0.5, 0.5, 0.5)))
    m["lmsp_type"] = mtype
    m["lmsp_generated"] = 1
    m["lmsp_rt_base"] = list(base)
    m["lmsp_rt_metal"] = float(rt.get("metal", 0.0))
    m["lmsp_rt_rough"] = float(rt.get("rough", 0.5))
    m["lmsp_rt_emit"] = list(rt.get("emit", (0.0, 0.0, 0.0)))
    m["lmsp_rt_emit_strength"] = float(rt.get("es", 0.0))
    m["lmsp_rt_alpha"] = float(rt.get("alpha", 1.0))
    m["lmsp_rt_transmission"] = float(rt.get("trans", 0.0))
    m.diffuse_color = (base[0], base[1], base[2], rt.get("alpha", 1.0))
    m.metallic = float(rt.get("metal", 0.0))
    m.roughness = float(rt.get("rough", 0.5))
    nb = NB(m.node_tree)
    out = nb.new("ShaderNodeOutputMaterial", 1700, 0)
    return m, nb, out


def _weather(nb, color, rough, metal, wear_color, wear_metal=1.0, dust=1.0, wear=1.0, impacts=1.0,
             heat=0.0, exterior=0.0, x=500, y=0):
    g = nb.new("ShaderNodeGroup", x, y)
    g.node_tree = bpy.data.node_groups[WEATHER_GROUP]
    for k, v in (("Color", color), ("Roughness", rough), ("Metallic", metal), ("Wear Color", wear_color),
                 ("Wear Metallic", wear_metal), ("Dust", dust), ("Wear", wear), ("Impacts", impacts),
                 ("Heat", heat), ("Exterior", exterior)):
        nb.set(g.inputs[k], v)
    return g


def _set_bsdf(nb, bsdf, vals):
    for k, v in (vals or {}).items():
        try:
            nb.set(bsdf.inputs[k], v)
        except Exception:
            pass


def _finish(nb, out, g, own_height=None, strength=0.25, dist=0.01, vals=None, tangent_z=False):
    bsdf = nb.new("ShaderNodeBsdfPrincipled", 1250, 0)
    nb.l.new(g.outputs["Color"], bsdf.inputs["Base Color"])
    nb.l.new(g.outputs["Roughness"], bsdf.inputs["Roughness"])
    nb.l.new(g.outputs["Metallic"], bsdf.inputs["Metallic"])
    n1 = nb.bump(own_height, strength, dist, x=900, y=-500) if own_height is not None else None
    n2 = nb.bump(g.outputs["Height"], 0.35, 0.004, normal=n1, x=1050, y=-500)
    nb.l.new(n2, bsdf.inputs["Normal"])
    _set_bsdf(nb, bsdf, vals)
    if tangent_z:
        tan = nb.new("ShaderNodeTangent", 1050, -750, direction_type='RADIAL', axis='Z')
        nb.l.new(tan.outputs["Tangent"], bsdf.inputs["Tangent"])
    nb.l.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return bsdf


def _plain(nb, out, vals, height=None, strength=0.2, dist=0.01):
    bsdf = nb.new("ShaderNodeBsdfPrincipled", 1250, 0)
    _set_bsdf(nb, bsdf, vals)
    if height is not None:
        nb.l.new(nb.bump(height, strength, dist, x=1000, y=-500), bsdf.inputs["Normal"])
    nb.l.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return bsdf


def _dim(c, k):
    return (c[0] * k, c[1] * k, c[2] * k)


# =========================================================================
# 1. Titanium structural frame (Ti-6Al-4V)
# =========================================================================
def mat_titanium(name="PHMA_Titanium", base=(0.58, 0.60, 0.62), rough=0.22, exterior=0.0):
    m, nb, out = _start(name, "Metal", dict(base=base, metal=1.0, rough=rough))
    o = nb.tc().outputs["Object"]
    brush = nb.noise(nb.mapping(o, scale=(320, 320, 2.5), x=-1200, y=400), 1.0, 3, 0.5, x=-1000, y=400).outputs["Fac"]
    var = nb.noise(o, 3.5, 4, x=-1000, y=200).outputs["Fac"]
    col = nb.mixc(nb.math('MULTIPLY', var, 0.3, x=-800, y=200), base, _dim(base, 0.82), x=-600, y=200)
    r = nb.math('MULTIPLY', rough, nb.mr(var, 0.3, 0.7, 0.8, 1.25, -800, 0), x=-600, y=0)
    mach = nb.wave(o, 140.0, 'RINGS', 'Z', dist=0.3, detail=1, x=-1000, y=-200).outputs["Fac"]
    h = nb.math('MULTIPLY_ADD', mach, 0.12, nb.math('MULTIPLY', brush, 0.6, x=-800, y=400), x=-600, y=400)
    g = _weather(nb, col, r, 1.0, (0.78, 0.79, 0.80), 1.0, dust=1.0, wear=1.0, impacts=1.0, heat=1.0, exterior=exterior)
    _finish(nb, out, g, h, 0.12, 0.002, {"Anisotropic": 0.4, "Specular IOR Level": 0.5,
                                        "Coat Weight": 0.1, "Coat Roughness": 0.05}, tangent_z=True)
    return m


# =========================================================================
# 2. Carbon fiber (aerospace CFRP, 2x2 twill, directional anisotropy)
# =========================================================================
def mat_carbon(name="PHMA_CarbonFiber"):
    m, nb, out = _start(name, "Composite", dict(base=(0.04, 0.04, 0.04), metal=0.0, rough=0.35))
    u, v = nb.cyl_uv(-1500, 300, density=1.0)
    wn = nb.noise(nb.tc().outputs["Object"], 2.0, 3, x=-1300, y=650).outputs["Fac"]
    N = 150.0
    uu = nb.math('MULTIPLY', nb.math('MULTIPLY_ADD', nb.math('SUBTRACT', wn, 0.5, x=-1100, y=650), 0.004, u, x=-950, y=500),
                 N, x=-800, y=500)
    vv = nb.math('MULTIPLY', v, N, x=-800, y=300)
    s = nb.math('FLOORED_MODULO', nb.math('ADD', nb.math('FLOOR', uu, x=-650, y=500), nb.math('FLOOR', vv, x=-650, y=300),
                                          x=-500, y=400), 4.0, x=-350, y=400)
    orient = nb.math('LESS_THAN', s, 2.0, x=-200, y=400)
    across = nb.mixf(orient, nb.math('FRACT', vv, x=-500, y=200), nb.math('FRACT', uu, x=-500, y=100), x=-200, y=200)
    crown = nb.math('SINE', nb.math('MULTIPLY', across, math.pi, x=-50, y=200), x=100, y=200)
    resin = nb.mr(nb.noise(nb.tc().outputs["Object"], 12.0, 5, x=-500, y=-100).outputs["Fac"], 0.55, 0.75, x=-300, y=-100)
    col = nb.mixc(nb.math('MULTIPLY_ADD', orient, 0.35, nb.math('MULTIPLY', crown, 0.3, x=250, y=150), x=400, y=200),
                  (0.03, 0.03, 0.032), (0.065, 0.065, 0.07), x=600, y=300)
    rough = nb.math('MULTIPLY_ADD', resin, -0.15, nb.math('MULTIPLY_ADD', crown, -0.1, 0.42, x=250, y=0), x=400, y=0, clamp=True)
    g = _weather(nb, col, rough, 0.0, (0.13, 0.13, 0.13), 0.0, dust=1.0, wear=0.7, impacts=1.0, heat=0.0)
    bsdf = _finish(nb, out, g, crown, 0.2, 0.0015, {"Anisotropic": 0.6, "Specular IOR Level": 0.65,
                                                    "Coat Weight": 1.0, "Coat Roughness": 0.03}, tangent_z=True)
    nb.l.new(nb.math('MULTIPLY', orient, 0.25, x=900, y=-900), bsdf.inputs["Anisotropic Rotation"])
    return m


# =========================================================================
# 3. Transparent sensor covers + coated lens elements
# =========================================================================
def mat_glass(name="PHMA_OpticalGlass"):
    m, nb, out = _start(name, "Optical", dict(base=(0.9, 0.95, 1.0), metal=0.0, rough=0.02, alpha=0.25, trans=1.0))
    o = nb.tc().outputs["Object"]
    smudge = nb.mr(nb.noise(o, 6.0, 5, 0.65, x=-800, y=0).outputs["Fac"], 0.5, 0.75, 0.02, 0.14, -600, 0)
    g = _weather(nb, (1, 1, 1), smudge, 0.0, (1, 1, 1), 0.0, dust=0.6, wear=0.5, impacts=1.0)
    _finish(nb, out, g, None, vals={"Transmission Weight": 1.0, "IOR": 1.46, "Coat Weight": 1.0,
                                    "Specular IOR Level": 0.5, "Thin Film Thickness": 110.0, "Thin Film IOR": 1.38})
    for attr, val in (("use_raytrace_refraction", True), ("use_transparency_overlap", False)):
        try:
            setattr(m, attr, val)
        except Exception:
            pass
    return m


def mat_lens(name="PHMA_LensOptic"):
    m, nb, out = _start(name, "Optical", dict(base=(0.01, 0.01, 0.015), metal=0.0, rough=0.03))
    _plain(nb, out, {"Base Color": (0.005, 0.005, 0.008), "Roughness": 0.03, "Coat Weight": 1.0,
                     "Specular IOR Level": 1.0, "Thin Film Thickness": 380.0, "Thin Film IOR": 1.6})
    return m


# =========================================================================
# 4. Multi-layer insulation blankets + beta cloth
# =========================================================================
def mat_mli(name="PHMA_MLI_Gold", base=(0.95, 0.62, 0.22)):
    m, nb, out = _start(name, "Thermal", dict(base=base, metal=0.9, rough=0.05))
    o = nb.tc().outputs["Object"]
    wr = nb.noise(o, 3.5, 6, 0.6, dist=1.5, x=-1200, y=300).outputs["Fac"]
    vor = nb.voronoi(o, 22.0, 'F1', 1.0, -1200, 100).outputs["Distance"]
    cr = nb.noise(o, 60.0, 2, x=-1200, y=-100).outputs["Fac"]
    h = nb.math('MULTIPLY_ADD', cr, 0.1, nb.math('MULTIPLY_ADD', vor, 0.25, nb.math('MULTIPLY', wr, 0.8, x=-1000, y=300),
                                                  x=-850, y=200), x=-700, y=200)
    sx = nb.mr(nb.wave(o, 1.047, 'BANDS', 'X', x=-1200, y=-300, profile='SAW').outputs["Fac"], 0.985, 1.0, x=-1000, y=-300)
    sz = nb.mr(nb.wave(o, 1.047, 'BANDS', 'Z', x=-1200, y=-500, profile='SAW').outputs["Fac"], 0.985, 1.0, x=-1000, y=-500)
    stitch = nb.math('MAXIMUM', sx, sz, x=-850, y=-400)
    col = nb.mixc(nb.math('MULTIPLY', stitch, 0.7, x=-700, y=-400), base, (0.25, 0.2, 0.12), x=-500, y=100)
    rough = nb.math('MULTIPLY_ADD', stitch, 0.5, nb.math('MULTIPLY_ADD', wr, 0.06, 0.03, x=-700, y=-100), x=-500, y=-100)
    g = _weather(nb, col, rough, 0.9, _dim(base, 0.7), 0.6, dust=1.2, wear=0.6, impacts=1.3, heat=0.3, exterior=1.0)
    _finish(nb, out, g, h, 0.45, 0.03, {"Coat Weight": 0.6, "Coat Roughness": 0.05, "Transmission Weight": 0.0})
    return m


def mat_beta_cloth(name="PHMA_BetaCloth"):
    m, nb, out = _start(name, "Fabric", dict(base=(0.88, 0.88, 0.86), metal=0.0, rough=0.8))
    o = nb.tc().outputs["Object"]
    chk = nb.new("ShaderNodeTexChecker", -900, 0)
    nb.set(chk.inputs["Vector"], o)
    chk.inputs["Scale"].default_value = 400.0
    h = chk.outputs["Fac"]
    g = _weather(nb, (0.88, 0.88, 0.86), 0.8, 0.0, (0.7, 0.68, 0.62), 0.0, dust=1.4, wear=0.8, impacts=1.2, exterior=1.0)
    _finish(nb, out, g, h, 0.1, 0.001, {"Sheen Weight": 0.3})
    return m


# =========================================================================
# 5. Chrome hydraulic pistons + anodized barrels
# =========================================================================
def mat_chrome(name="PHMA_ChromeHydraulic"):
    m, nb, out = _start(name, "Metal", dict(base=(0.85, 0.86, 0.88), metal=1.0, rough=0.05))
    o = nb.tc().outputs["Object"]
    streak = nb.noise(nb.mapping(o, scale=(25, 25, 1.5), x=-1200, y=300), 3.0, 4, x=-1000, y=300).outputs["Fac"]
    oil = nb.math('MULTIPLY', nb.mr(streak, 0.55, 0.75, x=-800, y=300),
                  nb.mr(nb.noise(o, 1.2, 3, x=-1000, y=100).outputs["Fac"], 0.45, 0.7, x=-800, y=100), x=-600, y=200)
    rings = nb.mr(nb.wave(o, 3.0, 'BANDS', 'Z', x=-1000, y=-150, profile='SAW').outputs["Fac"], 0.97, 1.0, x=-800, y=-150)
    col = nb.mixc(oil, (0.85, 0.86, 0.88), (0.22, 0.18, 0.10), x=-400, y=200)
    col = nb.mixc(nb.math('MULTIPLY', rings, 0.5, x=-600, y=-150), col, (0.5, 0.5, 0.52), x=-200, y=200)
    rough = nb.math('MULTIPLY_ADD', rings, 0.1, nb.math('MULTIPLY_ADD', oil, 0.25, 0.05, x=-400, y=0), x=-200, y=0)
    g = _weather(nb, col, rough, 1.0, (0.9, 0.9, 0.92), 1.0, dust=0.15, wear=0.3, impacts=0.5)
    _finish(nb, out, g, None, vals={"Anisotropic": 0.7}, tangent_z=True)
    return m


def mat_simple(name, mtype, base, metal, rough, wear_color=None, wear_metal=None, dust=1.0, wear=1.0,
               impacts=1.0, heat=0.0, exterior=0.0, bump_scale=200.0, bump_strength=0.06, vals=None):
    m, nb, out = _start(name, mtype, dict(base=base, metal=metal, rough=rough))
    o = nb.tc().outputs["Object"]
    var = nb.noise(o, 5.0, 4, x=-900, y=200).outputs["Fac"]
    col = nb.mixc(nb.math('MULTIPLY', var, 0.25, x=-700, y=200), base, _dim(base, 0.85), x=-500, y=200)
    h = nb.noise(o, bump_scale, 3, x=-900, y=-200).outputs["Fac"]
    g = _weather(nb, col, rough, metal, wear_color or _dim(base, 1.2), metal if wear_metal is None else wear_metal,
                 dust=dust, wear=wear, impacts=impacts, heat=heat, exterior=exterior)
    _finish(nb, out, g, h, bump_strength, 0.002, vals)
    return m


# =========================================================================
# 6. Lunar regolith dust accumulation (standalone) + terrain
# =========================================================================
def mat_dust(name="PHMA_LunarDust", base=DUST_RGB, rough=0.97, mtype="Terrain", big=False):
    m, nb, out = _start(name, mtype, dict(base=base, metal=0.0, rough=rough))
    o = nb.tc().outputs["Object"]
    grain = nb.noise(o, 220.0, 3, x=-900, y=200).outputs["Fac"]
    clump = nb.noise(o, 18.0, 5, x=-900, y=0).outputs["Fac"]
    col = nb.mixc(clump, _dim(base, 0.85), _dim(base, 1.1), x=-500, y=200)
    if big:
        albedo = nb.noise(o, 0.015, 6, 0.6, x=-900, y=400).outputs["Fac"]
        col = nb.mixc(nb.mr(albedo, 0.35, 0.7, x=-700, y=400), _dim(base, 0.75), col, x=-300, y=300)
        rocks = nb.mr(nb.voronoi(o, 1.6, 'F1', 1.0, -900, -400).outputs["Distance"], 0.07, 0.0, x=-700, y=-400)
        clump = nb.math('MULTIPLY_ADD', rocks, 2.0, clump, x=-500, y=-200)
    glint = nb.mr(nb.voronoi(o, 900.0, 'F1', 1.0, -900, -200).outputs["Distance"], 0.06, 0.0, x=-700, y=-200)
    r = nb.mixf(glint, rough, 0.25, x=-300, y=0)
    h = nb.math('MULTIPLY_ADD', grain, 0.5, nb.math('MULTIPLY', clump, 0.5, x=-500, y=0), x=-300, y=-100)
    nb_b = _plain(nb, out, {"Specular IOR Level": 0.35}, h, 0.5, 0.01)
    nb.l.new(col, nb_b.inputs["Base Color"])
    nb.l.new(r, nb_b.inputs["Roughness"])
    return m


def mat_regolith_blocks(name="PHMA_RegolithBlock"):
    m, nb, out = _start(name, "Terrain", dict(base=(0.24, 0.23, 0.21), metal=0.0, rough=0.95))
    o = nb.tc().outputs["Object"]
    layers = nb.wave(o, 15.7, 'BANDS', 'Z', x=-900, y=0).outputs["Fac"]
    grain = nb.noise(o, 120.0, 4, x=-900, y=-200).outputs["Fac"]
    h = nb.math('MULTIPLY_ADD', layers, 0.4, grain, x=-700, y=-100)
    g = _weather(nb, (0.24, 0.23, 0.21), 0.95, 0.0, (0.3, 0.29, 0.27), 0.0, dust=1.6, wear=0.5, impacts=1.4, exterior=1.0)
    _finish(nb, out, g, h, 0.6, 0.01)
    return m


# =========================================================================
# 7. LED indicators (fixed colours + fleet status LED driven by scene state)
# =========================================================================
def mat_led(name, col, strength=10.0):
    m, nb, out = _start(name, "Emissive", dict(base=_dim(col, 0.2), metal=0.0, rough=0.15, emit=col, es=strength))
    _plain(nb, out, {"Base Color": _dim(col, 0.2), "Roughness": 0.15, "Coat Weight": 1.0,
                     "Emission Color": col, "Emission Strength": strength})
    return m


def mat_led_status(name="PHMA_LED", strength=10.0, scene=None):
    scene = ensure_scene_props(scene)
    m, nb, out = _start(name, "Emissive", dict(base=(0.02, 0.06, 0.2), metal=0.0, rough=0.15,
                                                emit=LED_RGB["Blue"], es=strength))
    st = nb.value(0.0, -900, 0, "LED_State")
    add_scene_driver(m.node_tree, st, LED_PROP, scene)
    f = nb.math('DIVIDE', nb.math('ADD', st, 0.5, x=-700, y=0), 4.0, x=-550, y=0)
    col = nb.ramp(f, [(0.0, LED_RGB["Blue"]), (0.25, LED_RGB["Green"]), (0.5, LED_RGB["Yellow"]), (0.75, LED_RGB["Red"])],
                  -350, 0, interp='CONSTANT')
    b = _plain(nb, out, {"Base Color": (0.02, 0.02, 0.02), "Roughness": 0.15, "Coat Weight": 1.0, "Emission Strength": strength})
    nb.l.new(col, b.inputs["Emission Color"])
    return m


def mat_emit(name, col, strength, mtype="Emissive"):
    m, nb, out = _start(name, mtype, dict(base=col, metal=0.0, rough=0.5, emit=col, es=strength))
    em = nb.new("ShaderNodeEmission", 1200, 0)
    em.inputs["Color"].default_value = (col[0], col[1], col[2], 1)
    em.inputs["Strength"].default_value = strength
    nb.l.new(em.outputs[0], out.inputs["Surface"])
    return m


# =========================================================================
# 8. Worn paint + hazard markings (thermal white, EVA yellow, hazard stripes)
# =========================================================================
def mat_paint(name, base, rough=0.55, wear_color=(0.58, 0.60, 0.62), dust=1.2, wear=1.25, exterior=0.0, mtype="Coating"):
    m, nb, out = _start(name, mtype, dict(base=base, metal=0.0, rough=rough))
    o = nb.tc().outputs["Object"]
    var = nb.noise(o, 4.0, 4, x=-900, y=200).outputs["Fac"]
    col = nb.mixc(nb.math('MULTIPLY', var, 0.2, x=-700, y=200), base, _dim(base, 0.88), x=-500, y=200)
    peel = nb.noise(o, 300.0, 2, x=-900, y=-200).outputs["Fac"]
    g = _weather(nb, col, rough, 0.0, wear_color, 1.0, dust=dust, wear=wear, impacts=1.0, exterior=exterior)
    _finish(nb, out, g, peel, 0.05, 0.001)
    return m


def mat_hazard(name="PHMA_PaintHazard"):
    m, nb, out = _start(name, "Coating", dict(base=(0.85, 0.6, 0.02), metal=0.0, rough=0.5))
    o = nb.tc().outputs["Object"]
    w = nb.wave(o, 3.14, 'BANDS', 'DIAGONAL', x=-900, y=200).outputs["Fac"]
    stripe = nb.math('GREATER_THAN', w, 0.5, x=-700, y=200)
    col = nb.mixc(stripe, (0.02, 0.02, 0.02), (0.85, 0.6, 0.02), x=-500, y=200)
    g = _weather(nb, col, 0.5, 0.0, (0.58, 0.60, 0.62), 1.0, dust=1.3, wear=1.5, impacts=1.0)
    _finish(nb, out, g, None)
    return m


# =========================================================================
# 9. Micrometeorite impact damage (breach crater) + 10. procedural weld seams
# =========================================================================
def mat_impact(name="PHMA_ImpactDamage"):
    m, nb, out = _start(name, "Damage", dict(base=(0.2, 0.19, 0.18), metal=0.4, rough=0.6))
    o = nb.tc().outputs["Object"]
    d = nb.vmath('LENGTH', o, x=-1100, y=0)
    jit = nb.noise(o, 25.0, 6, 0.7, x=-1100, y=-200).outputs["Fac"]
    dd = nb.math('MULTIPLY_ADD', jit, 0.06, d, x=-900, y=0)
    col = nb.ramp(dd, [(0.0, (0.003, 0.003, 0.003)), (0.07, (0.01, 0.01, 0.01)), (0.09, (0.62, 0.6, 0.57)),
                       (0.14, (0.10, 0.08, 0.06)), (0.32, (0.22, 0.2, 0.18)), (0.5, (0.45, 0.44, 0.42))], -700, 0)
    met = nb.mr(dd, 0.08, 0.1, 0.0, 1.0, -700, -250)
    met = nb.math('MULTIPLY', met, nb.mr(dd, 0.1, 0.14, 1.0, 0.2, -700, -400), x=-500, y=-300)
    rough = nb.mr(dd, 0.08, 0.4, 0.35, 0.85, -700, -550)
    alpha = nb.mr(d, 0.42, 0.55, 1.0, 0.0, -700, -700)
    splat = nb.mr(nb.voronoi(o, 60.0, 'F1', 1.0, -1100, -900).outputs["Distance"], 0.12, 0.0, x=-900, y=-900)
    h = nb.math('MULTIPLY_ADD', splat, 0.3, nb.mr(dd, 0.0, 0.12, -1.0, 0.0, -700, -1050), x=-500, y=-1000)
    b = _plain(nb, out, {}, h, 0.8, 0.02)
    nb.l.new(col, b.inputs["Base Color"])
    nb.l.new(met, b.inputs["Metallic"])
    nb.l.new(rough, b.inputs["Roughness"])
    nb.l.new(alpha, b.inputs["Alpha"])
    return m


def mat_weld(name="PHMA_WeldSeam"):
    m, nb, out = _start(name, "Weld", dict(base=(0.5, 0.48, 0.45), metal=1.0, rough=0.4))
    uv = nb.sep(nb.tc().outputs["UV"], -1300, 0)
    L = nb.math('MAXIMUM', nb.attr("lmsp_len", 'OBJECT', -1300, -250).outputs["Fac"], 0.2, x=-1100, y=-250)
    along = nb.math('MULTIPLY', nb.math('MULTIPLY', uv.outputs[0], L, x=-1100, y=0), 180.0, x=-950, y=0)
    across = nb.math('ABSOLUTE', nb.math('SUBTRACT', nb.math('FRACT', nb.math('MULTIPLY', uv.outputs[1], 2.0, x=-1100, y=150),
                                                             x=-950, y=150), 0.5, x=-800, y=150), x=-650, y=150)
    rp = nb.math('FRACT', nb.math('MULTIPLY_ADD', nb.math('POWER', across, 2.0, x=-500, y=150), 0.6, along, x=-350, y=50), x=-200, y=50)
    h = nb.math('SUBTRACT', 1.0, rp, x=-50, y=50)
    tint = nb.ramp(nb.math('MULTIPLY', across, 2.0, x=-500, y=-150),
                   [(0.0, (0.55, 0.55, 0.56)), (0.6, (0.5, 0.48, 0.42)), (0.8, (0.58, 0.42, 0.18)),
                    (0.9, (0.28, 0.25, 0.5)), (1.0, (0.35, 0.4, 0.55))], -300, -150)
    rough = nb.math('MULTIPLY_ADD', rp, 0.12, 0.33, x=-50, y=-300)
    g = _weather(nb, tint, rough, 1.0, (0.7, 0.7, 0.72), 1.0, dust=1.0, wear=0.5, impacts=1.0)
    _finish(nb, out, g, h, 0.6, 0.002)
    return m


def mat_heat_tint(name="PHMA_WeldHeatTint"):
    m, nb, out = _start(name, "Weld", dict(base=(0.5, 0.42, 0.3), metal=1.0, rough=0.3))
    uv = nb.sep(nb.tc().outputs["UV"], -1100, 0)
    across = nb.math('ABSOLUTE', nb.math('MULTIPLY', nb.math('SUBTRACT', uv.outputs[1], 0.5, x=-900, y=0), 2.0, x=-750, y=0), x=-600, y=0)
    col = nb.ramp(across, [(0.0, (0.35, 0.38, 0.52)), (0.25, (0.38, 0.28, 0.45)), (0.5, (0.6, 0.44, 0.2)),
                           (0.8, (0.6, 0.58, 0.5)), (1.0, (0.58, 0.60, 0.62))], -400, 0)
    alpha = nb.mr(across, 0.8, 1.0, 1.0, 0.0, -400, -250)
    g = _weather(nb, col, 0.3, 1.0, (0.7, 0.7, 0.72), 1.0, dust=1.0, wear=0.5, impacts=1.0, heat=0.5)
    b = _finish(nb, out, g, None)
    nb.l.new(alpha, b.inputs["Alpha"])
    return m


# =========================================================================
# cables, rails, fabrics, electronics, habitat, fluids, celestial
# =========================================================================
def mat_kevlar(name="PHMA_KevlarWire"):
    m, nb, out = _start(name, "Fabric", dict(base=(0.78, 0.56, 0.12), metal=0.0, rough=0.6))
    uv = nb.sep(nb.tc().outputs["UV"], -1300, 0)
    L = nb.math('MAXIMUM', nb.attr("lmsp_len", 'OBJECT', -1300, -250).outputs["Fac"], 0.2, x=-1100, y=-250)
    a = nb.math('MULTIPLY', nb.math('MULTIPLY', uv.outputs[0], L, x=-1100, y=0), 60.0, x=-950, y=0)
    b = nb.math('MULTIPLY', uv.outputs[1], 24.0, x=-950, y=-150)
    p1 = nb.math('ADD', a, b, x=-800, y=0)
    p2 = nb.math('SUBTRACT', a, b, x=-800, y=-150)
    sel = nb.math('FLOORED_MODULO', nb.math('ADD', nb.math('FLOOR', p1, x=-650, y=0), nb.math('FLOOR', p2, x=-650, y=-150),
                                            x=-500, y=-50), 2.0, x=-350, y=-50)
    fr = nb.mixf(sel, nb.math('FRACT', p1, x=-500, y=100), nb.math('FRACT', p2, x=-500, y=-250), x=-200, y=0)
    h = nb.math('SINE', nb.math('MULTIPLY', fr, math.pi, x=-50, y=0), x=100, y=0)
    soil = nb.mr(nb.noise(nb.tc().outputs["Object"], 3.0, 4, x=-500, y=-450).outputs["Fac"], 0.5, 0.75, x=-300, y=-450)
    col = nb.mixc(nb.math('MULTIPLY', h, 0.35, x=250, y=150), (0.55, 0.38, 0.07), (0.82, 0.6, 0.14), x=400, y=200)
    col = nb.mixc(nb.math('MULTIPLY', soil, 0.5, x=400, y=0), col, (0.32, 0.27, 0.18), x=550, y=200)
    g = _weather(nb, col, 0.6, 0.0, (0.9, 0.75, 0.35), 0.0, dust=1.3, wear=0.8, impacts=1.0)
    _finish(nb, out, g, h, 0.4, 0.002, {"Sheen Weight": 0.5, "Sheen Roughness": 0.4})
    return m


def mat_rail(name="PHMA_RailTrack"):
    base = (0.35, 0.36, 0.38)
    m, nb, out = _start(name, "Metal", dict(base=base, metal=1.0, rough=0.4))
    geo = nb.new("ShaderNodeNewGeometry", -1100, 200)
    top = nb.mr(nb.sep(geo.outputs["Normal"], -900, 200).outputs[2], 0.92, 0.99, x=-700, y=200)
    o = nb.tc().outputs["Object"]
    steel = nb.noise(o, 180.0, 4, x=-900, y=-100).outputs["Fac"]
    col = nb.mixc(nb.math('MULTIPLY', top, 0.65, x=-500, y=200), base, (0.62, 0.63, 0.65), x=-300, y=200)
    rough = nb.mixf(top, 0.4, 0.12, x=-300, y=0)
    dust = nb.math('MULTIPLY', nb.math('SUBTRACT', 1.0, nb.math('MULTIPLY', top, 0.85, x=-500, y=-250), x=-350, y=-250),
                   1.6, x=-200, y=-250)
    g = _weather(nb, col, rough, 1.0, (0.7, 0.71, 0.73), 1.0, dust=dust, wear=1.3, impacts=1.0, heat=0.2)
    _finish(nb, out, g, steel, 0.1, 0.002, {"Anisotropic": 0.3})
    return m


def mat_bellows(name="PHMA_DustBellows"):
    m, nb, out = _start(name, "Fabric", dict(base=(0.72, 0.71, 0.68), metal=0.0, rough=0.82))
    o = nb.tc().outputs["Object"]
    folds = nb.wave(o, 7.85, 'BANDS', 'Z', x=-900, y=0, profile='TRI').outputs["Fac"]
    g = _weather(nb, (0.72, 0.71, 0.68), 0.82, 0.0, (0.5, 0.49, 0.46), 0.0, dust=2.0, wear=0.9, impacts=1.0)
    _finish(nb, out, g, folds, 0.9, 0.02, {"Sheen Weight": 0.2})
    return m


def mat_grid_panel(name, mtype, base, metal, rough, line_col, period, thin=0.97, vals=None, exterior=1.0, dust=1.2,
                   film=None):
    m, nb, out = _start(name, mtype, dict(base=base, metal=metal, rough=rough))
    o = nb.tc().outputs["Object"]
    sc = 2.0 * math.pi / (20.0 * period)
    lx = nb.mr(nb.wave(o, sc, 'BANDS', 'X', x=-1100, y=200, profile='SAW').outputs["Fac"], thin, 1.0, x=-900, y=200)
    lz = nb.mr(nb.wave(o, sc, 'BANDS', 'Z', x=-1100, y=0, profile='SAW').outputs["Fac"], thin, 1.0, x=-900, y=0)
    ly = nb.mr(nb.wave(o, sc, 'BANDS', 'Y', x=-1100, y=-200, profile='SAW').outputs["Fac"], thin, 1.0, x=-900, y=-200)
    line = nb.math('MAXIMUM', nb.math('MAXIMUM', lx, lz, x=-750, y=100), ly, x=-600, y=0)
    col = nb.mixc(line, base, line_col, x=-400, y=200)
    rough_s = nb.math('MULTIPLY_ADD', line, 0.3, rough, x=-400, y=0)
    g = _weather(nb, col, rough_s, metal, _dim(base, 0.8), metal, dust=dust, wear=0.6, impacts=1.2, exterior=exterior)
    v = dict(vals or {})
    if film:
        v["Thin Film Thickness"] = film
    _finish(nb, out, g, nb.math('MULTIPLY', line, -1.0, x=-400, y=-200), 0.3, 0.003, v)
    return m


def mat_water(name="PHMA_Water"):
    m, nb, out = _start(name, "Fluid", dict(base=(0.6, 0.85, 1.0), metal=0.0, rough=0.01, alpha=0.3, trans=1.0))
    o = nb.tc().outputs["Object"]
    ripple = nb.noise(o, 8.0, 3, x=-900, y=-200).outputs["Fac"]
    _plain(nb, out, {"Base Color": (0.85, 0.95, 1.0), "Roughness": 0.0, "IOR": 1.333, "Transmission Weight": 1.0}, ripple, 0.05, 0.01)
    vol = nb.new("ShaderNodeVolumeAbsorption", 1250, -400)
    vol.inputs["Color"].default_value = (0.55, 0.82, 0.95, 1)
    vol.inputs["Density"].default_value = 0.6
    nb.l.new(vol.outputs[0], out.inputs["Volume"])
    try:
        m.use_raytrace_refraction = True
    except Exception:
        pass
    return m


def mat_acrylic(name="PHMA_Acrylic"):
    m, nb, out = _start(name, "Optical", dict(base=(0.92, 0.96, 1.0), metal=0.0, rough=0.03, alpha=0.2, trans=1.0))
    o = nb.tc().outputs["Object"]
    sm = nb.mr(nb.noise(o, 4.0, 4, x=-900, y=0).outputs["Fac"], 0.5, 0.8, 0.02, 0.1, -700, 0)
    g = _weather(nb, (1, 1, 1), sm, 0.0, (1, 1, 1), 0.0, dust=0.3, wear=0.4, impacts=0.0)
    _finish(nb, out, g, None, vals={"Transmission Weight": 1.0, "IOR": 1.49, "Coat Weight": 0.5})
    try:
        m.use_raytrace_refraction = True
    except Exception:
        pass
    return m


def mat_screen(name="PHMA_ScreenUI", scene=None):
    scene = ensure_scene_props(scene)
    m, nb, out = _start(name, "Electronic", dict(base=(0.01, 0.02, 0.03), metal=0.0, rough=0.1,
                                                  emit=(0.05, 0.45, 0.8), es=3.0))
    uv = nb.sep(nb.tc().outputs["UV"], -1500, 0)
    u, v = uv.outputs[0], uv.outputs[1]
    gx = nb.mr(nb.math('FRACT', nb.math('MULTIPLY', u, 12.0, x=-1300, y=300), x=-1150, y=300), 0.95, 1.0, x=-1000, y=300)
    gy = nb.mr(nb.math('FRACT', nb.math('MULTIPLY', v, 8.0, x=-1300, y=150), x=-1150, y=150), 0.95, 1.0, x=-1000, y=150)
    grid = nb.math('MULTIPLY', nb.math('MAXIMUM', gx, gy, x=-850, y=220), 0.35, x=-700, y=220)
    col_id = nb.math('FLOOR', nb.math('MULTIPLY', u, 24.0, x=-1300, y=0), x=-1150, y=0)
    hgt = nb.noise(nb.comb(col_id, 0.0, 0.0, -1000, 0), 0.37, 2, x=-850, y=0).outputs["Fac"]
    bars = nb.math('MULTIPLY', nb.math('LESS_THAN', nb.math('MULTIPLY', v, 1.6, x=-850, y=-150), hgt, x=-700, y=-100),
                   nb.math('LESS_THAN', v, 0.55, x=-700, y=-250), x=-550, y=-100)
    wave = nb.mr(nb.math('ABSOLUTE', nb.math('SUBTRACT', v, nb.math('MULTIPLY_ADD', nb.math('SINE', nb.math('MULTIPLY', u, 25.0,
                 x=-1300, y=-450), x=-1150, y=-450), 0.06, 0.78, x=-1000, y=-450), x=-850, y=-450), x=-700, y=-450),
                 0.008, 0.0, x=-550, y=-450)
    header = nb.math('GREATER_THAN', v, 0.92, x=-700, y=-600)
    pat = nb.math('MAXIMUM', nb.math('MAXIMUM', grid, bars, x=-400, y=0), nb.math('MAXIMUM', wave, nb.math('MULTIPLY', header,
                  0.8, x=-550, y=-600), x=-400, y=-400), x=-250, y=-100)
    st = nb.value(0.0, -700, -800, "LED_State")
    add_scene_driver(m.node_tree, st, LED_PROP, scene)
    warn = nb.math('GREATER_THAN', st, 1.5, x=-550, y=-800)
    col = nb.mixc(warn, (0.05, 0.45, 0.8), (1.0, 0.12, 0.05), x=-250, y=-700)
    emit = nb.mixc(pat, (0.0, 0.0, 0.0), col, x=0, y=-300)
    b = _plain(nb, out, {"Base Color": (0.01, 0.012, 0.015), "Roughness": 0.08, "Coat Weight": 1.0, "Emission Strength": 3.0})
    nb.l.new(emit, b.inputs["Emission Color"])
    return m


def mat_plant(name="PHMA_PlantLeaf"):
    m, nb, out = _start(name, "Bio", dict(base=(0.06, 0.28, 0.04), metal=0.0, rough=0.45))
    oi = nb.new("ShaderNodeObjectInfo", -900, 0)
    col = nb.ramp(oi.outputs["Random"], [(0.0, (0.04, 0.2, 0.03)), (0.6, (0.07, 0.3, 0.04)), (1.0, (0.16, 0.35, 0.05))], -600, 0)
    b = _plain(nb, out, {"Roughness": 0.45, "Subsurface Weight": 0.2, "Sheen Weight": 0.1})
    nb.l.new(col, b.inputs["Base Color"])
    return m


def mat_earth(name="PHMA_Earth"):
    m, nb, out = _start(name, "Celestial", dict(base=(0.05, 0.1, 0.3), metal=0.0, rough=0.5))
    gen = nb.vmath('SUBTRACT', nb.tc().outputs["Generated"], (0.5, 0.5, 0.5), x=-1300, y=0)
    land = nb.mr(nb.noise(gen, 2.2, 8, 0.6, dist=0.4, x=-1100, y=200).outputs["Fac"], 0.52, 0.56, x=-900, y=200)
    lat = nb.math('ABSOLUTE', nb.sep(nb.vmath('NORMALIZE', gen, x=-1100, y=-200), -950, -200).outputs[2], x=-800, y=-200)
    ice = nb.mr(lat, 0.82, 0.9, x=-650, y=-200)
    biome = nb.ramp(nb.noise(gen, 4.0, 6, x=-1100, y=400).outputs["Fac"],
                    [(0.35, (0.33, 0.26, 0.15)), (0.55, (0.12, 0.16, 0.06)), (0.7, (0.05, 0.11, 0.03))], -800, 400)
    col = nb.mixc(land, (0.004, 0.018, 0.06), biome, x=-500, y=200)
    col = nb.mixc(ice, col, (0.85, 0.88, 0.9), x=-300, y=200)
    rough = nb.mixf(land, 0.12, 0.8, x=-300, y=0)
    b = _plain(nb, out, {"Specular IOR Level": 0.6})
    nb.l.new(col, b.inputs["Base Color"])
    nb.l.new(rough, b.inputs["Roughness"])
    return m


def mat_clouds(name="PHMA_EarthClouds"):
    m, nb, out = _start(name, "Celestial", dict(base=(1, 1, 1), metal=0.0, rough=0.9, alpha=0.5))
    gen = nb.vmath('SUBTRACT', nb.tc().outputs["Generated"], (0.5, 0.5, 0.5), x=-1100, y=0)
    c = nb.mr(nb.noise(gen, 3.0, 10, 0.62, dist=0.6, x=-900, y=0).outputs["Fac"], 0.5, 0.68, x=-700, y=0)
    b = _plain(nb, out, {"Base Color": (0.95, 0.95, 0.97), "Roughness": 0.95})
    nb.l.new(c, b.inputs["Alpha"])
    return m


def mat_atmo(name="PHMA_EarthAtmosphere"):
    m, nb, out = _start(name, "Celestial", dict(base=(0.3, 0.55, 1.0), metal=0.0, rough=1.0, alpha=0.3))
    lw = nb.new("ShaderNodeLayerWeight", -900, 0)
    lw.inputs["Blend"].default_value = 0.35
    a = nb.math('POWER', lw.outputs["Facing"], 2.5, x=-700, y=0)
    b = _plain(nb, out, {"Base Color": (0.25, 0.5, 1.0), "Roughness": 1.0})
    nb.l.new(nb.math('MULTIPLY', a, 0.9, x=-550, y=0), b.inputs["Alpha"])
    return m


def mat_dust_mote(name="PHMA_DustMote"):
    m, nb, out = _start(name, "Terrain", dict(base=(0.5, 0.5, 0.48), metal=0.0, rough=0.9))
    tr = nb.new("ShaderNodeBsdfTranslucent", 900, 200)
    tr.inputs["Color"].default_value = (0.75, 0.72, 0.66, 1)
    df = nb.new("ShaderNodeBsdfDiffuse", 900, 0)
    df.inputs["Color"].default_value = (0.5, 0.5, 0.48, 1)
    mx = nb.new("ShaderNodeMixShader", 1200, 0)
    mx.inputs[0].default_value = 0.65
    nb.l.new(df.outputs[0], mx.inputs[1])
    nb.l.new(tr.outputs[0], mx.inputs[2])
    nb.l.new(mx.outputs[0], out.inputs["Surface"])
    return m


# =========================================================================
# library registry
# =========================================================================
def _library():
    L = [
        ("PHMA_Titanium", lambda: mat_titanium()),
        ("PHMA_TitaniumExterior", lambda: mat_titanium("PHMA_TitaniumExterior", exterior=1.0)),
        ("PHMA_CarbonFiber", lambda: mat_carbon()),
        ("PHMA_OpticalGlass", lambda: mat_glass()),
        ("PHMA_LensOptic", lambda: mat_lens()),
        ("PHMA_MLI_Gold", lambda: mat_mli("PHMA_MLI_Gold", (0.95, 0.62, 0.22))),
        ("PHMA_MLI_Silver", lambda: mat_mli("PHMA_MLI_Silver", (0.86, 0.87, 0.88))),
        ("PHMA_BetaCloth", lambda: mat_beta_cloth()),
        ("PHMA_ChromeHydraulic", lambda: mat_chrome()),
        ("PHMA_AnodizedBlack", lambda: mat_simple("PHMA_AnodizedBlack", "Metal", (0.03, 0.03, 0.035), 1.0, 0.35,
                                                  wear_color=(0.7, 0.7, 0.72), dust=1.0, wear=1.1)),
        ("PHMA_Aluminum", lambda: mat_simple("PHMA_Aluminum", "Metal", (0.91, 0.92, 0.92), 1.0, 0.3)),
        ("PHMA_Ceramic", lambda: mat_simple("PHMA_Ceramic", "Metal", (0.86, 0.86, 0.83), 0.0, 0.25,
                                            wear_color=(0.7, 0.7, 0.68), wear_metal=0.0, dust=0.3, wear=0.3)),
        ("PHMA_Copper", lambda: mat_simple("PHMA_Copper", "Metal", (0.95, 0.64, 0.54), 1.0, 0.25,
                                           wear_color=(0.98, 0.7, 0.6), heat=0.4)),
        ("PHMA_RubberSeal", lambda: mat_simple("PHMA_RubberSeal", "Fabric", (0.02, 0.02, 0.022), 0.0, 0.75,
                                               wear_color=(0.06, 0.06, 0.06), wear_metal=0.0, dust=1.6, wear=1.4)),
        ("PHMA_DustBellows", lambda: mat_bellows()),
        ("PHMA_KevlarWire", lambda: mat_kevlar()),
        ("PHMA_RailTrack", lambda: mat_rail()),
        ("PHMA_LunarDust", lambda: mat_dust()),
        ("PHMA_Regolith", lambda: mat_dust("PHMA_Regolith", (0.2, 0.195, 0.185), 0.98, big=True)),
        ("PHMA_RegolithBlock", lambda: mat_regolith_blocks()),
        ("PHMA_LED", lambda: mat_led_status()),
        ("PHMA_LED_Blue", lambda: mat_led("PHMA_LED_Blue", LED_RGB["Blue"], 10.0)),
        ("PHMA_LED_Green", lambda: mat_led("PHMA_LED_Green", LED_RGB["Green"], 10.0)),
        ("PHMA_LED_Yellow", lambda: mat_led("PHMA_LED_Yellow", LED_RGB["Yellow"], 10.0)),
        ("PHMA_LED_Red", lambda: mat_led("PHMA_LED_Red", LED_RGB["Red"], 12.0)),
        ("PHMA_PaintWhite", lambda: mat_paint("PHMA_PaintWhite", (0.82, 0.82, 0.80), 0.6)),
        ("PHMA_PaintWhiteExterior", lambda: mat_paint("PHMA_PaintWhiteExterior", (0.84, 0.84, 0.82), 0.65, exterior=1.0, dust=1.5)),
        ("PHMA_PaintYellow", lambda: mat_paint("PHMA_PaintYellow", (0.85, 0.6, 0.02), 0.5, wear=1.6)),
        ("PHMA_PaintRed", lambda: mat_paint("PHMA_PaintRed", (0.55, 0.02, 0.02), 0.45, wear=1.4)),
        ("PHMA_PaintHazard", lambda: mat_hazard()),
        ("PHMA_ImpactDamage", lambda: mat_impact()),
        ("PHMA_WeldSeam", lambda: mat_weld()),
        ("PHMA_WeldHeatTint", lambda: mat_heat_tint()),
        ("PHMA_SolarCell", lambda: mat_grid_panel("PHMA_SolarCell", "Electronic", (0.015, 0.02, 0.06), 0.0, 0.15,
                                                  (0.6, 0.6, 0.62), 0.156, 0.975, {"Coat Weight": 1.0}, film=80.0)),
        ("PHMA_RadiatorOSR", lambda: mat_grid_panel("PHMA_RadiatorOSR", "Thermal", (0.92, 0.93, 0.94), 1.0, 0.04,
                                                    (0.15, 0.15, 0.15), 0.04, 0.94)),
        ("PHMA_HabitatShell", lambda: mat_grid_panel("PHMA_HabitatShell", "Coating", (0.78, 0.78, 0.76), 0.0, 0.6,
                                                     (0.35, 0.35, 0.34), 1.2, 0.985, dust=1.5)),
        ("PHMA_InteriorPanel", lambda: mat_grid_panel("PHMA_InteriorPanel", "Coating", (0.75, 0.76, 0.76), 0.0, 0.5,
                                                      (0.3, 0.3, 0.3), 0.6, 0.99, exterior=0.0, dust=0.3)),
        ("PHMA_WheelMesh", lambda: mat_simple("PHMA_WheelMesh", "Metal", (0.42, 0.42, 0.44), 1.0, 0.35,
                                              wear_color=(0.7, 0.7, 0.72), dust=2.0, wear=1.6, exterior=1.0)),
        ("PHMA_WaterShield", lambda: mat_simple("PHMA_WaterShield", "Fluid", (0.32, 0.42, 0.52), 0.0, 0.35,
                                                wear_color=(0.4, 0.5, 0.6), wear_metal=0.0, dust=0.3, wear=0.4,
                                                vals={"Sheen Weight": 0.2})),
        ("PHMA_Water", lambda: mat_water()),
        ("PHMA_Acrylic", lambda: mat_acrylic()),
        ("PHMA_ScreenUI", lambda: mat_screen()),
        ("PHMA_PlantLeaf", lambda: mat_plant()),
        ("PHMA_GrowLight", lambda: mat_emit("PHMA_GrowLight", (0.9, 0.25, 0.75), 8.0)),
        ("PHMA_LightPanel", lambda: mat_emit("PHMA_LightPanel", (1.0, 0.96, 0.9), 12.0)),
        ("PHMA_WeldGlow", lambda: mat_emit("PHMA_WeldGlow", (0.6, 0.75, 1.0), 120.0)),
        ("PHMA_Spark", lambda: mat_emit("PHMA_Spark", (1.0, 0.55, 0.15), 40.0)),
        ("PHMA_ImpactFlash", lambda: mat_emit("PHMA_ImpactFlash", (1.0, 0.9, 0.8), 0.0)),
        ("PHMA_Earth", lambda: mat_earth()),
        ("PHMA_EarthClouds", lambda: mat_clouds()),
        ("PHMA_EarthAtmosphere", lambda: mat_atmo()),
        ("PHMA_DustMote", lambda: mat_dust_mote()),
    ]
    return L


LIBRARY_NAMES = [n for n, _ in _library()]

CATEGORY = {
    "Titanium": ["PHMA_Titanium", "PHMA_TitaniumExterior"],
    "Carbon": ["PHMA_CarbonFiber"],
    "Glass": ["PHMA_OpticalGlass", "PHMA_LensOptic", "PHMA_Acrylic"],
    "Dust": ["PHMA_LunarDust", "PHMA_Regolith", "PHMA_RegolithBlock", "PHMA_DustMote"],
    "Hydraulics": ["PHMA_ChromeHydraulic", "PHMA_AnodizedBlack"],
    "Thermal": ["PHMA_MLI_Gold", "PHMA_MLI_Silver", "PHMA_BetaCloth", "PHMA_RadiatorOSR"],
}


def build_library(scene=None):
    scene = ensure_scene_props(scene)
    build_weathering_group(scene)
    made, errors = [], {}
    for name, fn in _library():
        try:
            fn()
            made.append(name)
        except Exception as e:
            import traceback
            errors[name] = traceback.format_exc()[-600:]
    for n in made:
        bpy.data.materials[n].use_fake_user = True
    return made, errors
