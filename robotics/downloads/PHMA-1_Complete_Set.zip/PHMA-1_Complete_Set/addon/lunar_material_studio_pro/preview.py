"""Live material preview geometry + cinematic age comparison."""
import bpy, bmesh, math
from mathutils import Vector, Matrix
from .materials import CATEGORY

PREVIEW_COLL = "LMSP_Preview"
ORIGIN = Vector((-90.0, -90.0, 0.0))
SHAPES = [('SPHERE', "Sphere", ""), ('CUBE', "Cube", ""), ('JOINT', "Mechanical Joint", ""),
          ('PIPE', "Pipe Segment", ""), ('HYDRAULIC', "Hydraulic Cylinder", "")]


def _coll(name):
    col = bpy.data.collections.get(name)
    if not col:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col


def _clear(col):
    for o in list(col.objects):
        d = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if d is not None and getattr(d, "users", 1) == 0:
            if isinstance(d, bpy.types.Mesh):
                bpy.data.meshes.remove(d)


def _cyl(bm, r, h, z0=0.0, seg=48, axis='Z', off=(0, 0, 0)):
    geom = bmesh.ops.create_cone(bm, cap_ends=True, segments=seg, radius1=r, radius2=r, depth=h)
    vs = geom["verts"]
    M = Matrix.Translation((0, 0, z0 + h / 2))
    if axis == 'X':
        M = Matrix.Rotation(math.pi / 2, 4, 'Y') @ M
    bmesh.ops.transform(bm, matrix=Matrix.Translation(off) @ M, verts=vs)


def shape_mesh(kind, name):
    bm = bmesh.new()
    if kind == 'SPHERE':
        bmesh.ops.create_uvsphere(bm, u_segments=64, v_segments=32, radius=0.42)
        bmesh.ops.translate(bm, vec=(0, 0, 0.42), verts=bm.verts)
    elif kind == 'CUBE':
        bmesh.ops.create_cube(bm, size=0.7)
        bmesh.ops.bevel(bm, geom=list(bm.edges), offset=0.04, segments=3, affect='EDGES', profile=0.5)
        bmesh.ops.translate(bm, vec=(0, 0, 0.35), verts=bm.verts)
    elif kind == 'JOINT':
        _cyl(bm, 0.3, 0.5, 0.05, axis='X', off=(-0.25, 0, 0.45))
        _cyl(bm, 0.34, 0.06, 0, axis='X', off=(-0.3, 0, 0.45))
        _cyl(bm, 0.34, 0.06, 0, axis='X', off=(0.24, 0, 0.45))
        for i in range(12):
            a = i / 12 * math.tau
            _cyl(bm, 0.018, 0.03, 0, seg=6, axis='X', off=(0.29, math.cos(a) * 0.28, 0.45 + math.sin(a) * 0.28))
        _cyl(bm, 0.12, 0.45, 0.0, seg=32, off=(0, 0, 0))
    elif kind == 'PIPE':
        g = bmesh.ops.create_cone(bm, cap_ends=False, segments=48, radius1=0.16, radius2=0.16, depth=1.0)
        bmesh.ops.rotate(bm, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2, 3, 'Y'), verts=g["verts"])
        for x in (-0.5, 0.5):
            _cyl(bm, 0.24, 0.05, 0, axis='X', off=(x - 0.025, 0, 0))
        bmesh.ops.translate(bm, vec=(0, 0, 0.3), verts=bm.verts)
    else:
        _cyl(bm, 0.09, 0.55, 0.0, off=(0, 0, 0.05))
        _cyl(bm, 0.045, 0.45, 0.6, off=(0, 0, 0))
        _cyl(bm, 0.06, 0.1, 0.0, seg=32, axis='X', off=(-0.05, 0, 0.02))
        _cyl(bm, 0.05, 0.1, 0.0, seg=32, axis='X', off=(-0.05, 0, 1.06))
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = True
    return me


def show_preview(context, category, shape='SPHERE'):
    scene = context.scene
    col = _coll(PREVIEW_COLL)
    _clear(col)
    if category == 'FULL':
        cam = bpy.data.objects.get("CAM_Arm_Preview")
        if cam:
            scene.camera = cam
        return 0
    mats = CATEGORY.get(category, [category]) if category in CATEGORY else [category]
    mats = [m for m in mats if m in bpy.data.materials]
    pl = bpy.data.meshes.new("LMSP_Preview_Plinth")
    bm = bmesh.new()
    bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=4.0)
    bm.to_mesh(pl)
    bm.free()
    po = bpy.data.objects.new("LMSP_Preview_Plinth", pl)
    col.objects.link(po)
    po.location = ORIGIN
    po["lmsp_preview"] = 1
    if "PHMA_RegolithBlock" in bpy.data.materials:
        pl.materials.append(bpy.data.materials["PHMA_InteriorPanel"])
    n = len(mats)
    for i, mn in enumerate(mats):
        me = shape_mesh(shape, "LMSP_Preview_%s" % mn)
        me.materials.append(bpy.data.materials[mn])
        o = bpy.data.objects.new("LMSP_Preview_%s" % mn, me)
        col.objects.link(o)
        o.location = ORIGIN + Vector(((i - (n - 1) / 2) * 1.15, 0, 0))
        o["lmsp_preview"] = 1
        o["lmsp_exterior"] = 1.0
    cam = bpy.data.objects.get("CAM_LMSP_Preview")
    if not cam:
        cd = bpy.data.cameras.new("CAM_LMSP_Preview")
        cam = bpy.data.objects.new("CAM_LMSP_Preview", cd)
        col.objects.link(cam)
    cam.data.lens = 60
    cam.location = ORIGIN + Vector((0, -4.2 - 0.6 * n, 1.6))
    cam.rotation_euler = (math.radians(80), 0, 0)
    cam["lmsp_preview"] = 1
    scene.camera = cam
    return n


def build_comparison(context, ages=(0, 1, 5, 10), rig_name="RIG_PHMA1_EXT", spacing=6.0):
    rig = bpy.data.objects.get(rig_name)
    if not rig:
        return 0
    col = _coll("LMSP_Comparison")
    clear_comparison()
    col = _coll("LMSP_Comparison")
    vl = context.view_layer
    base = Vector((-90.0, 40.0, 0.0))
    labels = {0: "NEW", 1: "1 YEAR", 5: "5 YEARS", 10: "10 YEARS"}
    for i, age in enumerate(ages):
        bpy.ops.object.select_all(action='DESELECT')
        objs = [rig] + [o for o in rig.children_recursive if o.name in vl.objects]
        for o in objs:
            o.hide_set(False)
            o.select_set(True)
        vl.objects.active = rig
        bpy.ops.object.duplicate(linked=True)
        new = list(context.selected_objects)
        nrig = next(o for o in new if o.type == 'ARMATURE')
        for o in new:
            for c in list(o.users_collection):
                c.objects.unlink(o)
            col.objects.link(o)
            o["lmsp_age_ovr"] = float(age) + 1.0
            o["lmsp_preview"] = 1
        nrig.location = base + Vector((i * spacing, 0, 0))
        cur = bpy.data.curves.new("LMSP_CMP_Label_%d" % age, 'FONT')
        cur.body = labels.get(age, "%d YEARS" % age)
        cur.size = 0.6
        cur.align_x = 'CENTER'
        t = bpy.data.objects.new("LMSP_CMP_Label_%d" % age, cur)
        col.objects.link(t)
        t.location = base + Vector((i * spacing, -3.2, 0.05))
        if "PHMA_LightPanel" in bpy.data.materials:
            cur.materials.append(bpy.data.materials["PHMA_LightPanel"])
        t["lmsp_preview"] = 1
    cam = bpy.data.objects.get("CAM_LMSP_Comparison")
    if not cam:
        cd = bpy.data.cameras.new("CAM_LMSP_Comparison")
        cam = bpy.data.objects.new("CAM_LMSP_Comparison", cd)
        col.objects.link(cam)
    cam.data.lens = 35
    mid = base + Vector(((len(ages) - 1) * spacing / 2, 0, 0))
    cam.location = mid + Vector((0, -26, 6.5))
    cam.rotation_euler = (math.radians(82), 0, 0)
    context.scene.camera = cam
    bpy.ops.object.select_all(action='DESELECT')
    return len(ages)


def clear_comparison():
    col = bpy.data.collections.get("LMSP_Comparison")
    if not col:
        return
    for o in list(col.objects):
        if o.name.startswith("CAM_"):
            continue
        bpy.data.objects.remove(o, do_unlink=True)
