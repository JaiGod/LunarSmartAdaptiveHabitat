"""Pipeline: validation, optimisation, LODs, movie-asset prep, game-ready GLB export with texture baking."""
import bpy, bmesh, os, json, re, time, math
from mathutils import Matrix, Vector
from .assign import NAME_OK, assign_materials, apply_dust, apply_wear, target_objects
from .materials import build_library

NON_PBR_OK = {"Emissive", "Fluid", "Celestial", "Optical", "Decal"}


# ------------------------------------------------------------------ validation
def _mat_issues(m):
    errs, warns, info = [], [], {"normal": False, "rough": False, "tex4k": False, "images": 0, "nodes": 0}
    if not m.node_tree:
        return ["no node tree"], warns, info
    nt = m.node_tree
    info["nodes"] = len(nt.nodes) + sum(len(n.node_tree.nodes) for n in nt.nodes if n.type == 'GROUP' and n.node_tree)
    outs = [n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL']
    if not outs:
        errs.append("Broken node tree: no Material Output")
    elif not any(o.inputs["Surface"].is_linked for o in outs):
        errs.append("Broken node tree: Surface not connected")
    for l in nt.links:
        if not l.is_valid:
            errs.append("Broken node link %s -> %s" % (l.from_node.name, l.to_node.name))
    for n in nt.nodes:
        if n.type == 'GROUP' and n.node_tree is None:
            errs.append("Group node without tree: " + n.name)
        if n.type == 'TEX_IMAGE':
            info["images"] += 1
            if n.image is None:
                errs.append("Broken texture link: " + n.name)
            else:
                img = n.image
                if img.source == 'FILE' and not img.packed_file and not os.path.exists(bpy.path.abspath(img.filepath)):
                    errs.append("Missing texture file: " + img.name)
                if max(img.size) >= 4096:
                    info["tex4k"] = True
    bsdfs = [n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED']
    if bsdfs:
        info["normal"] = any(b.inputs["Normal"].is_linked for b in bsdfs)
        info["rough"] = any(b.inputs["Roughness"].is_linked for b in bsdfs)
        if not info["normal"] and m.get("lmsp_type") not in NON_PBR_OK:
            warns.append("Missing Normal Map")
    elif m.get("lmsp_type") not in NON_PBR_OK:
        warns.append("Non-PBR Material")
    return errs, warns, info


def uv_area(me):
    uvl = me.uv_layers.active
    if not uvl:
        return 0.0
    tot = 0.0
    me.calc_loop_triangles()
    d = uvl.data
    for t in me.loop_triangles:
        a, b, c = (d[i].uv for i in t.loops)
        tot += abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)) * 0.5
    return tot


def validate_scene(context, write_text=True, write_json_dir=None):
    t0 = time.time()
    rep = {"errors": [], "warnings": [], "objects": 0, "materials": {}, "tris": 0}
    seen_meshes = {}
    for ob in context.scene.objects:
        if ob.type != 'MESH' or ob.get("lmsp_preview"):
            continue
        rep["objects"] += 1
        me = ob.data
        nt = sum(max(len(p.vertices) - 2, 1) for p in me.polygons) if me.name not in seen_meshes else seen_meshes[me.name]
        seen_meshes[me.name] = nt
        rep["tris"] += nt
        if not any(s.material for s in ob.material_slots):
            rep["errors"].append(("Missing Materials", ob.name))
        if not NAME_OK.match(ob.name):
            rep["warnings"].append(("Improper Naming", ob.name))
        if not ob.get("lmsp_decal"):
            if not me.uv_layers:
                rep["warnings"].append(("Missing UVs", ob.name))
            elif len(me.polygons) < 20000 and uv_area(me) > 1.02:
                rep["warnings"].append(("Overlapping UVs", ob.name))
        area = sum(p.area for p in me.polygons) or 1e-6
        if nt > 150000 or (nt / area > 60000 and nt > 5000):
            rep["warnings"].append(("Excessive Polygon Density", "%s (%d tris, %.0f/m2)" % (ob.name, nt, nt / area)))
    for m in bpy.data.materials:
        if m.users == 0 or m.name.startswith("RT_"):
            continue
        e, w, info = _mat_issues(m)
        rep["materials"][m.name] = {"errors": e, "warnings": w, **info, "users": m.users - (1 if m.use_fake_user else 0)}
        for x in e:
            rep["errors"].append((x, m.name))
        for x in w:
            rep["warnings"].append((x, m.name))
    rep["status"] = "PASS" if not rep["errors"] else "FAIL"
    rep["seconds"] = round(time.time() - t0, 2)
    sugg = []
    kinds = {}
    for k, _ in rep["warnings"]:
        kinds[k] = kinds.get(k, 0) + 1
    if kinds.get("Missing UVs"):
        sugg.append("Run 'Prepare Movie Assets' or the GLB export (both auto-unwrap) before baking.")
    if kinds.get("Excessive Polygon Density"):
        sugg.append("Generate LOD versions or lower bevel segments on dense parts.")
    if kinds.get("Improper Naming"):
        sugg.append("Rename objects to PREFIX_Part_Material (e.g. PHMA1_EXT_Boom_CFRP) so auto-assignment is exact.")
    if rep["tris"] > 3_000_000:
        sugg.append("Scene is over 3M triangles: enable Persistent Data and use LOD1 for distant shots.")
    if not sugg:
        sugg.append("No optimisation needed.")
    rep["suggestions"] = sugg
    rep["summary_counts"] = kinds
    if write_text:
        txt = bpy.data.texts.get("LMSP_Validation_Report") or bpy.data.texts.new("LMSP_Validation_Report")
        txt.clear()
        L = ["LUNAR MATERIAL STUDIO PRO - SCENE VALIDATION", "=" * 46,
             "Status: %s   Objects: %d   Triangles: %d   Time: %.2fs" % (rep["status"], rep["objects"], rep["tris"], rep["seconds"]),
             "", "ERRORS (%d)" % len(rep["errors"])]
        L += ["  x %s: %s" % e for e in rep["errors"][:400]]
        L += ["", "WARNINGS (%d)" % len(rep["warnings"])]
        for k, v in sorted(kinds.items()):
            L.append("  ! %-28s %d" % (k, v))
        L += ["  ! %s: %s" % w for w in rep["warnings"][:300]]
        L += ["", "OPTIMISATION SUGGESTIONS"] + ["  - " + s for s in sugg]
        txt.write("\n".join(L))
    if write_json_dir:
        os.makedirs(write_json_dir, exist_ok=True)
        with open(os.path.join(write_json_dir, "validation_report.json"), "w") as f:
            json.dump(rep, f, indent=1, default=str)
    return rep


# ------------------------------------------------------------------ render optimisation
def optimize_for_rendering(scene):
    c = scene.cycles
    scene.render.engine = 'CYCLES'
    c.use_adaptive_sampling = True
    c.adaptive_threshold = 0.01
    c.use_denoising = True
    try:
        c.denoiser = 'OPENIMAGEDENOISE'
    except Exception:
        pass
    c.caustics_reflective = False
    c.caustics_refractive = False
    c.max_bounces = 12
    c.volume_bounces = 4
    c.blur_glossy = 0.5
    scene.render.use_persistent_data = False  # persistent data drops bone-parented linked duplicates with motion blur (5.2)
    try:
        c.use_light_tree = True
    except Exception:
        pass
    for cn in ("LMSP_Preview", "LMSP_Comparison", "LMSP_LODs", "LMSP_ExportTemp"):
        col = bpy.data.collections.get(cn)
        if col:
            col.hide_render = True
    return "Adaptive sampling, OIDN, light tree, persistent data off (stability); caustics off; helper collections hidden."


def unwrap(objs):
    vl = bpy.context.view_layer
    meshes = [o for o in objs if o.type == 'MESH' and not o.get("lmsp_decal") and o.name in vl.objects]
    todo = [o for o in meshes if not o.data.uv_layers]
    if not todo:
        return 0
    prev = vl.objects.active
    bpy.ops.object.select_all(action='DESELECT')
    uniq = {}
    for o in todo:
        uniq.setdefault(o.data.name, o)
    for o in uniq.values():
        o.hide_set(False)
        o.select_set(True)
    vl.objects.active = list(uniq.values())[0]
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=1.15, island_margin=0.004)
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    vl.objects.active = prev
    return len(uniq)


def mark_assets(names_tags):
    n = 0
    for cname, desc, tags in names_tags:
        col = bpy.data.collections.get(cname)
        if not col:
            continue
        try:
            col.asset_mark()
            col.asset_data.description = desc
            for t in tags:
                if t not in col.asset_data.tags:
                    col.asset_data.tags.new(t)
            n += 1
        except Exception:
            pass
    return n


def generate_lods(objs, ratios=(0.5, 0.2)):
    col = bpy.data.collections.get("LMSP_LODs")
    if not col:
        col = bpy.data.collections.new("LMSP_LODs")
        bpy.context.scene.collection.children.link(col)
    col.hide_render = True
    col.hide_viewport = True
    made = 0
    dg = bpy.context.evaluated_depsgraph_get()
    for ob in objs:
        if ob.type != 'MESH' or ob.get("lmsp_lod") or ob.get("lmsp_decal") or len(ob.data.polygons) < 64:
            continue
        for i, r in enumerate(ratios, 1):
            nm = "%s_LOD%d" % (ob.name, i)
            if nm in bpy.data.objects:
                continue
            me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
            lo = bpy.data.objects.new(nm, me)
            col.objects.link(lo)
            lo.matrix_world = ob.matrix_world.copy()
            dm = lo.modifiers.new("LOD_Decimate", 'DECIMATE')
            dm.ratio = r
            lo["lmsp_lod"] = i
            lo["lmsp_lod_source"] = ob.name
            made += 1
    return made


# ------------------------------------------------------------------ GLB export
def _rt_material(src, baked=None):
    key = "RT_" + src.name + ("_" + baked["tag"] if baked else "")
    m = bpy.data.materials.get(key)
    if m:
        return m
    m = bpy.data.materials.new(key)
    try:
        m.use_nodes = True
    except Exception:
        pass
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (600, 0)
    b = nt.nodes.new("ShaderNodeBsdfPrincipled")
    b.location = (200, 0)
    nt.links.new(b.outputs[0], out.inputs[0])
    base = src.get("lmsp_rt_base", [0.6, 0.6, 0.6])
    b.inputs["Base Color"].default_value = (base[0], base[1], base[2], 1)
    b.inputs["Metallic"].default_value = float(src.get("lmsp_rt_metal", 0.0))
    b.inputs["Roughness"].default_value = float(src.get("lmsp_rt_rough", 0.5))
    es = float(src.get("lmsp_rt_emit_strength", 0.0))
    if es > 0:
        e = src.get("lmsp_rt_emit", [0, 0, 0])
        b.inputs["Emission Color"].default_value = (e[0], e[1], e[2], 1)
        b.inputs["Emission Strength"].default_value = min(es, 20.0)
    tr = float(src.get("lmsp_rt_transmission", 0.0))
    al = float(src.get("lmsp_rt_alpha", 1.0))
    if tr > 0:
        b.inputs["Transmission Weight"].default_value = tr
    if al < 1.0:
        b.inputs["Alpha"].default_value = al
    imgname = src.get("lmsp_rt_image")
    if imgname and imgname in bpy.data.images:
        t = nt.nodes.new("ShaderNodeTexImage")
        t.location = (-300, 0)
        t.image = bpy.data.images[imgname]
        nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
        nt.links.new(t.outputs["Alpha"], b.inputs["Alpha"])
    if baked:
        def tex(img, y, noncolor=False):
            t = nt.nodes.new("ShaderNodeTexImage")
            t.location = (-400, y)
            t.image = img
            if noncolor:
                img.colorspace_settings.name = 'Non-Color'
            return t
        nt.links.new(tex(baked["base"], 300).outputs["Color"], b.inputs["Base Color"])
        sep = nt.nodes.new("ShaderNodeSeparateColor")
        sep.location = (-100, 0)
        nt.links.new(tex(baked["orm"], 0, True).outputs["Color"], sep.inputs[0])
        nt.links.new(sep.outputs[1], b.inputs["Roughness"])
        nt.links.new(sep.outputs[2], b.inputs["Metallic"])
        nm = nt.nodes.new("ShaderNodeNormalMap")
        nm.location = (-100, -300)
        nt.links.new(tex(baked["normal"], -300, True).outputs["Color"], nm.inputs["Color"])
        nt.links.new(nm.outputs[0], b.inputs["Normal"])
    m["lmsp_rt"] = 1
    return m


def _effective_bone(ob):
    o = ob
    while o is not None:
        if o.parent and o.parent.type == 'ARMATURE':
            return o.parent, (o.parent_bone if o.parent_type == 'BONE' else "")
        o = o.parent
    return None, ""


BAKE_SKIP_TYPES = {"Emissive", "Optical", "Fluid", "Decal", "Celestial"}


def _bake_group(ob, src_mat, res, tex_dir, tag):
    """Bake base colour, ORM (R=1,G=rough,B=metal) and tangent normal from the procedural material."""
    scene = bpy.context.scene
    work = src_mat.copy()
    ob.data.materials.clear()
    ob.data.materials.append(work)
    nt = work.node_tree
    imgs = {}
    for k, nc in (("base", False), ("rough", True), ("metal", True), ("normal", True)):
        img = bpy.data.images.new("BK_%s_%s" % (tag, k), res, res, alpha=False, float_buffer=False)
        if nc:
            img.colorspace_settings.name = 'Non-Color'
        imgs[k] = img
    tnode = nt.nodes.new("ShaderNodeTexImage")
    tnode.location = (2000, 600)
    bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    out = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
    vl = bpy.context.view_layer
    bpy.ops.object.select_all(action='DESELECT')
    ob.select_set(True)
    vl.objects.active = ob

    def do(kind, img, **kw):
        tnode.image = img
        nt.nodes.active = tnode
        bpy.ops.object.bake(type=kind, margin=6, use_clear=True, **kw)

    do('DIFFUSE', imgs["base"], pass_filter={'COLOR'})
    do('ROUGHNESS', imgs["rough"])
    do('NORMAL', imgs["normal"])
    if bsdf is not None and out is not None:
        em = nt.nodes.new("ShaderNodeEmission")
        mi = bsdf.inputs["Metallic"]
        if mi.is_linked:
            nt.links.new(mi.links[0].from_socket, em.inputs["Color"])
        else:
            v = mi.default_value
            em.inputs["Color"].default_value = (v, v, v, 1)
        old = out.inputs["Surface"].links[0].from_socket if out.inputs["Surface"].is_linked else None
        nt.links.new(em.outputs[0], out.inputs["Surface"])
        do('EMIT', imgs["metal"])
        if old is not None:
            nt.links.new(old, out.inputs["Surface"])
    # pack R=1 (AO), G=rough, B=metal into one ORM image (glTF convention)
    import numpy as np
    n = res * res * 4
    r = np.empty(n, np.float32); imgs["rough"].pixels.foreach_get(r)
    mt = np.empty(n, np.float32); imgs["metal"].pixels.foreach_get(mt)
    orm = np.ones(n, np.float32)
    orm[1::4] = r[0::4]
    orm[2::4] = mt[0::4]
    oimg = bpy.data.images.new("BK_%s_orm" % tag, res, res, alpha=False)
    oimg.colorspace_settings.name = 'Non-Color'
    oimg.pixels.foreach_set(orm)
    res_imgs = {"base": imgs["base"], "orm": oimg, "normal": imgs["normal"], "tag": tag}
    os.makedirs(tex_dir, exist_ok=True)
    for k in ("base", "orm", "normal"):
        im = res_imgs[k]
        im.filepath_raw = os.path.join(tex_dir, im.name + ".png")
        im.file_format = 'PNG'
        im.save()
    for k in ("rough", "metal"):
        bpy.data.images.remove(imgs[k])
    ob.data.materials.clear()
    bpy.data.materials.remove(work)
    return res_imgs


def export_glb(variant, source_collections, rigs, filepath, bake=True, max_res=1024, lod_ratio=None,
               extra_objects=None, log=None):
    """Merge parts per (bone, material), bake procedural materials, export rig + animations to GLB."""
    scene = bpy.context.scene
    vl = bpy.context.view_layer
    t0 = time.time()
    prev_engine = scene.render.engine
    prev_samples = scene.cycles.samples
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 8
    scene.cycles.use_denoising = False
    try:
        scene.cycles.device = 'GPU'
    except Exception:
        pass
    for r in rigs:
        r.data.pose_position = 'REST'
    bpy.context.view_layer.update()
    tmp = bpy.data.collections.get("LMSP_ExportTemp") or bpy.data.collections.new("LMSP_ExportTemp")
    if tmp.name not in scene.collection.children:
        scene.collection.children.link(tmp)
    srcs = []
    for cn in source_collections:
        c = bpy.data.collections.get(cn)
        if c:
            srcs += [o for o in c.all_objects if o.type in {'MESH', 'CURVE', 'FONT'} and not o.hide_render]
    srcs += list(extra_objects or [])
    srcs = list(dict.fromkeys(srcs))
    dg = bpy.context.evaluated_depsgraph_get()
    groups = {}
    for ob in srcs:
        mat = ob.material_slots[0].material if ob.material_slots and ob.material_slots[0].material else None
        rig, bone = _effective_bone(ob)
        if rig is not None and rig not in rigs:
            continue
        key = (rig.name if rig else "", bone, mat.name if mat else "None")
        groups.setdefault(key, []).append(ob)
    made = []
    tex_dir = os.path.join(os.path.dirname(filepath), "textures", variant)
    for (rname, bone, mname), obs in groups.items():
        bm = bmesh.new()
        for ob in obs:
            me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
            me.transform(ob.matrix_world)
            bm.from_mesh(me)
            bpy.data.meshes.remove(me)
        for f in bm.faces:
            f.material_index = 0
        if len(bm.faces) == 0:
            bm.free()
            continue
        short = re.sub(r"^PHMA_", "", mname)
        nm = "%s_%s_%s" % (variant, bone or "Static", short)
        me = bpy.data.meshes.new(nm)
        bm.to_mesh(me)
        bm.free()
        jo = bpy.data.objects.new(nm, me)
        tmp.objects.link(jo)
        src_mat = bpy.data.materials.get(mname)
        if src_mat:
            me.materials.append(src_mat)
        if lod_ratio:
            dm = jo.modifiers.new("LOD", 'DECIMATE')
            dm.ratio = lod_ratio
            vl.update()
            m2 = bpy.data.meshes.new_from_object(jo.evaluated_get(bpy.context.evaluated_depsgraph_get()))
            jo.modifiers.clear()
            old = jo.data
            jo.data = m2
            bpy.data.meshes.remove(old)
            me = jo.data
            if src_mat and not me.materials:
                me.materials.append(src_mat)
        baked = None
        mtype = src_mat.get("lmsp_type") if src_mat else None
        if bake and src_mat and src_mat.get("lmsp_generated") and mtype not in BAKE_SKIP_TYPES:
            area = sum(p.area for p in me.polygons)
            res = 256 if area < 0.05 else 512 if area < 0.6 else 1024 if area < 4 else 2048
            res = min(res, max_res)
            while me.uv_layers:
                me.uv_layers.remove(me.uv_layers[0])
            me.uv_layers.new(name="UVMap")
            bpy.ops.object.select_all(action='DESELECT')
            jo.select_set(True)
            vl.objects.active = jo
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.smart_project(angle_limit=1.15, island_margin=0.006)
            bpy.ops.object.mode_set(mode='OBJECT')
            try:
                baked = _bake_group(jo, src_mat, res, tex_dir, nm)
            except Exception as e:
                if log is not None:
                    log.append("bake failed %s: %s" % (nm, e))
                baked = None
        rt = _rt_material(src_mat, baked) if src_mat else None
        me.materials.clear()
        if rt:
            me.materials.append(rt)
        if rname:
            rig = bpy.data.objects[rname]
            jo.parent = rig
            if bone:
                jo.parent_type = 'BONE'
                jo.parent_bone = bone
                pb = rig.pose.bones[bone]
                pm = rig.matrix_world @ pb.matrix @ Matrix.Translation((0, pb.bone.length, 0))
            else:
                pm = rig.matrix_world.copy()
            jo.matrix_parent_inverse = pm.inverted()
        made.append(jo)
    for r in rigs:
        r.data.pose_position = 'POSE'
    bpy.ops.object.select_all(action='DESELECT')
    for o in made:
        o.select_set(True)
    for r in rigs:
        r.hide_set(False)
        r.select_set(True)
    vl.objects.active = rigs[0] if rigs else (made[0] if made else None)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    kw = dict(filepath=filepath, export_format='GLB', use_selection=True, export_apply=True,
              export_yup=True, export_texcoords=True, export_normals=True, export_materials='EXPORT',
              export_image_format='AUTO', export_animations=bool(rigs),
              use_active_scene=True)  # 5.2 otherwise writes every scene with a selected object
    if rigs:
        kw.update(export_animation_mode='ACTIONS', export_force_sampling=True, export_frame_step=1)
    ok, err = True, ""
    try:
        bpy.ops.export_scene.gltf(**kw)
    except TypeError:
        kw.pop("export_animation_mode", None)
        kw.pop("use_active_scene", None)
        bpy.ops.export_scene.gltf(**kw)
    except Exception as e:
        ok, err = False, str(e)
    tris = sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in made)
    for o in made:
        me = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if me.users == 0:
            bpy.data.meshes.remove(me)
    for m in list(bpy.data.materials):
        if m.name.startswith("RT_") and m.users == 0:
            bpy.data.materials.remove(m)
    scene.render.engine = prev_engine
    scene.cycles.samples = prev_samples
    scene.cycles.use_denoising = True
    size = os.path.getsize(filepath) if os.path.exists(filepath) else 0
    return {"ok": ok, "err": err, "file": filepath, "meshes": len(made), "tris": tris,
            "mb": round(size / 1048576, 2), "sec": round(time.time() - t0, 1)}


# ------------------------------------------------------------------ one-click flows
def auto_configure(context, scope='ALL'):
    if "PHMA_Titanium" not in bpy.data.materials:
        build_library(context.scene)
    objs = target_objects(context, scope)
    st = assign_materials(objs)
    apply_dust(objs)
    apply_wear(objs)
    return st


def prepare_movie_assets(context):
    st = auto_configure(context)
    msg = optimize_for_rendering(context.scene)
    n = mark_assets([
        ("PHMA1_Exterior", "PHMA-1 Primary Habitat Engineering Arm - exterior variant", ["robotics", "arm", "exterior"]),
        ("PHMA1_Interior", "PHMA-1i interior service arm (0.4 scale)", ["robotics", "arm", "interior"]),
        ("PHMA_ToolHeads", "PHMA-1 interchangeable end effectors", ["tools", "end-effector"]),
        ("MMR_MicroRobots", "Type 2 micro maintenance robots", ["robotics", "micro"]),
        ("EVA_ExteriorRobots", "Type 3 EVA exterior robots", ["robotics", "rover"]),
    ])
    return "%d objects configured, %d collections marked as assets. %s" % (st["assigned"], n, msg)
