"""Lighting environment presets. Physically motivated: no atmosphere on the Moon, so sunrise
light stays white (5600 K), the sky stays black, and stars are camera-only (they do not light the scene)."""
import bpy, math
from mathutils import Vector
from .core import NB, LED_PROP, main_scene

LIGHT_COLL = "LMSP_Lighting"
SUN_ANGLE = math.radians(0.53)   # true solar disc as seen from the Moon


def kelvin(k):
    t = k / 100.0
    r = 255 if t <= 66 else 329.698727446 * ((t - 60) ** -0.1332047592)
    g = 99.4708025861 * math.log(t) - 161.1195681661 if t <= 66 else 288.1221695283 * ((t - 60) ** -0.0755148492)
    b = 255 if t >= 66 else (0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307)
    c = [max(0, min(255, x)) / 255.0 for x in (r, g, b)]
    return tuple(x ** 2.2 for x in c)


def _coll(scene):
    col = bpy.data.collections.get(LIGHT_COLL)
    if not col:
        col = bpy.data.collections.new(LIGHT_COLL)
    if col.name not in scene.collection.children:
        scene.collection.children.link(col)
    return col


def clear(scene):
    col = _coll(scene)
    for o in list(col.objects):
        d = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if d and d.users == 0:
            bpy.data.lights.remove(d)


def light(scene, name, kind, energy, color, loc=(0, 0, 0), direction=None, size=None, angle=None, spot=None):
    ld = bpy.data.lights.new(name, kind)
    ld.energy = energy
    ld.color = color
    if kind == 'SUN':
        ld.angle = SUN_ANGLE if angle is None else angle
    if kind == 'AREA' and size:
        ld.shape = 'RECTANGLE'
        ld.size, ld.size_y = size
    if kind == 'SPOT' and spot:
        ld.spot_size = spot
        ld.spot_blend = 0.4
    if kind in ('POINT', 'SPOT') and size:
        ld.shadow_soft_size = size
    ob = bpy.data.objects.new(name, ld)
    _coll(scene).objects.link(ob)
    ob.location = loc
    if direction is not None:
        d = Vector(direction).normalized()
        ob.rotation_euler = Vector((0, 0, 1)).rotation_difference(d).to_euler()
    ob["lmsp_env_light"] = 1
    return ob


def sun_vector(elev, az):
    e, a = math.radians(elev), math.radians(az)
    return Vector((math.cos(e) * math.sin(a), math.cos(e) * math.cos(a), math.sin(e)))


def world_space(scene, star_strength=1.0, name="LMSP_World_Space"):
    w = bpy.data.worlds.get(name) or bpy.data.worlds.new(name)
    try:
        w.use_nodes = True
    except Exception:
        pass
    nt = w.node_tree
    nt.nodes.clear()
    nb = NB(nt)
    out = nb.new("ShaderNodeOutputWorld", 900, 0)
    bg = nb.new("ShaderNodeBackground", 700, 0)
    tc = nb.new("ShaderNodeTexCoord", -900, 0)
    v = nb.voronoi(tc.outputs["Generated"], 700.0, 'F1', 1.0, -700, 0)
    pts = nb.mr(v.outputs["Distance"], 0.045, 0.0, x=-500, y=0)
    bright = nb.math('POWER', nb.sep(v.outputs["Color"], -500, -200).outputs[0], 8.0, x=-350, y=-200)
    stars = nb.math('MULTIPLY', nb.math('POWER', pts, 3.0, x=-350, y=0), nb.math('MULTIPLY', bright, 6.0, x=-200, y=-200), x=-150, y=0)
    tint = nb.ramp(nb.sep(v.outputs["Color"], -500, -400).outputs[1], [(0.0, (0.75, 0.82, 1.0)), (0.6, (1, 1, 1)), (1.0, (1.0, 0.85, 0.65))], -350, -400)
    band = nb.mr(nb.math('ABSOLUTE', nb.sep(nb.vmath('NORMALIZE', tc.outputs["Generated"], x=-700, y=-600), -550, -600).outputs[2],
                         x=-400, y=-600), 0.35, 0.0, 0.0, 0.035, -250, -600)
    mw = nb.math('MULTIPLY', band, nb.noise(tc.outputs["Generated"], 3.0, 8, 0.6, x=-400, y=-800).outputs["Fac"], x=-100, y=-650)
    col = nb.mixc(stars, (0, 0, 0), tint, x=100, y=-100)
    col = nb.mixc(mw, col, (0.5, 0.52, 0.6), 'ADD', x=250, y=-100)
    lp = nb.new("ShaderNodeLightPath", 100, 300)
    strength = nb.math('MULTIPLY', lp.outputs["Is Camera Ray"], star_strength, x=400, y=200)
    nb.l.new(col, bg.inputs["Color"])
    nb.l.new(strength, bg.inputs["Strength"])
    nb.l.new(bg.outputs[0], out.inputs["Surface"])
    scene.world = w
    return w


def world_studio(scene):
    w = bpy.data.worlds.get("LMSP_World_Studio") or bpy.data.worlds.new("LMSP_World_Studio")
    try:
        w.use_nodes = True
    except Exception:
        pass
    nt = w.node_tree
    nt.nodes.clear()
    nb = NB(nt)
    out = nb.new("ShaderNodeOutputWorld", 600, 0)
    bg = nb.new("ShaderNodeBackground", 400, 0)
    tc = nb.new("ShaderNodeTexCoord", -600, 0)
    z = nb.sep(nb.vmath('NORMALIZE', tc.outputs["Generated"], x=-400, y=0), -250, 0).outputs[2]
    col = nb.ramp(nb.mr(z, -0.3, 0.8, x=-100, y=0), [(0.0, (0.03, 0.03, 0.035)), (1.0, (0.32, 0.34, 0.37))], 100, 0)
    nb.l.new(col, bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 1.0
    nb.l.new(bg.outputs[0], out.inputs["Surface"])
    scene.world = w
    return w


def _earth_dir(fallback=(0.25, -0.9, 0.12)):
    e = bpy.data.objects.get("ENV_Earth")
    if e:
        return (e.matrix_world.translation - Vector((0, 0, 0))).normalized()
    return Vector(fallback).normalized()


def _interior_origin():
    o = bpy.data.objects.get("SET_Interior_Origin")
    return o.matrix_world.translation.copy() if o else Vector((0, 70, 0))


PRESET_ITEMS = [
    ('EARTH_STUDIO', "Earth Studio Lighting", "Neutral three-point studio for material review"),
    ('MOON_NOON', "Moon Noon", "High sun, hard shadows, black sky"),
    ('MOON_SUNRISE', "Moon Sunrise", "Grazing white sunlight from the east, Earth low on the horizon"),
    ('MOON_SUNSET', "Moon Sunset", "Grazing sunlight from the west"),
    ('LUNAR_NIGHT', "Lunar Night", "No sun: near-full earthshine plus habitat floodlights"),
    ('STORM_SHELTER', "Storm Shelter Interior", "Dim warm LEDs inside the water-walled shelter"),
    ('GREENHOUSE', "Greenhouse Interior", "Red/blue grow light spectrum with white task lights"),
    ('EMERGENCY', "Emergency Lighting", "Red emergency lighting, fleet LEDs to EMERGENCY"),
    ('RADIATION_STORM', "Radiation Storm", "Solar particle event: amber warning lighting, LEDs to WARNING"),
]


def apply_preset(scene, key):
    clear(scene)
    vs = scene.view_settings
    try:
        vs.view_transform = 'AgX'
        vs.look = 'AgX - Medium High Contrast'
    except Exception:
        pass
    vs.exposure = 0.0
    sun5600 = kelvin(5600)
    ed = _earth_dir()
    led = 0.0
    if key == 'EARTH_STUDIO':
        world_studio(scene)
        light(scene, "LGT_Key", 'AREA', 1500, kelvin(5600), (6, -6, 7), (6, -6, 7), size=(3, 3))
        light(scene, "LGT_Fill", 'AREA', 500, kelvin(6500), (-7, -4, 4), (-7, -4, 4), size=(4, 4))
        light(scene, "LGT_Rim", 'AREA', 1200, kelvin(7000), (0, 8, 6), (0, 8, 6), size=(2, 6))
    elif key in ('MOON_NOON', 'MOON_SUNRISE', 'MOON_SUNSET', 'RADIATION_STORM'):
        world_space(scene, 0.6)
        elev, az = {'MOON_NOON': (55, 160), 'MOON_SUNRISE': (1.6, 72), 'MOON_SUNSET': (2.0, 288),
                    'RADIATION_STORM': (12, 120)}[key]
        light(scene, "LGT_Sun", 'SUN', 5.5, sun5600, direction=sun_vector(elev, az))
        light(scene, "LGT_Earthshine", 'SUN', 0.15, (0.55, 0.7, 1.0), direction=ed, angle=math.radians(2.0))
        if key == 'RADIATION_STORM':
            led = 2.0
            o = _interior_origin()
            light(scene, "LGT_Alert_A", 'AREA', 300, (1.0, 0.55, 0.1), o + Vector((0, 0, 3.6)), (0, 0, 1), size=(8, 0.6))
    elif key == 'LUNAR_NIGHT':
        world_space(scene, 1.2)
        light(scene, "LGT_Earthshine", 'SUN', 0.15, (0.55, 0.7, 1.0), direction=ed, angle=math.radians(2.0))
        vs.exposure = 2.5
    elif key in ('STORM_SHELTER', 'GREENHOUSE', 'EMERGENCY'):
        world_space(scene, 0.3)
        o = _interior_origin()
        if key == 'STORM_SHELTER':
            for i, x in enumerate((-5, 0, 5)):
                light(scene, "LGT_Shelter_%d" % i, 'AREA', 220, kelvin(3500), o + Vector((x, 0, 3.7)), (0, 0, 1), size=(2.4, 0.4))
        elif key == 'GREENHOUSE':
            for i, x in enumerate((-4, 0, 4)):
                light(scene, "LGT_Grow_%d" % i, 'AREA', 400, (1.0, 0.35, 0.8), o + Vector((x, 1.0, 3.5)), (0, 0, 1), size=(3, 0.5))
            light(scene, "LGT_Task", 'AREA', 250, kelvin(5000), o + Vector((0, -1.0, 3.7)), (0, 0, 1), size=(8, 0.4))
        else:
            led = 3.0
            for i, x in enumerate((-5, 0, 5)):
                light(scene, "LGT_Emergency_%d" % i, 'AREA', 260, (1.0, 0.06, 0.03), o + Vector((x, 0, 3.7)), (0, 0, 1), size=(1.5, 0.4))
            vs.exposure = 0.5
    scene[LED_PROP] = led
    scene["lmsp_env"] = key
    return key
