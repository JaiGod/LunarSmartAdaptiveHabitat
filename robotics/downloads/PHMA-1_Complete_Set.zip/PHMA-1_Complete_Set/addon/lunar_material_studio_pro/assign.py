"""Automatic material assignment: names -> tokens -> material, then collection, then fallback."""
import bpy, re
from .materials import build_library, LIBRARY_NAMES, CATEGORY

# token -> material.  Tokens are scanned from the END of the object name, so the
# most specific suffix wins: "ElbowCam_Housing" -> Housing -> CFRP,
# "ElbowCam_Lens" -> Lens -> lens optic.
TOKEN_RULES = {
    "PHMA_Titanium": ["titanium", "frame", "structural", "beam", "support", "bracket", "bolt", "bolts", "bolting",
                      "fastener", "fasteners", "nut", "clevis", "yoke", "fitting", "collar", "band", "flange", "lug",
                      "plate", "chassis", "mount", "ring", "strut", "hinge", "pin", "pins", "truss", "coupling",
                      "deck", "rocker", "bogie", "leg", "jaw", "jaws", "finger", "fingers", "chuck", "blade", "patch"],
    "PHMA_CarbonFiber": ["carbon", "cfrp", "panel", "housing", "cover", "shroud", "boom", "segment", "tube", "fairing"],
    "PHMA_OpticalGlass": ["glass", "sensor", "camera", "viewport", "window", "dome", "porthole"],
    "PHMA_LensOptic": ["lens", "optic", "optics", "aperture"],
    "PHMA_ChromeHydraulic": ["hydraulic", "piston", "actuator", "cylinder", "rod", "chrome"],
    "PHMA_AnodizedBlack": ["motor", "gearbox", "drive", "anodized", "barrel", "servo", "reducer", "spool", "electronics",
                           "avionics", "box", "body"],
    "PHMA_KevlarWire": ["wire", "cable", "harness", "conduit", "sleeve", "kevlar", "umbilical", "hose"],
    "PHMA_LED": ["led", "status", "indicator", "warning", "beacon"],
    "PHMA_MLI_Gold": ["mli", "blanket", "kapton", "foil"],
    "PHMA_MLI_Silver": ["mylar", "mlisilver"],
    "PHMA_BetaCloth": ["beta", "betacloth"],
    "PHMA_RadiatorOSR": ["radiator", "osr"],
    "PHMA_DustBellows": ["bellows", "boot", "skirt"],
    "PHMA_RubberSeal": ["seal", "wiper", "gasket", "pad", "pads", "bumper", "grommet"],
    "PHMA_Ceramic": ["bearing", "ceramic", "insulator", "insulators"],
    "PHMA_RailTrack": ["rail", "rails", "track", "tie", "ties", "sleeper"],
    "PHMA_Copper": ["busbar", "copper", "conductor", "collector"],
    "PHMA_SolarCell": ["solar", "pv", "cells"],
    "PHMA_PaintYellow": ["handrail", "handhold", "yellow", "grab"],
    "PHMA_PaintHazard": ["hazard", "stripe", "stripes"],
    "PHMA_PaintRed": ["red", "paintred", "estop"],
    "PHMA_PaintWhite": ["paint", "white", "thermalpaint", "cowl"],
    "PHMA_WeldSeam": ["weld", "seam", "bead"],
    "PHMA_WeldHeatTint": ["haz", "heattint"],
    "PHMA_Regolith": ["regolith", "terrain", "ground", "berm", "surface"],
    "PHMA_RegolithBlock": ["brick", "bricks", "block", "blocks", "sandbag", "sandbags"],
    "PHMA_LunarDust": ["dust", "powder"],
    "PHMA_Water": ["water", "fluid", "coolant"],
    "PHMA_WaterShield": ["watershield", "bladder", "bladders"],
    "PHMA_Acrylic": ["acrylic", "tank"],
    "PHMA_ScreenUI": ["screen", "display", "monitor", "hmi"],
    "PHMA_PlantLeaf": ["leaf", "leaves", "plant", "plants", "foliage", "crop"],
    "PHMA_GrowLight": ["growlight", "growlights"],
    "PHMA_LightPanel": ["light", "lamp", "emitter", "lightpanel"],
    "PHMA_WheelMesh": ["wheel", "wheels", "chevron", "grouser", "tire"],
    "PHMA_HabitatShell": ["hull", "shell", "module", "habitat", "hab"],
    "PHMA_InteriorPanel": ["interiorpanel", "liner", "wall", "floor", "ceiling", "rack"],
    "PHMA_Aluminum": ["aluminum", "aluminium", "alu", "manifold", "valve", "pump", "frameal"],
    "PHMA_Earth": ["earth"],
    "PHMA_EarthClouds": ["clouds"],
    "PHMA_EarthAtmosphere": ["atmosphere"],
    "PHMA_ImpactDamage": ["damage", "crater", "breach"],
    "PHMA_Spark": ["spark", "sparks"],
    "PHMA_WeldGlow": ["glow", "plasma"],
    "PHMA_ImpactFlash": ["flash"],
    "PHMA_DustMote": ["mote", "motes"],
}
TOKEN_TO_MAT = {}
for mat, toks in TOKEN_RULES.items():
    for t in toks:
        TOKEN_TO_MAT.setdefault(t, mat)

COLLECTION_RULES = [
    ("habitat", "PHMA_HabitatShell"), ("aquaponics", "PHMA_Acrylic"), ("hydroponics", "PHMA_Aluminum"),
    ("radiation", "PHMA_WaterShield"), ("water", "PHMA_Aluminum"), ("medical", "PHMA_PaintWhite"),
    ("rover", "PHMA_Titanium"), ("eva", "PHMA_Titanium"), ("micro", "PHMA_Aluminum"),
    ("robot", "PHMA_Titanium"), ("phma", "PHMA_Titanium"), ("environment", "PHMA_Regolith"),
    ("server", "PHMA_AnodizedBlack"), ("solar", "PHMA_SolarCell"), ("airlock", "PHMA_HabitatShell"),
]

EXTERIOR_HINTS = ("ext", "exterior", "eva", "environment", "outdoor", "surface", "solar", "track_exterior")
NAME_OK = re.compile(r"^(PHMA1?I?|PHMA|MMR\d?|EVA\d?|LSAH|ENV|CAM|LGT|LMSP|TL\d\d|RIG|SET)[A-Za-z0-9]*_")


def tokens(name):
    name = re.sub(r"\.\d+$", "", name)
    parts = re.split(r"[^A-Za-z0-9]+", name)
    out = []
    for p in parts:
        out.extend(x.lower() for x in re.findall(r"[A-Z]+(?![a-z])|[A-Z]?[a-z]+|\d+", p) if x)
        out.append(p.lower())
    return [t for t in out if t]


def resolve_material(ob):
    explicit = ob.get("lmsp_material")
    if explicit:
        return explicit, "explicit"
    for t in reversed(tokens(ob.name)):
        if t in TOKEN_TO_MAT:
            return TOKEN_TO_MAT[t], "name:" + t
    for c in ob.users_collection:
        cn = c.name.lower()
        for key, mat in COLLECTION_RULES:
            if key in cn:
                return mat, "collection:" + c.name
    if ob.data and hasattr(ob.data, "polygons") and len(ob.data.polygons):
        dims = ob.dimensions
        if dims.z < 0.02 * max(dims.x, dims.y, 1e-6):
            return "PHMA_InteriorPanel", "geometry:flat"
    return "PHMA_Titanium", "fallback"


def is_exterior(ob):
    if "lmsp_exterior" in ob.keys():
        return bool(ob["lmsp_exterior"])
    toks = set(tokens(ob.name))
    if toks & {"ext", "exterior", "eva"}:
        return True
    for c in ob.users_collection:
        cn = c.name.lower()
        if any(h in cn for h in EXTERIOR_HINTS) and "interior" not in cn:
            return True
    return False


def target_objects(context, scope='ALL'):
    if scope == 'SELECTED':
        obs = list(context.selected_objects)
    elif scope == 'COLLECTION' and context.collection:
        obs = list(context.collection.all_objects)
    else:
        obs = list(context.scene.objects)
    return [o for o in obs if o.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'} and not o.get("lmsp_preview")]


def assign_materials(objs, overwrite=True):
    if "PHMA_Titanium" not in bpy.data.materials:
        build_library()
    stats = {"assigned": 0, "kept": 0, "missing": [], "by_material": {}, "fallback": []}
    for ob in objs:
        name, why = resolve_material(ob)
        mat = bpy.data.materials.get(name)
        if mat is None:
            stats["missing"].append((ob.name, name))
            continue
        slots = ob.material_slots
        cur = slots[0].material if len(slots) else None
        if cur is not None and not overwrite and not cur.name.startswith("PHMA_"):
            stats["kept"] += 1
            continue
        if cur is not None and cur.name.startswith("PHMA_Decal"):
            stats["kept"] += 1
            continue
        if len(slots) == 0:
            ob.data.materials.append(mat)
        else:
            for s in slots:
                if s.material is None or overwrite or s.material.name.startswith("PHMA_"):
                    s.material = mat
        ob["lmsp_assigned_by"] = why
        ob["lmsp_category"] = mat.get("lmsp_type", "")
        stats["assigned"] += 1
        stats["by_material"][name] = stats["by_material"].get(name, 0) + 1
        if why == "fallback":
            stats["fallback"].append(ob.name)
    return stats


DUST_HIGH = {"rail", "rails", "track", "tie", "deck", "platform", "chassis", "regolith", "berm", "terrain", "skirt",
             "bellows", "boot", "wheel", "wheels", "solar", "top", "step", "blade", "pylon"}
DUST_LOW = {"rod", "piston", "chrome", "bearing", "lens", "glass", "camera", "coupling", "led", "screen", "pads", "pad"}
WEAR_HIGH = {"rail", "wheel", "wheels", "pad", "pads", "coupling", "handrail", "handhold", "jaw", "jaws", "finger",
             "chuck", "blade", "grab", "collector", "bogie"}


def apply_dust(objs):
    n = 0
    for ob in objs:
        toks = set(tokens(ob.name))
        ext = is_exterior(ob)
        ob["lmsp_exterior"] = 1.0 if ext else 0.0
        k = 1.0
        if toks & DUST_HIGH:
            k = 1.6
        if toks & DUST_LOW:
            k = 0.15 if toks & {"rod", "piston", "chrome", "bearing"} else 0.5
        ob["lmsp_dust"] = k
        n += 1
    return n


def apply_wear(objs):
    n = 0
    for ob in objs:
        toks = set(tokens(ob.name))
        k = 1.0
        if toks & WEAR_HIGH:
            k = 1.7
        elif toks & {"cover", "shroud", "mli", "blanket", "beta"}:
            k = 0.8
        ob["lmsp_wear"] = k
        n += 1
    return n


def highlight_category(context, category):
    """Viewport colour overlay: matching objects bright, rest grey."""
    shading = None
    for area in context.screen.areas if context.screen else []:
        if area.type == 'VIEW_3D':
            shading = area.spaces.active.shading
            shading.type = 'SOLID'
            shading.color_type = 'OBJECT'
    cols = {"Titanium": (0.2, 0.6, 1.0, 1), "Carbon": (1.0, 0.45, 0.05, 1), "Glass": (0.1, 1.0, 0.9, 1),
            "Unassigned": (1.0, 0.05, 0.05, 1), "Duplicate": (1.0, 0.0, 1.0, 1)}
    names = set(CATEGORY.get(category, []))
    dup_names = set()
    if category == "Duplicate":
        base = {}
        for m in bpy.data.materials:
            b = re.sub(r"\.\d+$", "", m.name)
            base.setdefault(b, []).append(m.name)
        for b, lst in base.items():
            if len(lst) > 1:
                dup_names.update(n for n in lst if n != b)
    hit = 0
    for ob in context.scene.objects:
        if ob.type != 'MESH':
            continue
        mats = [s.material.name for s in ob.material_slots if s.material]
        if category == "Unassigned":
            on = len(mats) == 0
        elif category == "Duplicate":
            on = any(m in dup_names for m in mats)
        else:
            on = any(m in names for m in mats)
        ob.color = cols.get(category, (1, 1, 0, 1)) if on else (0.18, 0.18, 0.18, 1)
        hit += on
    return hit


def restore_shading(context):
    for area in context.screen.areas if context.screen else []:
        if area.type == 'VIEW_3D':
            area.spaces.active.shading.color_type = 'MATERIAL'
    for ob in context.scene.objects:
        ob.color = (1, 1, 1, 1)
