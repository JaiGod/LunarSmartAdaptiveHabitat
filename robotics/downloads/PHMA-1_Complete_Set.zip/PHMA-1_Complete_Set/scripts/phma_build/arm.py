"""PHMA-1 Primary Habitat Maintenance Arm - rig + geometry (rest pose = arm straight up).
Rig space: rail head top at z=0, track runs along +Y, arm 'forward' is -Y.

Spec (PHMA-1): reach 8.5 m (telescoping boom +1.0 m), retracted/stowed length 3.2 m, base dia 1.8 m,
lift 2,500 kg lunar, precision 0.1-100 kg, mass 1,450 kg. Axes: J1 turret yaw (continuous, slip ring),
J2 shoulder pitch +-180, J3 boom roll +-180, E1 telescope 0-1.0 m, J4 elbow pitch +-160,
J5 wrist pitch +-180, J6 wrist yaw +-180, J7 wrist roll +-270.
"""
import bpy, math
from mathutils import Vector, Matrix
from .common import Kit, coll, make_rig, parent_kit, TAU

SH_Z, BOOM_TOP, ELB_Z, FA_END, WY_Z, WR0, WR1, TM1 = 1.65, 4.6, 5.15, 7.85, 8.1, 8.35, 8.65, 8.8
A_PT = {s: Vector((s * 0.62, 0.55, 1.15)) for s in (-1, 1)}
B_PT = {s: Vector((s * 0.62, 0.32, 3.0)) for s in (-1, 1)}
SIDE = {-1: "L", 1: "R"}
# planar kinematics used by the animation solver (lengths in rig space, telescope retracted)
L_UPPER = ELB_Z - SH_Z          # shoulder axis -> elbow axis = 3.5 m (+ telescope 0..1.0)
L_FORE = FA_END - ELB_Z         # elbow -> wrist pitch = 2.7 m
L_WRIST = TM1 - FA_END          # wrist pitch -> tool face = 0.95 m

SPEC = ("PHMA-1 | reach 8.5 m (+1.0 m telescope) | stowed 3.2 m | base 1.8 m | lift 2500 kg lunar | "
        "precision 0.1-100 kg | mass 1450 kg | 7 rotary axes + telescope | Ti-6Al-4V 60% / CFRP booms")


def rig_bones():
    b = [("Root", (0, 0, 0), (0, 0.5, 0), None, False),
         ("Carriage", (0, 0, 0.02), (0, 0.6, 0.02), "Root", False),
         ("J1_Turret_Yaw", (0, 0, 0.45), (0, 0, SH_Z), "Carriage", False),
         ("J2_Shoulder_Pitch", (0, 0, SH_Z), (0, 0, 2.0), "J1_Turret_Yaw", True),
         ("J3_Boom_Roll", (0, 0, 2.0), (0, 0, BOOM_TOP), "J2_Shoulder_Pitch", True),
         ("E1_Telescope", (0, 0, BOOM_TOP), (0, 0, ELB_Z), "J3_Boom_Roll", False),
         ("J4_Elbow_Pitch", (0, 0, ELB_Z), (0, 0, FA_END), "E1_Telescope", True),
         ("J5_Wrist_Pitch", (0, 0, FA_END), (0, 0, WY_Z), "J4_Elbow_Pitch", True),
         ("J6_Wrist_Yaw", (0, 0, WY_Z), (0, 0, WR0), "J5_Wrist_Pitch", True),
         ("J7_Wrist_Roll", (0, 0, WR0), (0, 0, WR1), "J6_Wrist_Yaw", True),
         ("Tool_Mount", (0, 0, WR1), (0, 0, TM1), "J7_Wrist_Roll", True),
         ("IK_Target", (0, 0, TM1 + 0.6), (0, -0.4, TM1 + 0.6), "Root", False)]
    for s in (-1, 1):
        d = (B_PT[s] - A_PT[s]).normalized()
        b.append(("HYD_%s_Cyl" % SIDE[s], tuple(A_PT[s]), tuple(A_PT[s] + d * 1.15), "J1_Turret_Yaw", False))
        b.append(("HYD_%s_Rod" % SIDE[s], tuple(B_PT[s]), tuple(B_PT[s] - d * 1.15), "J3_Boom_Roll", False))
        # fixed anchor bones (no constraints) so the two pistons never track each other directly
        b.append(("HYD_%s_CylAnchor" % SIDE[s], tuple(A_PT[s]), tuple(A_PT[s] - d * 0.1), "J1_Turret_Yaw", False))
        b.append(("HYD_%s_RodAnchor" % SIDE[s], tuple(B_PT[s]), tuple(B_PT[s] + d * 0.1), "J3_Boom_Roll", False))
    return b


JOINT_AXIS = {"J1_Turret_Yaw": ('Y', None), "J2_Shoulder_Pitch": ('X', 180), "J3_Boom_Roll": ('Y', 180),
              "J4_Elbow_Pitch": ('X', 160), "J5_Wrist_Pitch": ('X', 180), "J6_Wrist_Yaw": ('Z', 180),
              "J7_Wrist_Roll": ('Y', 270)}


def setup_rig(rig):
    arm = rig.data
    cols = {}
    for nm in ("Joints", "Hydraulics", "Controls"):
        try:
            cols[nm] = arm.collections.new(nm)
        except Exception:
            cols[nm] = None
    for pb in rig.pose.bones:
        nm = pb.name
        pb.lock_location = (True, True, True)
        pb.lock_rotation = (True, True, True)
        pb.lock_scale = (True, True, True)
        pb.lock_rotation_w = True
        grp = "Joints"
        if nm in JOINT_AXIS:
            ax, lim = JOINT_AXIS[nm]
            i = "XYZ".index(ax)
            lr = [True, True, True]
            lr[i] = False
            pb.lock_rotation = lr
            pb.lock_ik_x, pb.lock_ik_y, pb.lock_ik_z = lr
            if lim:
                c = pb.constraints.new('LIMIT_ROTATION')
                c.owner_space = 'LOCAL'
                setattr(c, "use_limit_" + ax.lower(), True)
                setattr(c, "min_" + ax.lower(), math.radians(-lim))
                setattr(c, "max_" + ax.lower(), math.radians(lim))
        elif nm in ("Carriage", "E1_Telescope"):
            pb.lock_location = (True, False, True)
            pb.lock_ik_x = pb.lock_ik_y = pb.lock_ik_z = True
            if nm == "E1_Telescope":
                c = pb.constraints.new('LIMIT_LOCATION')
                c.owner_space = 'LOCAL'
                c.use_min_y = c.use_max_y = True
                c.min_y, c.max_y = 0.0, 1.0
        elif nm in ("Root", "IK_Target"):
            pb.lock_location = (False, False, False)
            pb.lock_rotation = (False, False, False)
            grp = "Controls"
        elif nm.endswith("Anchor"):
            grp = "Hydraulics"
        elif nm.startswith("HYD_"):
            pb.lock_rotation = (False, False, False)
            other = nm[:-4] + ("_RodAnchor" if nm.endswith("_Cyl") else "_CylAnchor")
            c = pb.constraints.new('DAMPED_TRACK')
            c.target = rig
            c.subtarget = other
            c.head_tail = 0.0
            grp = "Hydraulics"
        if cols.get(grp):
            try:
                cols[grp].assign(arm.bones[nm])
            except Exception:
                pass
    ik = rig.pose.bones["Tool_Mount"].constraints.new('IK')
    ik.target = rig
    ik.subtarget = "IK_Target"
    ik.chain_count = 9
    ik.use_tail = True
    ik.influence = 0.0
    ik.name = "IK (set influence 1 for IK posing)"
    rig["lmsp_spec"] = SPEC
    rig["mass_kg"] = 1450
    rig["reach_m"] = 8.5
    rig["lift_capacity_kg_lunar"] = 2500


def _yoke_pts(half_w, z0, cz, r, a_pad=0.35, n=14):
    pts = [(-half_w, z0), (half_w, z0)]
    for i in range(n + 1):
        a = -a_pad + (math.pi + 2 * a_pad) * i / n
        pts.append((r * math.cos(a), cz + r * math.sin(a)))
    return pts


def _motor(k, name, x0, x1, r, z, axis='X', y=0.0, fins=5):
    """Harmonic-drive servo motor can with cooling fins, along X (or Y) from x0 to x1."""
    sgn = 1 if x1 > x0 else -1
    L = abs(x1 - x0)
    prof = [(r * 0.8, 0.0), (r, 0.01), (r, L * 0.75), (r * 0.85, L * 0.8), (r * 0.85, L), (0.0, L)]
    if axis == 'X':
        k.lathe(name + "_Motor", prof, 32, loc=(x0, y, z), align=(sgn, 0, 0))
        for i in range(fins):
            xx = x0 + sgn * L * (0.12 + 0.12 * i)
            k.ring(name + "_Fin%d_Ring" % i, r * 1.12, r * 0.98, 0.008, (xx, y, z), axis='X', seg=32)
    else:
        k.lathe(name + "_Motor", prof, 32, loc=(0.0, x0, z), align=(0, sgn, 0))
        for i in range(fins):
            yy = x0 + sgn * L * (0.12 + 0.12 * i)
            k.ring(name + "_Fin%d_Ring" % i, r * 1.12, r * 0.98, 0.008, (0.0, yy, z), axis='Y', seg=32)


def build_phma(variant='EXT', parent_coll=None, rig_name=None):
    ext = variant == 'EXT'
    P = "PHMA1_EXT" if ext else "PHMA1_INT"
    col = coll("PHMA1_Exterior" if ext else "PHMA1_Interior", parent_coll)
    rig = make_rig(rig_name or ("RIG_PHMA1_EXT" if ext else "RIG_PHMA1_INT"), col, rig_bones())
    setup_rig(rig)
    k = Kit(col, P)
    # ================================================================ CARRIAGE (rides the titanium rail)
    k.bone = "Carriage"
    k.box("Carriage_Chassis_Frame", (1.5, 2.8, 0.16), (0, 0, 0.34), bevel=0.015)
    k.box("Carriage_Deck", (1.44, 2.74, 0.025), (0, 0, 0.432), bevel=0.004)
    for s in (-1, 1):
        k.box("Carriage_SideBeam_%s_Titanium" % SIDE[s], (0.08, 2.9, 0.22), (s * 0.72, 0, 0.29), bevel=0.01)
    for bx in (-0.375, 0.375):
        for by in (-1.0, 1.0):
            t = ("L" if bx < 0 else "R") + ("F" if by < 0 else "B")
            k.box("Bogie_%s_Frame" % t, (0.22, 0.62, 0.16), (bx, by, 0.2), bevel=0.01)
            for dy in (-0.18, 0.18):
                tt = t + ("a" if dy < 0 else "b")
                k.cyl("Bogie_%s_RailWheel_Titanium" % tt, 0.11, 0.07, (bx, by + dy, 0.11), axis='X', seg=32, bevel=0.004)
                k.cyl("Bogie_%s_Hub_Bearing" % tt, 0.045, 0.09, (bx, by + dy, 0.11), axis='X', seg=24)
                for gs in (-1, 1):
                    k.cyl("Bogie_%s_Guide%s_Ceramic" % (tt, "i" if gs < 0 else "o"), 0.032, 0.045,
                          (bx + gs * 0.07, by + dy, -0.03), seg=20)
                    k.box("Bogie_%s_GuideArm%s_Bracket" % (tt, "i" if gs < 0 else "o"), (0.026, 0.06, 0.17),
                          (bx + gs * 0.07, by + dy, 0.06), bevel=0.003)
                k.cyl("Bogie_%s_CaptureWheel_Ceramic" % tt, 0.022, 0.03, (bx, by + dy + 0.06, -0.085), axis='X', seg=16)
            so = 1 if bx > 0 else -1
            _motor(k, "Bogie_%s_Drive" % t, bx + so * 0.11, bx + so * 0.3, 0.065, 0.2, 'X', by)
            k.box("Bogie_%s_Gearbox" % t, (0.1, 0.16, 0.14), (bx + so * 0.13, by, 0.2), bevel=0.008)
            for fs in (-1, 1):
                k.box("Bogie_%s%s_DustSkirt" % (t, "i" if fs < 0 else "o"), (0.012, 0.66, 0.12),
                      (bx + fs * 0.125, by, 0.07), bevel=0.0)
    k.box("Collector_Arm_Bracket", (0.04, 0.12, 0.44), (-0.66, 0, 0.13), bevel=0.004)
    k.box("Collector_Shoe_Copper", (0.06, 0.3, 0.025), (-0.62, 0, -0.035), bevel=0.003)
    k.box("Encoder_ReaderHead_Housing", (0.05, 0.12, 0.07), (0.3, 0.0, -0.05), bevel=0.004)
    for s, nm in ((1, "Avionics"), (-1, "PowerUnit")):
        k.box("%s_Electronics" % nm, (0.5, 0.38, 0.3), (s * 0.4, -1.15, 0.6), bevel=0.012)
        k.box("%s_AccessPanel_Cover" % nm, (0.44, 0.012, 0.24), (s * 0.4, -1.345, 0.6), bevel=0.003)
        k.bolts("%s_Panel_Bolts" % nm, [(s * 0.4 + dx, -1.351, 0.6 + dz) for dx in (-0.2, 0.2) for dz in (-0.1, 0.1)],
                (0, -1, 0), 0.01, 0.008)
        k.box("%s_StatusLED" % nm, (0.06, 0.01, 0.015), (s * 0.4 + 0.15, -1.352, 0.7), bevel=0.0)
        if ext:
            k.box("%s_Radiator_OSR" % nm, (0.48, 0.36, 0.018), (s * 0.4, -1.15, 0.78), bevel=0.002)
            for sx in (-0.2, 0.2):
                for sy in (-0.15, 0.15):
                    k.cyl("%s_Standoff%d%d_Strut" % (nm, sx > 0, sy > 0), 0.008, 0.03, (s * 0.4 + sx, -1.15 + sy, 0.762), seg=8)
        else:
            k.box("%s_Cowl_Paint" % nm, (0.5, 0.38, 0.02), (s * 0.4, -1.15, 0.76), bevel=0.006)
    k.box("ToolRack_Frame", (1.3, 0.44, 0.05), (0, 1.18, 0.47), bevel=0.006)
    for i, x in enumerate((-0.42, 0.0, 0.42)):
        k.ring("ToolRack_Holster%d_Ring" % i, 0.175, 0.15, 0.1, (x, 1.18, 0.62), seg=40)
        for a in range(3):
            ang = a / 3 * TAU + 0.5
            k.box("ToolRack_Holster%d_Post%d_Strut" % (i, a), (0.02, 0.02, 0.16),
                  (x + math.cos(ang) * 0.162, 1.18 + math.sin(ang) * 0.162, 0.53), bevel=0.0)
    k.box("Override_Panel", (0.02, 0.36, 0.22), (0.765, -0.45, 0.3), bevel=0.004)
    k.cyl("Override_EStop_PaintRed", 0.042, 0.035, (0.79, -0.53, 0.33), axis='X', seg=32, bevel=0.004)
    k.ring("Override_EStop_Collar_Yellow", 0.06, 0.04, 0.02, (0.78, -0.53, 0.33), axis='X', seg=32)
    k.cable("Override_TPull_Handhold", [(0.775, -0.34, 0.24), (0.84, -0.34, 0.26), (0.84, -0.34, 0.36), (0.775, -0.34, 0.38)], 0.012)
    k.cyl("Override_KeySwitch_Body", 0.02, 0.03, (0.785, -0.42, 0.24), axis='X', seg=16)
    for s in (-1, 1):
        k.cable("Carriage_%s_Handrail" % SIDE[s], [(s * 0.76, -1.25, 0.4), (s * 0.84, -1.18, 0.52), (s * 0.84, 1.18, 0.52),
                                                   (s * 0.76, 1.25, 0.4)], 0.017)
        for j, y in enumerate((-0.6, 0.0, 0.6)):
            k.cyl("Handrail_%s%d_Standoff_Strut" % (SIDE[s], j), 0.012, 0.12, (s * 0.8, y, 0.46), axis='X', seg=10)
        if not ext:
            for y in (-1.38, 1.38):
                k.cyl("Corner_%s%s_Bumper" % (SIDE[s], "F" if y < 0 else "B"), 0.07, 0.3, (s * 0.72, y, 0.34), seg=24, bevel=0.01)
    for s in (-1, 1):
        loc = Vector((s * 0.6, -1.4, 0.52))
        k.lathe("Flood_%s_Housing" % SIDE[s], [(0.0, -0.09), (0.05, -0.09), (0.07, -0.05), (0.075, 0.0), (0.075, 0.02)],
                32, loc=loc, align=(0, -1, 0))
        k.cyl("Flood_%s_Emitter" % SIDE[s], 0.064, 0.004, loc + Vector((0, -0.012, 0)), axis='Y', seg=32)
        k.cyl("Flood_%s_Glass" % SIDE[s], 0.07, 0.006, loc + Vector((0, -0.022, 0)), axis='Y', seg=32)
        k.box("Flood_%s_Mount_Bracket" % SIDE[s], (0.04, 0.08, 0.1), loc + Vector((0, 0.1, -0.06)), bevel=0.003)
        if ext:
            k.light("Flood_%s" % SIDE[s], 'SPOT', 900, (1.0, 0.97, 0.92), loc + Vector((0, -0.03, 0)), (0, -1, -0.25),
                    math.radians(70), 0.06)
    k.cyl("FrontMast_Strut", 0.025, 0.5, (0, -1.28, 0.44), base=True, seg=16)
    k.box("FrontMast_PanTilt_Gearbox", (0.08, 0.08, 0.07), (0, -1.28, 0.97), bevel=0.006)
    k.box("FrontCam_Housing", (0.12, 0.16, 0.09), (0, -1.31, 1.05), bevel=0.01)
    k.cyl("FrontCam_Lens", 0.03, 0.02, (0, -1.395, 1.05), axis='Y', seg=32)
    k.cyl("FrontCam_Glass", 0.034, 0.006, (0, -1.392, 1.05), axis='Y', seg=32)
    k.box("Carriage_StatusLED", (1.3, 0.012, 0.018), (0, -1.405, 0.39), bevel=0.0)
    if ext:
        k.bellows("Slew_DustBellows", 0.905, 0.94, 0.43, 0.535, 4, seg=64)
    # ================================================================ TURRET (J1)
    k.bone = "J1_Turret_Yaw"
    k.ring("SlewBearing_Outer_Ring", 0.9, 0.66, 0.1, (0, 0, 0.5), seg=64, bevel=0.004)
    k.bolt_circle("SlewBearing_Bolts", 48, 0.83, 0.55, 'Z', r=0.014, h=0.012)
    k.lathe("Turret_Drum_Housing", [(0.66, 0.55), (0.8, 0.57), (0.8, 1.1), (0.74, 1.2), (0.55, 1.24), (0.0, 1.24)], 64)
    if ext:
        k.lathe("Turret_Drum_MLI", [(0.808, 0.6), (0.808, 1.09)], 56, a0=0.55, a1=TAU - 0.55, cap=False, solid=0.012)
    else:
        k.lathe("Turret_Drum_Cowl_Paint", [(0.806, 0.62), (0.806, 1.07)], 56, a0=0.55, a1=TAU - 0.55, cap=False, solid=0.01)
    k.box("Turret_AccessPanel_Cover", (0.012, 0.42, 0.36), (0.806, 0, 0.84), bevel=0.003)
    k.bolts("Turret_AccessPanel_Bolts", [(0.813, dy, 0.84 + dz) for dy in (-0.19, 0.0, 0.19) for dz in (-0.16, 0.16)],
            (1, 0, 0), 0.01, 0.008)
    k.lathe("Turret_TopPlate", [(0.6, 1.24), (0.63, 1.26), (0.63, 1.29), (0.0, 1.29)], 64)
    for s in (-1, 1):
        k.plate("Yoke_%s_Titanium" % SIDE[s], _yoke_pts(0.42, 1.24, SH_Z, 0.37), 0.07, (s * 0.49, 0, 0), 'YZ', 0.01)
        k.cyl("Yoke_%s_Boss_Fitting" % SIDE[s], 0.22, 0.05, (s * 0.55, 0, SH_Z), axis='X', seg=48, bevel=0.006)
        k.bolt_circle("Yoke_%s_Boss_Bolts" % SIDE[s], 12, 0.18, s * 0.575, 'X', r=0.011, h=0.01, center=(0, 0, SH_Z),
                      flip=(s < 0))
        _motor(k, "Shoulder_%s" % SIDE[s], s * 0.575, s * 0.76, 0.15, SH_Z, 'X')
        k.box("HydAnchor_%s_Lug" % SIDE[s], (0.1, 0.16, 0.2), tuple(A_PT[s]), bevel=0.008)
        k.cyl("HydAnchor_%s_Pin" % SIDE[s], 0.03, 0.16, tuple(A_PT[s]), axis='X', seg=20)
    if ext:
        k.box("Turret_Radiator_OSR", (0.86, 0.03, 0.5), (0, 0.84, 0.88), bevel=0.003)
        for x in (-0.38, 0.38):
            for z in (0.7, 1.06):
                k.box("Turret_Radiator_Standoff%d%d_Bracket" % (x > 0, z > 1), (0.03, 0.06, 0.03), (x, 0.8, z), bevel=0.0)
    k.cyl("TurretMast_Strut", 0.025, 0.55, (0.5, -0.5, 1.2), base=True, seg=16)
    k.box("TurretMast_PanTilt_Gearbox", (0.08, 0.08, 0.07), (0.5, -0.5, 1.78), bevel=0.006)
    k.box("TurretCam_Housing", (0.13, 0.17, 0.1), (0.5, -0.53, 1.86), bevel=0.01)
    k.cyl("TurretCam_Lens", 0.032, 0.02, (0.5, -0.62, 1.86), axis='Y', seg=32)
    k.cyl("TurretCam_Glass", 0.036, 0.006, (0.5, -0.617, 1.86), axis='Y', seg=32)
    k.lathe("TurretMast_Beacon_LED", [(0.03, 1.91), (0.03, 1.95), (0.02, 1.97), (0.0, 1.975)], 24, loc=(0.5, -0.5, 0))
    # ================================================================ SHOULDER (J2)
    k.bone = "J2_Shoulder_Pitch"
    k.lathe("Shoulder_Drum_Titanium", [(0.3, -0.42), (0.34, -0.4), (0.36, -0.36), (0.36, 0.36), (0.34, 0.4), (0.3, 0.42)],
            64, loc=(0, 0, SH_Z), axis='X')
    for s in (-1, 1):
        k.torus("Shoulder_%s_StatusLED" % SIDE[s], 0.31, 0.008, (s * 0.425, 0, SH_Z), axis='X', seg=48, rseg=6)
        k.ring("Shoulder_%s_Seal" % SIDE[s], 0.24, 0.2, 0.03, (s * 0.44, 0, SH_Z), axis='X', seg=48)
    if ext:
        k.lathe("Shoulder_MLI", [(0.372, -0.34), (0.372, 0.34)], 48, loc=(0, 0, SH_Z), axis='X', a0=0.2, a1=3.6,
                cap=False, solid=0.01)
    else:
        k.lathe("Shoulder_Cowl_Paint", [(0.37, -0.3), (0.37, 0.3)], 48, loc=(0, 0, SH_Z), axis='X', a0=0.2, a1=3.6,
                cap=False, solid=0.01)
    k.lathe("Shoulder_BoomRoot_Fitting", [(0.2, 1.88), (0.26, 1.94), (0.26, 2.0), (0.0, 2.0)], 48)
    # ================================================================ BOOM (J3)
    k.bone = "J3_Boom_Roll"
    k.lathe("Roll_Drive_Collar", [(0.25, 2.0), (0.27, 2.03), (0.27, 2.27), (0.24, 2.32), (0.215, 2.34)], 64, cap=False)
    k.bellows("Roll_DustBellows", 0.255, 0.277, 1.985, 2.04, 3, seg=64)
    k.cyl("Boom_Tube_CFRP", 0.21, 2.3, (0, 0, 2.33), base=True, seg=64)
    for i, z in enumerate((2.95, 3.6, 4.25)):
        k.ring("Boom_Band%d_Ring" % i, 0.227, 0.205, 0.06, (0, 0, z), seg=64)
        angs = [j / 8 * TAU + 0.2 for j in range(8)]
        k.bolts("Boom_Band%d_Bolts" % i, [(math.cos(a) * 0.227, math.sin(a) * 0.227, z) for a in angs],
                [(math.cos(a), math.sin(a), 0) for a in angs], 0.009, 0.007)
    for s in (-1, 1):
        k.box("HydLug_%s_Bracket" % SIDE[s], (0.46, 0.08, 0.12), (s * 0.41, 0.21, 3.0), rotz=s * 0.482, bevel=0.008)
        k.box("HydLug_%s_Lug" % SIDE[s], (0.09, 0.1, 0.11), tuple(B_PT[s]), bevel=0.008)
        k.cyl("HydLug_%s_Pin" % SIDE[s], 0.028, 0.14, tuple(B_PT[s]), axis='X', seg=20)
    k.lathe("Boom_EndCollar", [(0.205, 4.5), (0.25, 4.55), (0.25, 4.86), (0.205, 4.9), (0.172, 4.9)], 64, cap=False)
    k.bolt_circle("Boom_EndCollar_Bolts", 12, 0.228, 4.9, 'Z', r=0.01, h=0.008)
    k.ring("Telescope_Wiper_Seal", 0.18, 0.16, 0.03, (0, 0, 4.905), seg=48)
    k.cable("Boom_DataHarness_Kevlar", [(0.23, 0.0, 2.25), (0.268, 0.03, 2.5), (0.268, 0.03, 4.35), (0.24, 0.0, 4.6)], 0.022)
    k.cable("Boom_PowerConduit", [(0.0, 0.23, 2.25), (0.03, 0.272, 2.5), (0.03, 0.272, 4.35), (0.0, 0.24, 4.6)], 0.03)
    k.clamps("Boom_HarnessClamp_Bracket", [(0.268, 0.03, z) for z in (2.7, 3.15, 3.85, 4.1)], 0.034)
    k.clamps("Boom_ConduitClamp_Bracket", [(0.03, 0.272, z) for z in (2.7, 3.15, 3.85, 4.1)], 0.042)
    if ext:
        k.box("Boom_NodeBox_Blanket", (0.17, 0.22, 0.32), (-0.3, 0.0, 3.3), bevel=0.02)
    else:
        k.box("Boom_NodeBox_Electronics", (0.17, 0.22, 0.32), (-0.3, 0.0, 3.3), bevel=0.012)
    k.box("Boom_NodeBox_Mount_Bracket", (0.12, 0.08, 0.08), (-0.22, 0.0, 3.3), bevel=0.004)
    # ================================================================ TELESCOPE (E1) + elbow stator
    k.bone = "E1_Telescope"
    k.cyl("Telescope_InnerTube_Titanium", 0.16, 1.35, (0, 0, 3.62), base=True, seg=48)
    k.lathe("Telescope_TopFitting", [(0.165, 4.93), (0.2, 4.96), (0.2, 4.99), (0.0, 4.99)], 48)
    for s in (-1, 1):
        k.plate("ElbowYoke_%s_Titanium" % SIDE[s], _yoke_pts(0.2, 4.95, ELB_Z, 0.27), 0.06, (s * 0.31, 0, 0), 'YZ', 0.008)
    _motor(k, "Elbow_R", 0.34, 0.52, 0.17, ELB_Z, 'X')
    k.box("ElbowCam_Bracket", (0.1, 0.1, 0.12), (-0.4, -0.05, ELB_Z), bevel=0.006)
    k.box("ElbowCam_PanTilt_Gearbox", (0.08, 0.09, 0.08), (-0.47, -0.1, ELB_Z), bevel=0.006)
    k.box("ElbowCam_Housing", (0.12, 0.17, 0.1), (-0.47, -0.2, ELB_Z), bevel=0.01)
    k.cyl("ElbowCam_Lens", 0.032, 0.02, (-0.47, -0.29, ELB_Z), axis='Y', seg=32)
    k.cyl("ElbowCam_Glass", 0.036, 0.006, (-0.47, -0.287, ELB_Z), axis='Y', seg=32)
    k.torus("ElbowCam_Ring_LED", 0.045, 0.005, (-0.47, -0.29, ELB_Z), axis='Y', seg=32, rseg=6)
    if ext:
        k.light("ElbowCam_Flood", 'SPOT', 250, (1.0, 0.97, 0.92), (-0.47, -0.3, ELB_Z), (0, -1, -0.1), math.radians(50), 0.03)
    # ================================================================ FOREARM (J4)
    k.bone = "J4_Elbow_Pitch"
    k.lathe("Elbow_Drum_Titanium", [(0.22, -0.27), (0.25, -0.25), (0.26, -0.22), (0.26, 0.22), (0.25, 0.25), (0.22, 0.27)],
            64, loc=(0, 0, ELB_Z), axis='X')
    for s in (-1, 1):
        k.torus("Elbow_%s_StatusLED" % SIDE[s], 0.225, 0.006, (s * 0.272, 0, ELB_Z), axis='X', seg=48, rseg=6)
    if ext:
        k.lathe("Elbow_MLI", [(0.268, -0.21), (0.268, 0.21)], 48, loc=(0, 0, ELB_Z), axis='X', a0=0.2, a1=3.4,
                cap=False, solid=0.008)
    else:
        k.lathe("Elbow_Cowl_Paint", [(0.268, -0.2), (0.268, 0.2)], 48, loc=(0, 0, ELB_Z), axis='X', a0=0.2, a1=3.4,
                cap=False, solid=0.008)
    k.lathe("Forearm_RootFitting", [(0.2, 5.36), (0.215, 5.4), (0.215, 5.55), (0.18, 5.6)], 48, cap=False)
    k.cyl("Forearm_Tube_CFRP", 0.17, 1.9, (0, 0, 5.58), base=True, seg=64)
    for i, z in enumerate((6.1, 6.8)):
        k.ring("Forearm_Band%d_Ring" % i, 0.186, 0.165, 0.05, (0, 0, z), seg=48)
    k.cable("Forearm_DataHarness_Kevlar", [(0.19, 0.0, 5.62), (0.215, 0.03, 5.8), (0.215, 0.03, 7.2), (0.19, 0.0, 7.4)], 0.018)
    k.cable("Forearm_PowerConduit", [(0.0, 0.19, 5.62), (0.03, 0.218, 5.8), (0.03, 0.218, 7.2), (0.0, 0.19, 7.4)], 0.024)
    k.clamps("Forearm_HarnessClamp_Bracket", [(0.215, 0.03, z) for z in (6.3, 6.6, 7.0)], 0.028)
    k.lathe("Forearm_EndFitting", [(0.17, 7.42), (0.2, 7.47), (0.2, 7.6), (0.0, 7.6)], 48)
    for s in (-1, 1):
        k.plate("WristYoke_%s_Titanium" % SIDE[s], _yoke_pts(0.15, 7.56, FA_END, 0.18), 0.05, (s * 0.2, 0, 0), 'YZ', 0.006)
    _motor(k, "WristPitch_R", 0.225, 0.34, 0.11, FA_END, 'X', fins=3)
    # ================================================================ WRIST (J5 pitch / J6 yaw / J7 roll)
    k.bone = "J5_Wrist_Pitch"
    k.lathe("WristPitch_Drum_Titanium", [(0.14, -0.17), (0.16, -0.15), (0.16, 0.15), (0.14, 0.17)], 48,
            loc=(0, 0, FA_END), axis='X')
    k.torus("WristPitch_StatusLED", 0.145, 0.005, (0.172, 0, FA_END), axis='X', seg=40, rseg=6)
    for s in (-1, 1):
        pts = [(-0.14, 7.96), (0.14, 7.96)] + [(0.16 * math.cos(a), WY_Z + 0.16 * math.sin(a))
                                               for a in [-0.3 + (math.pi + 0.6) * i / 12 for i in range(13)]]
        k.plate("WristYawYoke_%s_Titanium" % ("F" if s < 0 else "B"), pts, 0.04, (0, s * 0.18, 0), 'XZ', 0.005)
    _motor(k, "WristYaw_B", 0.2, 0.3, 0.09, WY_Z, 'Y', fins=3)
    k.bone = "J6_Wrist_Yaw"
    k.lathe("WristYaw_Drum_Titanium", [(0.13, -0.16), (0.15, -0.14), (0.15, 0.14), (0.13, 0.16)], 48,
            loc=(0, 0, WY_Z), axis='Y')
    k.lathe("WristRoll_Base_Collar", [(0.15, 8.22), (0.17, 8.26), (0.17, 8.34)], 48, cap=False)
    k.bellows("WristRoll_DustBellows", 0.165, 0.18, 8.33, 8.38, 2, seg=48)
    k.bone = "J7_Wrist_Roll"
    k.lathe("WristRoll_Housing", [(0.168, 8.37), (0.178, 8.4), (0.178, 8.6), (0.168, 8.65)], 64, cap=False)
    k.torus("WristRoll_StatusLED", 0.179, 0.005, (0, 0, 8.62), seg=48, rseg=6)
    k.box("SensorHead_Housing", (0.24, 0.12, 0.15), (0, -0.235, 8.5), bevel=0.012)
    for s in (-1, 1):
        k.cyl("SensorHead_Stereo%s_Lens" % SIDE[s], 0.028, 0.02, (s * 0.075, -0.3, 8.52), axis='Y', seg=32)
        k.box("SensorHead_Flood%s_Emitter" % SIDE[s], (0.03, 0.01, 0.05), (s * 0.105, -0.297, 8.465), bevel=0.0)
    k.box("SensorHead_Cover_Glass", (0.22, 0.006, 0.11), (0, -0.298, 8.5), bevel=0.002)
    k.lathe("SensorHead_Lidar_Sensor", [(0.04, 8.575), (0.046, 8.585), (0.046, 8.63), (0.0, 8.64)], 32, loc=(0, -0.235, 0))
    if ext:
        k.light("SensorHead_Spot", 'SPOT', 300, (1.0, 0.98, 0.95), (0, -0.31, 8.47), (0, -1, -0.05), math.radians(45), 0.02)
    k.bone = "Tool_Mount"
    k.lathe("ToolChanger_Coupling", [(0.168, 8.65), (0.18, 8.67), (0.18, 8.76), (0.15, 8.8), (0.0, 8.8)], 64)
    k.ring("ToolChanger_Latch_Ring", 0.188, 0.17, 0.04, (0, 0, 8.71), seg=64)
    for i in range(3):
        a = i / 3 * TAU
        k.cyl("ToolChanger_AlignPin%d_Pins" % i, 0.012, 0.04, (math.cos(a) * 0.11, math.sin(a) * 0.11, 8.8), base=True, seg=12)
    k.box("ToolChanger_Connector_Box", (0.06, 0.04, 0.02), (0.0, 0.08, 8.81), bevel=0.003)
    # ================================================================ HYDRAULIC ASSIST (electro-hydraulic, sealed)
    for s in (-1, 1):
        A, B = A_PT[s], B_PT[s]
        d = (B - A).normalized()
        k.bone = "HYD_%s_Cyl" % SIDE[s]
        k.lathe("Hyd%s_Barrel" % SIDE[s], [(0.055, 0.0), (0.075, 0.03), (0.075, 1.08), (0.065, 1.12), (0.05, 1.15)], 32,
                loc=tuple(A), align=tuple(d))
        k.cyl("Hyd%s_BaseEye_Titanium" % SIDE[s], 0.05, 0.09, tuple(A), axis='X', seg=24)
        k.ring("Hyd%s_Gland_Seal" % SIDE[s], 0.06, 0.036, 0.03, tuple(A + d * 1.14), align=tuple(d), seg=32)
        k.cyl("Hyd%s_Port_Fitting" % SIDE[s], 0.018, 0.05, tuple(A + d * 0.12 + Vector((s * 0.08, 0, 0))), axis='X', seg=12)
        k.bone = "HYD_%s_Rod" % SIDE[s]
        k.cyl("Hyd%s_Rod" % SIDE[s], 0.035, 1.15, tuple(B), align=tuple(-d), base=True, seg=32)
        k.cyl("Hyd%s_RodEye_Titanium" % SIDE[s], 0.045, 0.08, tuple(B), axis='X', seg=24)
    k.bone = "J1_Turret_Yaw"
    for s in (-1, 1):
        A = A_PT[s]
        d = (B_PT[s] - A).normalized()
        p0 = A + d * 0.12 + Vector((s * 0.1, 0, 0))
        k.cable("Hyd%s_Hose" % SIDE[s], [tuple(p0), tuple(p0 + Vector((s * 0.06, 0.05, -0.12))), (s * 0.79, 0.3, 0.95),
                                         (s * 0.78, 0.15, 0.8)], 0.013)
    return rig, k


def decorate_phma(k, ext=True):
    """Labels, IDs, QR tags, inspection stickers, docking targets (needs the add-on's decal module)."""
    from lunar_material_studio_pro import decals as D
    P = k.prefix
    ob = lambda n: bpy.data.objects.get("%s_%s" % (P, n))
    title = "PHMA-1" if ext else "PHMA-1I"
    made = []
    try:
        made.append(D.id_plate(ob("Yoke_R_Titanium"), (0.526, 0.0, 1.4), (1, 0, 0), (0, 0, 1), 0.26, 0.085,
                               title + " J2 SHOULDER", "+-180 DEG  SN 0047"))
        made.append(D.preset_decal(ob("Yoke_L_Titanium"), "pinch", (-0.526, 0.0, 1.4), (-1, 0, 0), (0, 0, 1), 0.26, 0.075))
        made.append(D.inspection_sticker(ob("Turret_AccessPanel_Cover"), (0.813, 0.1, 0.95), (1, 0, 0), (0, 0, 1),
                                         0.1, 0.075, "2033-07-02", maint=True))
        made.append(D.qr_tag(ob("Turret_AccessPanel_Cover"), (0.813, -0.1, 0.95), (1, 0, 0), (0, 0, 1), 0.07))
        made.append(D.inspection_sticker(ob("Avionics_AccessPanel_Cover"), (0.47, -1.352, 0.64), (0, -1, 0), (0, 0, 1),
                                         0.09, 0.07, "2031-03-14"))
        made.append(D.qr_tag(ob("Avionics_AccessPanel_Cover"), (0.3, -1.352, 0.62), (0, -1, 0), (0, 0, 1), 0.07))
        made.append(D.preset_decal(ob("PowerUnit_AccessPanel_Cover"), "hv", (-0.4, -1.352, 0.62), (0, -1, 0), (0, 0, 1),
                                   0.32, 0.085))
        made.append(D.preset_decal(ob("Override_Panel"), "override", (0.776, -0.4, 0.34), (1, 0, 0), (0, 0, 1), 0.17, 0.055))
        for s in (-1, 1):
            made.append(D.preset_decal(ob("Carriage_SideBeam_%s_Titanium" % SIDE[s]), "lift",
                                       (s * 0.761, 1.05, 0.3), (s, 0, 0), (0, 0, 1), 0.26, 0.08))
        made.append(D.preset_decal(ob("Carriage_Chassis_Frame"), "hazard", (0, -1.401, 0.31), (0, -1, 0), (0, 0, 1), 1.1, 0.06))
        made.append(D.preset_decal(ob("Carriage_Deck"), "target", (0.0, 0.75, 0.4446), (0, 0, 1), (0, 1, 0), 0.24, 0.24))
        made.append(D.id_plate(ob("Boom_Tube_CFRP"), (0, -0.2125, 3.95), (0, -1, 0), (-1, 0, 0), 0.62, 0.085,
                               title + " LSAH ROBOTICS", "HABITAT ENGINEERING ARM" if ext else "INTERIOR SERVICE ARM"))
        made.append(D.preset_decal(ob("Boom_Tube_CFRP"), "nostep", (0, -0.2125, 2.7), (0, -1, 0), (-1, 0, 0), 0.3, 0.075))
        made.append(D.qr_tag(ob("Forearm_Tube_CFRP"), (0, -0.1725, 5.95), (0, -1, 0), (0, 0, 1), 0.06))
        made.append(D.id_plate(ob("Forearm_Tube_CFRP"), (0, -0.1725, 6.45), (0, -1, 0), (-1, 0, 0), 0.5, 0.075,
                               "J4 ELBOW +-160 DEG", "MAX 2500 KG LUNAR"))
        if not ext:
            made.append(D.preset_decal(ob("Carriage_Chassis_Frame"), "eva", (0, 1.401, 0.31), (0, 1, 0), (0, 0, 1), 0.4, 0.07,
                                       extra=["COBOT ZONE", "SPEED LIMITED"]))
        else:
            made.append(D.preset_decal(ob("Carriage_SideBeam_R_Titanium"), "eva", (0.761, -0.95, 0.3), (1, 0, 0), (0, 0, 1),
                                       0.26, 0.07))
    except Exception as e:
        print("decal error", e)
    return [m for m in made if m]
