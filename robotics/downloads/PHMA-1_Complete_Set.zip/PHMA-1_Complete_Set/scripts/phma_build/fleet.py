"""Support fleet: Type 2 micro maintenance robots and Type 3 EVA exterior robots (rigged)."""
import bpy, bmesh, math
from mathutils import Vector, Matrix
from .common import Kit, coll, make_rig, parent_kit, align_matrix, TAU


def merged_boxes(k, name, items, bevel=None):
    """items: list of (size xyz, Matrix). One mesh, many boxes (grousers, spokes, ribs)."""
    bm = bmesh.new()
    for size, M in items:
        g = bmesh.ops.create_cube(bm, size=1.0)
        bmesh.ops.scale(bm, vec=size, verts=g["verts"])
        bmesh.ops.transform(bm, matrix=M, verts=g["verts"])
    return k._obj(name, bm, Matrix.Identity(4), bevel=bevel)


def _lock_all(rig, free):
    for pb in rig.pose.bones:
        f = free.get(pb.name, "")
        pb.lock_location = tuple(a not in f for a in "xyz")
        pb.lock_rotation = tuple(a not in f for a in "XYZ")
        pb.lock_scale = (True, True, True)


# =============================================================== TYPE 2A: in-pipe crawler
MMR_SPEC = ("MMR-2A in-pipe crawler | fits 200-300 mm ID pipe | 3 spring-loaded legs, 6 wheels | 1.8 kg | "
            "HD camera + ultrasonic wall-thickness + acoustic leak sensing | LUNA-AI vision, autonomous")


def build_mmr_pipe(name="RIG_MMR2A", parent_coll=None, pipe_r=0.125):
    col = coll("MMR_MicroRobots", parent_coll)
    legs = [math.radians(a) for a in (90, 210, 330)]
    wr = 0.028
    wc = pipe_r - wr
    bones = [("Root", (0, 0, 0), (0, 0.08, 0), None, False), ("Body", (0, -0.05, 0), (0, 0.05, 0), "Root", False),
             ("Cam_Tilt", (0, 0.1, 0), (0, 0.14, 0), "Body", False)]
    for i, phi in enumerate(legs):
        r = Vector((math.cos(phi), 0, math.sin(phi)))
        ax = Vector((-math.sin(phi), 0, math.cos(phi)))
        for fb, y in (("F", 0.07), ("B", -0.07)):
            h = r * wc + Vector((0, y, 0))
            bones.append(("Wheel_%d%s" % (i, fb), tuple(h), tuple(h + ax * 0.02), "Body", False))
    rig = make_rig(name, col, bones)
    _lock_all(rig, {"Root": "xyzXYZ", "Body": "Y", "Cam_Tilt": "X", **{b[0]: "Y" for b in bones if b[0].startswith("Wheel")}})
    rig["lmsp_spec"] = MMR_SPEC
    k = Kit(col, "MMR2A")
    k.bone = "Body"
    k.lathe("Body_Housing", [(0.0, -0.12), (0.03, -0.118), (0.045, -0.1), (0.045, 0.08), (0.04, 0.1), (0.0, 0.1)], 40,
            align=(0, 1, 0))
    for i, y in enumerate((-0.06, 0.0, 0.06)):
        k.ring("Body_Band%d_Ring" % i, 0.048, 0.044, 0.008, (0, y, 0), axis='Y', seg=40)
    k.box("Body_StatusLED", (0.004, 0.06, 0.006), (0.046, -0.02, 0.0), bevel=0.0)
    k.box("Battery_Electronics", (0.05, 0.03, 0.03), (0, -0.115, 0), bevel=0.004)
    k.cyl("UT_Probe_Sensor", 0.008, 0.03, (0, 0.03, -0.06), seg=12)
    k.cyl("Antenna_Rod", 0.003, 0.05, (0, -0.1, 0.05), base=True, seg=8)
    for i, phi in enumerate(legs):
        r = Vector((math.cos(phi), 0, math.sin(phi)))
        ax = Vector((-math.sin(phi), 0, math.cos(phi)))
        for fb, y in (("F", 0.07), ("B", -0.07)):
            p0 = r * 0.045 + Vector((0, y * 0.5, 0))
            p1 = r * wc + Vector((0, y, 0))
            k.cyl("Leg%d%s_Link_Titanium" % (i, fb), 0.006, (p1 - p0).length, tuple(p0), align=tuple(p1 - p0), base=True, seg=10)
        k.cyl("Leg%d_Spring_Chrome" % i, 0.009, 0.035, tuple(r * 0.06), align=tuple(r), base=True, seg=12)
    k.bone = "Cam_Tilt"
    k.lathe("Nose_Dome_Glass", [(0.04, 0.0), (0.04, 0.01), (0.032, 0.03), (0.018, 0.042), (0.0, 0.046)], 40,
            loc=(0, 0.1, 0), align=(0, 1, 0), cap=False)
    k.cyl("Nose_Camera_Lens", 0.014, 0.01, (0, 0.13, 0), axis='Y', seg=24)
    k.torus("Nose_Ring_LED", 0.03, 0.003, (0, 0.108, 0), axis='Y', seg=32, rseg=6)
    k.light("Nose_Flood", 'SPOT', 6, (0.95, 0.97, 1.0), (0, 0.15, 0), (0, 1, 0), math.radians(80), 0.01)
    for i, phi in enumerate(legs):
        r = Vector((math.cos(phi), 0, math.sin(phi)))
        ax = Vector((-math.sin(phi), 0, math.cos(phi)))
        for fb, y in (("F", 0.07), ("B", -0.07)):
            k.bone = "Wheel_%d%s" % (i, fb)
            h = r * wc + Vector((0, y, 0))
            k.cyl("Wheel%d%s_Magnet_Wheel" % (i, fb), wr, 0.018, tuple(h), align=tuple(ax), seg=24)
            k.cyl("Wheel%d%s_Hub_Bearing" % (i, fb), 0.01, 0.022, tuple(h), align=tuple(ax), seg=12)
    parent_kit(k, rig)
    return rig, k


# =============================================================== TYPE 2B: surface crawler
MMB_SPEC = ("MMR-2B surface crawler | 4 magnetic wheels for ferritic steel tanks/rails + electroadhesive belly pad "
            "for aluminium/titanium | eddy-current + thermal electrical diagnostics | 3.5 kg")


def build_mmr_surface(name="RIG_MMR2B", parent_coll=None):
    col = coll("MMR_MicroRobots", parent_coll)
    bones = [("Root", (0, 0, 0), (0, 0.1, 0), None, False), ("Body", (0, -0.05, 0.05), (0, 0.05, 0.05), "Root", False),
             ("Cam_Tilt", (0, 0.13, 0.11), (0, 0.17, 0.11), "Body", False)]
    W = [("FL", -0.12, 0.1), ("FR", 0.12, 0.1), ("BL", -0.12, -0.1), ("BR", 0.12, -0.1)]
    for n, x, y in W:
        bones.append(("Wheel_" + n, (x, y, 0.035), (x + (0.03 if x > 0 else -0.03), y, 0.035), "Body", False))
    rig = make_rig(name, col, bones)
    _lock_all(rig, {"Root": "xyzXYZ", "Body": "X", "Cam_Tilt": "X", **{"Wheel_" + n: "Y" for n, _, _ in W}})
    rig["lmsp_spec"] = MMB_SPEC
    k = Kit(col, "MMR2B")
    k.bone = "Body"
    k.box("Chassis_Housing", (0.2, 0.3, 0.06), (0, 0, 0.07), bevel=0.012)
    k.box("Belly_ElectroAdhesion_Pad", (0.16, 0.24, 0.006), (0, 0, 0.037), bevel=0.0)
    k.box("Top_Cover", (0.16, 0.22, 0.012), (0, -0.01, 0.106), bevel=0.004)
    k.box("EddySensor_Array_Sensor", (0.14, 0.03, 0.02), (0, 0.16, 0.045), bevel=0.003)
    k.box("Status_LED", (0.12, 0.004, 0.008), (0, -0.152, 0.08), bevel=0.0)
    k.cyl("Mast_Strut", 0.008, 0.06, (0, 0.13, 0.1), base=True, seg=10)
    k.bone = "Cam_Tilt"
    k.box("Cam_Housing", (0.06, 0.05, 0.04), (0, 0.14, 0.17), bevel=0.006)
    k.cyl("Cam_Lens", 0.012, 0.008, (0, 0.167, 0.17), axis='Y', seg=20)
    k.box("Thermal_Cam_Housing", (0.03, 0.03, 0.03), (0.05, 0.14, 0.17), bevel=0.004)
    k.cyl("Thermal_Cam_Lens", 0.009, 0.006, (0.05, 0.157, 0.17), axis='Y', seg=16)
    for n, x, y in W:
        k.bone = "Wheel_" + n
        k.cyl("Wheel%s_Magnet_Wheel" % n, 0.035, 0.03, (x, y, 0.035), axis='X', seg=28)
        k.cyl("Wheel%s_Hub_Bearing" % n, 0.012, 0.034, (x, y, 0.035), axis='X', seg=12)
    parent_kit(k, rig)
    return rig, k


# =============================================================== TYPE 3: EVA exterior robot
EVA_SPEC = ("EVA-3 exterior robot | 1.9 m x 1.6 m, 420 kg | rocker-bogie, 6 titanium chevron wheels with fenders | "
            "4-DOF arm with EDS dust-clearing wand + soft brush | regolith blade | gamma/neutron pod | "
            "sealed ceramic bearings, dust bellows, survives 14-day lunar night on Li-ion + heaters")

WHEELS = {"FL": (-0.8, 0.8), "FR": (0.8, 0.8), "ML": (-0.8, 0.0), "MR": (0.8, 0.0), "BL": (-0.8, -0.8), "BR": (0.8, -0.8)}
WR = 0.26


def _wheel(k, n, x, y):
    s = 1 if x > 0 else -1
    c = Vector((x, y, WR))
    k.lathe("Wheel%s_Hub" % n, [(0.0, -0.06), (0.09, -0.06), (0.1, -0.04), (0.1, 0.06), (0.0, 0.06)], 32,
            loc=tuple(c), axis='X')
    k.lathe("Wheel%s_Motor" % n, [(0.0, 0.0), (0.08, 0.0), (0.08, 0.08), (0.06, 0.1), (0.0, 0.1)], 32,
            loc=tuple(c + Vector((-s * 0.06, 0, 0))), align=(-s, 0, 0))
    k.lathe("Wheel%s_Tire" % n, [(WR - 0.012, -0.11), (WR, -0.105), (WR, 0.105), (WR - 0.012, 0.11)], 48,
            loc=tuple(c), axis='X', cap=False, solid=0.006)
    items = []
    for i in range(20):
        a = i / 20 * TAU
        M = (Matrix.Translation(c) @ Matrix.Rotation(a, 4, 'X') @ Matrix.Translation((0, 0, WR + 0.008))
             @ Matrix.Rotation(0.35 * (1 if i % 2 else -1), 4, 'Y'))
        items.append(((0.2, 0.012, 0.016), M))
    merged_boxes(k, "Wheel%s_Grousers_Chevron" % n, items)
    sp = []
    for i in range(10):
        a = i / 10 * TAU
        for side in (-0.07, 0.07):
            M = Matrix.Translation(c + Vector((side, 0, 0))) @ Matrix.Rotation(a, 4, 'X') @ Matrix.Translation((0, 0, (WR + 0.1) / 2))
            sp.append(((0.008, 0.02, WR - 0.1), M))
    merged_boxes(k, "Wheel%s_Spokes_Titanium" % n, sp)


def build_eva(name="RIG_EVA3", parent_coll=None, prefix="EVA3"):
    col = coll("EVA_ExteriorRobots", parent_coll)
    bones = [("Root", (0, 0, 0), (0, 0.5, 0), None, False), ("Body", (0, 0, 0.75), (0, 0.4, 0.75), "Root", False)]
    for s, sd in ((-1, "L"), (1, "R")):
        bones += [("Rocker_" + sd, (s * 0.62, 0.15, 0.75), (s * 0.72, 0.15, 0.75), "Body", False),
                  ("Bogie_" + sd, (s * 0.72, -0.4, 0.5), (s * 0.82, -0.4, 0.5), "Rocker_" + sd, False),
                  ("Steer_F" + sd, (s * 0.8, 0.8, 0.52), (s * 0.8, 0.8, 0.62), "Rocker_" + sd, False),
                  ("Steer_B" + sd, (s * 0.8, -0.8, 0.52), (s * 0.8, -0.8, 0.62), "Bogie_" + sd, False),
                  ("Wheel_F" + sd, (s * 0.8, 0.8, WR), (s * 0.9, 0.8, WR), "Steer_F" + sd, False),
                  ("Wheel_M" + sd, (s * 0.8, 0.0, WR), (s * 0.9, 0.0, WR), "Bogie_" + sd, False),
                  ("Wheel_B" + sd, (s * 0.8, -0.8, WR), (s * 0.9, -0.8, WR), "Steer_B" + sd, False)]
    bones += [("Arm_Base_Yaw", (0, 0.72, 0.98), (0, 0.72, 1.08), "Body", False),
              ("Arm_Shoulder", (0, 0.72, 1.08), (0, 1.32, 1.08), "Arm_Base_Yaw", True),
              ("Arm_Elbow", (0, 1.32, 1.08), (0, 1.82, 1.08), "Arm_Shoulder", True),
              ("Arm_Wrist", (0, 1.82, 1.08), (0, 1.98, 1.08), "Arm_Elbow", True),
              ("Mast_Pan", (-0.45, 0.55, 1.62), (-0.45, 0.55, 1.75), "Body", False),
              ("Mast_Tilt", (-0.45, 0.55, 1.75), (-0.45, 0.72, 1.75), "Mast_Pan", True),
              ("Blade_Pitch", (0, 0.86, 0.5), (0, 1.0, 0.5), "Body", False)]
    rig = make_rig(name, col, bones)
    free = {"Root": "xyzXYZ", "Body": "XYZz", "Arm_Base_Yaw": "Y", "Arm_Shoulder": "X", "Arm_Elbow": "X", "Arm_Wrist": "X",
            "Mast_Pan": "Y", "Mast_Tilt": "X", "Blade_Pitch": "X"}
    for b in bones:
        if b[0].startswith(("Wheel_", "Steer_", "Rocker_", "Bogie_")):
            free[b[0]] = "Y"
    _lock_all(rig, free)
    rig["lmsp_spec"] = EVA_SPEC
    k = Kit(col, prefix)
    k.bone = "Body"
    k.box("Chassis_Frame", (1.1, 1.5, 0.3), (0, 0, 0.78), bevel=0.02)
    k.box("Body_BetaCloth", (1.14, 1.4, 0.12), (0, -0.04, 0.99), bevel=0.03)
    k.box("Deck_Radiator_OSR", (0.9, 0.6, 0.02), (0, -0.35, 1.06), bevel=0.003)
    k.box("Deck_Solar_Cells", (0.9, 0.5, 0.02), (0, 0.25, 1.06), bevel=0.003)
    k.box("Avionics_AccessPanel_Cover", (0.012, 0.5, 0.2), (0.556, -0.2, 0.78), bevel=0.003)
    k.bolts("Avionics_Panel_Bolts", [(0.563, -0.2 + dy, 0.78 + dz) for dy in (-0.23, 0.23) for dz in (-0.08, 0.08)],
            (1, 0, 0), 0.01, 0.008)
    k.box("Battery_Electronics", (0.4, 0.3, 0.2), (-0.2, -0.55, 0.62), bevel=0.012)
    k.box("Front_StatusLED", (0.6, 0.012, 0.02), (0, 0.752, 0.86), bevel=0.0)
    k.lathe("Beacon_LED", [(0.03, 1.1), (0.03, 1.15), (0.02, 1.17), (0.0, 1.175)], 24, loc=(0.45, -0.6, 0))
    for s, sd in ((-1, "L"), (1, "R")):
        k.cyl("Pivot%s_Bearing" % sd, 0.07, 0.1, (s * 0.6, 0.15, 0.75), axis='X', seg=32)
        k.bellows("Pivot%s_DustBellows" % sd, 0.075, 0.09, -0.02, 0.06, 2, loc=(s * 0.56, 0.15, 0.75), axis='X', seg=32)
        loc = Vector((s * 0.42, 0.76, 0.75))
        k.lathe("Flood%s_Housing" % sd, [(0.0, -0.08), (0.045, -0.08), (0.06, -0.04), (0.065, 0.0)], 32, loc=loc, align=(0, 1, 0))
        k.cyl("Flood%s_Emitter" % sd, 0.055, 0.004, tuple(loc + Vector((0, 0.002, 0))), axis='Y', seg=32)
        k.light("Flood%s" % sd, 'SPOT', 600, (1.0, 0.97, 0.92), tuple(loc + Vector((0, 0.02, 0))), (0, 1, -0.3),
                math.radians(70), 0.05)
    k.box("RadPod_Electronics", (0.3, 0.22, 0.18), (0.25, -0.72, 1.14), bevel=0.012)
    k.cyl("RadPod_Gamma_Detector_Housing", 0.05, 0.28, (0.25, -0.86, 1.14), axis='Y', seg=28)
    for i in range(3):
        k.cyl("RadPod_Neutron%d_Aluminum" % i, 0.015, 0.26, (0.16 + i * 0.03, -0.72, 1.23), base=True, seg=12)
    # rocker-bogie
    for s, sd in ((-1, "L"), (1, "R")):
        k.bone = "Rocker_" + sd
        piv = Vector((s * 0.72, 0.15, 0.75))
        for nm, p1 in (("Front", Vector((s * 0.8, 0.8, 0.52))), ("Rear", Vector((s * 0.72, -0.4, 0.5)))):
            k.cyl("Rocker%s_%s_Strut" % (sd, nm), 0.035, (p1 - piv).length, tuple(piv), align=tuple(p1 - piv), base=True, seg=20)
        k.cyl("Rocker%s_Hub_Fitting" % sd, 0.06, 0.08, tuple(piv), axis='X', seg=24)
        k.lathe("SteerF%s_Motor" % sd, [(0.0, 0.0), (0.06, 0.0), (0.06, 0.12), (0.0, 0.14)], 24, loc=(s * 0.8, 0.8, 0.52))
        k.bone = "Bogie_" + sd
        bp = Vector((s * 0.72, -0.4, 0.5))
        for nm, p1 in (("Mid", Vector((s * 0.8, 0.0, 0.48))), ("Back", Vector((s * 0.8, -0.8, 0.52)))):
            k.cyl("Bogie%s_%s_Strut" % (sd, nm), 0.03, (p1 - bp).length, tuple(bp), align=tuple(p1 - bp), base=True, seg=20)
        k.cyl("Bogie%s_Hub_Fitting" % sd, 0.05, 0.08, tuple(bp), axis='X', seg=24)
        k.cyl("Bogie%s_MidLeg_Strut" % sd, 0.03, 0.22, (s * 0.8, 0.0, 0.26), base=True, seg=16)
        k.lathe("SteerB%s_Motor" % sd, [(0.0, 0.0), (0.06, 0.0), (0.06, 0.12), (0.0, 0.14)], 24, loc=(s * 0.8, -0.8, 0.52))
        for fb in ("F", "B"):
            k.bone = "Steer_%s%s" % (fb, sd)
            y = 0.8 if fb == "F" else -0.8
            k.cyl("Steer%s%s_Leg_Strut" % (fb, sd), 0.03, 0.26, (s * 0.8, y, 0.26), base=True, seg=16)
            k.plate("Fender%s%s_Cover" % (fb, sd), [(y - 0.32, 0.4), (y + 0.32, 0.4), (y + 0.3, 0.5), (y - 0.3, 0.5)],
                    0.26, (s * 0.8, 0, 0.12), 'YZ', 0.01)
        k.bone = "Bogie_" + sd
        k.plate("FenderM%s_Cover" % sd, [(-0.32, 0.4), (0.32, 0.4), (0.3, 0.5), (-0.3, 0.5)], 0.26, (s * 0.8, 0, 0.12), 'YZ', 0.01)
    for n, (x, y) in WHEELS.items():
        sd = n[1]
        k.bone = "Wheel_%s%s" % (n[0], sd)
        _wheel(k, n, x, y)
    # arm with EDS wand + brush
    k.bone = "Arm_Base_Yaw"
    k.lathe("Arm_Base_Collar", [(0.12, 0.98), (0.13, 1.0), (0.13, 1.06), (0.1, 1.08), (0.0, 1.08)], 40, loc=(0, 0.72, 0))
    k.bone = "Arm_Shoulder"
    k.cyl("Arm_Shoulder_Drum_Titanium", 0.075, 0.18, (0, 0.72, 1.08), axis='X', seg=32)
    k.cyl("Arm_Upper_Tube_CFRP", 0.045, 0.46, (0, 1.05, 1.08), axis="Y", seg=32)
    k.box("Arm_Upper_Fitting", (0.1, 0.06, 0.1), (0, 1.3, 1.08), bevel=0.008)
    k.bone = "Arm_Elbow"
    k.cyl("Arm_Elbow_Drum_Titanium", 0.06, 0.15, (0, 1.32, 1.08), axis='X', seg=28)
    k.cyl("Arm_Fore_Tube_CFRP", 0.04, 0.44, (0, 1.57, 1.08), axis='Y', seg=28)
    k.bone = "Arm_Wrist"
    k.cyl("Arm_Wrist_Drum_Titanium", 0.05, 0.12, (0, 1.82, 1.08), axis='X', seg=24)
    k.box("EDS_Wand_Housing", (0.5, 0.06, 0.05), (0, 1.94, 1.08), bevel=0.008)
    k.box("EDS_Wand_Electrode_Copper", (0.46, 0.004, 0.035), (0, 1.972, 1.08), bevel=0.0)
    k.cyl("CleanBrush_Pad", 0.03, 0.46, (0, 1.95, 1.03), axis='X', seg=24)
    k.bone = "Mast_Pan"
    k.cyl("Mast_Strut", 0.03, 0.62, (-0.45, 0.55, 1.05), base=True, seg=20)
    k.bellows("Mast_Pan_DustBellows", 0.035, 0.045, 1.58, 1.64, 2, loc=(-0.45, 0.55, 0), seg=24)
    k.lathe("HGA_Dish_Aluminum", [(0.0, 0.0), (0.08, 0.015), (0.15, 0.05), (0.15, 0.055), (0.0, 0.01)], 40,
            loc=(-0.45, 0.45, 1.5), align=(0.3, -1, 0.6))
    k.bone = "Mast_Tilt"
    k.box("MastHead_Housing", (0.3, 0.1, 0.1), (-0.45, 0.6, 1.75), bevel=0.012)
    for s in (-1, 1):
        k.cyl("MastHead_Stereo%s_Lens" % ("L" if s < 0 else "R"), 0.022, 0.015, (-0.45 + s * 0.1, 0.652, 1.75), axis='Y', seg=24)
    k.lathe("MastHead_Lidar_Sensor", [(0.04, 1.8), (0.045, 1.81), (0.045, 1.86), (0.0, 1.87)], 28, loc=(-0.45, 0.6, 0))
    k.bone = "Blade_Pitch"
    k.plate("Dozer_Blade", [(0.86, 0.28), (0.9, 0.28), (1.0, 0.36), (1.02, 0.5), (0.98, 0.6), (0.94, 0.6), (0.97, 0.5),
                            (0.95, 0.38), (0.88, 0.32)], 1.4, (0, 0, 0), 'YZ', 0.006)
    k.box("Dozer_CuttingEdge_Titanium", (1.4, 0.04, 0.03), (0, 0.89, 0.285), bevel=0.003)
    for s in (-1, 1):
        k.cyl("Dozer%s_Piston_Rod" % ("L" if s < 0 else "R"), 0.018, 0.3, (s * 0.4, 0.62, 0.68), align=(0, 0.6, -0.3),
              base=True, seg=16)
        k.cyl("Dozer%s_Barrel" % ("L" if s < 0 else "R"), 0.03, 0.2, (s * 0.4, 0.55, 0.72), align=(0, 0.6, -0.3), base=True, seg=16)
    parent_kit(k, rig)
    return rig, k
