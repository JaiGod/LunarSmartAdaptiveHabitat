"""Launch background Blender jobs (renders / GLB export) without freezing the open session."""
import bpy, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
JOBS = os.path.join(ROOT, "scripts", "jobs")
BLEND = os.path.join(ROOT, "PHMA-1_Robotic_Maintenance_Fleet.blend")


def launch(script, args, log_name):
    log = open(os.path.join(ROOT, "docs", log_name), "w")
    cmd = [bpy.app.binary_path, "-b", BLEND, "--python", os.path.join(JOBS, script), "--"] + [str(a) for a in args]
    flags = 0x08000000 if os.name == 'nt' else 0
    p = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT, creationflags=flags)
    return p.pid


def render(scene, frame, samples, rx, ry, name, camera="-", age=None):
    out = os.path.join(ROOT, "renders", name)
    args = [scene, frame, samples, rx, ry, out, camera] + ([age] if age is not None else [])
    return launch("render_job.py", args, "render_%s.log" % name.replace(".png", "")), out


def export(quick=False):
    return launch("export_job.py", [os.path.join(ROOT, "exports_glb")] + (["quick"] if quick else []), "export.log")


def queue(items, name="queue"):
    import json
    p = os.path.join(ROOT, "docs", name + ".json")
    for it in items:
        it["out"] = os.path.join(ROOT, "renders", it["out"])
    json.dump(items, open(p, "w"), indent=1)
    return launch("render_queue.py", [p], name + ".log")
