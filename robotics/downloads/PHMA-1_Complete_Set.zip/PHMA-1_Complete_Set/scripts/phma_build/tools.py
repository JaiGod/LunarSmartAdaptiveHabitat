"""PHMA-1 interchangeable end effectors. Each tool is built with its quick-change coupling face
at z=0 and the tool extending along +Z, then transformed to wherever it is mounted/stowed."""
import bpy, math
from mathutils import Vector, Matrix
from .common import Kit, coll, TAU

TOOL_SPECS = {
    "TL01": ("Precision Repair Gripper", "0.6 m x 0.3 m | parallel jaws, force-torque sensor, palm camera | "
             "electronics/ORU swaps, tool handling"),
    "TL02": ("Smart Welding Tool", "3.5 kW | fibre-laser head (works in vacuum) + arc torch for pressurised interiors | "
             "seam-tracking camera | hull, pipe, structural repair"),
    "TL03": ("Hydraulic Cutter", "0.8 m | 120 kN | emergency structural cutting, damaged component removal"),
    "TL04": ("Core Drill", "brushless spindle, titanium core bit, bellows chip shroud (no loose debris in vacuum)"),
    "TL05": ("Inspection Camera", "pan-tilt HD camera, ring light, articulated snake probe for cavities"),
    "TL06": ("Radiation Diagnostic Scanner", "25 m range | CZT gamma detector, He-3 neutron counters, particle flux telescope"),
    "TL07": ("Leak Detection Scanner", "ultrasonic phased array, LWIR thermal camera, mass-spec sniffer + ion gauge"),
    "TL08": ("Cargo Manipulator", "latching end effector (3-wire snare) for grapple fixtures | 2500 kg lunar"),
}


def coupling(k):
    k.lathe("Coupling_Plate", [(0.0, 0.0), (0.15, 0.0), (0.172, 0.012), (0.172, 0.05), (0.155, 0.065), (0.12, 0.07),
                               (0.0, 0.07)], 48)
    k.ring("Coupling_Latch_Ring", 0.18, 0.165, 0.03, (0, 0, 0.035), seg=48)
    k.bolt_circle("Coupling_Bolts", 8, 0.14, 0.07, 'Z', r=0.008, h=0.006)


def tl01_gripper(k):
    coupling(k)
    k.lathe("Gripper_FTSensor_Housing", [(0.0, 0.07), (0.12, 0.07), (0.13, 0.08), (0.13, 0.11), (0.12, 0.12), (0.0, 0.12)], 48)
    k.box("Gripper_Body", (0.3, 0.16, 0.2), (0, 0, 0.22), bevel=0.015)
    k.box("Gripper_Guide_Rail", (0.3, 0.05, 0.025), (0, 0, 0.333), bevel=0.003)
    for s in (-1, 1):
        n = "L" if s < 0 else "R"
        k.box("Gripper_Slide%s_Bracket" % n, (0.06, 0.08, 0.04), (s * 0.09, 0, 0.36), bevel=0.004)
        k.box("Gripper_Finger%s_Titanium" % n, (0.035, 0.11, 0.26), (s * 0.09, 0, 0.5), bevel=0.006)
        k.box("Gripper_Finger%s_Pads" % n, (0.012, 0.09, 0.12), (s * 0.066, 0, 0.56), bevel=0.002)
        k.box("Gripper_Tip%s_Titanium" % n, (0.03, 0.1, 0.03), (s * 0.08, 0, 0.635), rotx=0.0, roty=s * 0.5, bevel=0.004)
    k.cyl("Gripper_PalmCam_Lens", 0.018, 0.015, (0, -0.081, 0.25), axis='Y', seg=24)
    k.box("Gripper_StatusLED", (0.04, 0.006, 0.012), (0.1, -0.081, 0.3), bevel=0.0)


def tl02_welder(k):
    coupling(k)
    k.lathe("Welder_PowerUnit_Body", [(0.0, 0.07), (0.12, 0.07), (0.13, 0.09), (0.13, 0.32), (0.11, 0.35), (0.0, 0.35)], 48)
    for i in range(6):
        k.ring("Welder_Fin%d_Ring" % i, 0.15, 0.128, 0.01, (0, 0, 0.12 + i * 0.035), seg=48)
    k.lathe("Welder_LaserNozzle_Titanium", [(0.06, 0.35), (0.07, 0.37), (0.07, 0.45), (0.04, 0.56), (0.02, 0.6),
                                             (0.0, 0.6)], 40)
    k.cyl("Welder_LaserExit_Lens", 0.016, 0.004, (0, 0, 0.6), seg=24)
    k.cyl("Welder_ArcTorch_Body", 0.025, 0.22, (0.1, 0, 0.42), align=(-0.35, 0, 1), seg=20)
    k.cyl("Welder_ArcTorch_Copper", 0.012, 0.05, (0.06, 0, 0.53), align=(-0.35, 0, 1), seg=16)
    k.box("Welder_Spool_Bracket", (0.03, 0.1, 0.12), (-0.13, 0, 0.22), bevel=0.004)
    k.lathe("Welder_WireFeed_Spool", [(0.03, -0.04), (0.07, -0.04), (0.07, -0.035), (0.05, -0.035), (0.05, 0.035),
                                      (0.07, 0.035), (0.07, 0.04), (0.03, 0.04)], 32, loc=(-0.19, 0, 0.22), axis='Y', cap=False)
    k.torus("Welder_Wire_Copper", 0.05, 0.012, (-0.19, 0, 0.22), axis='Y', seg=32, rseg=8)
    k.box("Welder_SeamCam_Housing", (0.06, 0.06, 0.08), (0, -0.115, 0.47), bevel=0.006)
    k.cyl("Welder_SeamCam_Lens", 0.016, 0.01, (0, -0.148, 0.47), axis='Y', seg=24)
    k.cable("Welder_Power_Cable", [(0.12, 0.0, 0.3), (0.16, 0.02, 0.36), (0.12, 0.0, 0.42)], 0.01)
    glow = k.cyl("Welder_Plasma_Glow", 0.03, 0.035, (0, 0, 0.618), seg=16, props={"lmsp_weld_glow": 1})
    glow.hide_render = True
    glow.hide_viewport = True
    # the laser keyhole plasma is bright enough to light the hull around it
    pl = k.light("Welder_Plasma_Light", 'POINT', 450, (0.72, 0.84, 1.0), (0, 0, 0.64), (0, 0, 1), size=0.01)
    pl["lmsp_weld_glow"] = 1
    pl.hide_render = True
    pl.hide_viewport = True


def tl03_cutter(k):
    coupling(k)
    k.lathe("Cutter_Barrel", [(0.0, 0.07), (0.09, 0.07), (0.1, 0.09), (0.1, 0.38), (0.08, 0.41), (0.0, 0.41)], 40)
    k.cyl("Cutter_Piston_Rod", 0.03, 0.08, (0, 0, 0.41), base=True, seg=24)
    k.box("Cutter_Yoke_Frame", (0.08, 0.14, 0.09), (0, 0, 0.47), bevel=0.008)
    pr = [(-0.01, 0.46), (0.03, 0.46), (0.07, 0.55), (0.085, 0.65), (0.06, 0.75), (0.0, 0.8), (-0.012, 0.785),
          (0.025, 0.71), (0.03, 0.6), (-0.005, 0.52)]
    k.plate("Cutter_JawR_Blade", pr, 0.028, (0, 0.018, 0), 'XZ', 0.003)
    pl = [(-x, z) for (x, z) in reversed(pr)]
    k.plate("Cutter_JawL_Blade", pl, 0.028, (0, -0.018, 0), 'XZ', 0.003)
    k.cyl("Cutter_Pivot_Pin", 0.02, 0.1, (0, 0, 0.49), axis='Y', seg=20)
    k.cyl("Cutter_Gauge_Body", 0.025, 0.02, (0.1, 0, 0.3), axis='X', seg=24)
    k.cyl("Cutter_Gauge_Glass", 0.022, 0.004, (0.111, 0, 0.3), axis='X', seg=24)
    k.cable("Cutter_Supply_Hose", [(-0.09, 0, 0.12), (-0.13, 0, 0.22), (-0.1, 0, 0.36)], 0.012)


def tl04_drill(k):
    coupling(k)
    k.lathe("Drill_Motor", [(0.0, 0.07), (0.1, 0.07), (0.11, 0.09), (0.11, 0.32), (0.08, 0.36), (0.0, 0.36)], 40)
    for i in range(5):
        k.ring("Drill_Fin%d_Ring" % i, 0.125, 0.108, 0.01, (0, 0, 0.12 + i * 0.04), seg=40)
    k.lathe("Drill_GearHead_Gearbox", [(0.07, 0.36), (0.08, 0.38), (0.06, 0.42), (0.0, 0.42)], 40)
    k.lathe("Drill_Chuck", [(0.045, 0.42), (0.05, 0.44), (0.05, 0.48), (0.035, 0.5), (0.0, 0.5)], 32)
    k.cyl("Drill_CoreBit_Titanium", 0.032, 0.28, (0, 0, 0.5), base=True, seg=32)
    pts = [(math.cos(t) * 0.034, math.sin(t) * 0.034, 0.5 + t / (TAU * 4) * 0.26) for t in [i * 0.4 for i in range(int(TAU * 4 / 0.4) + 1)]]
    k.cable("Drill_Flute_Chrome", pts, 0.004, res=4)
    k.ring("Drill_Crown_Ring", 0.036, 0.024, 0.02, (0, 0, 0.78), seg=32)
    k.bellows("Drill_DustShroud_Bellows", 0.05, 0.066, 0.43, 0.6, 6, seg=32)


def tl05_inspection(k):
    coupling(k)
    k.box("InspCam_Base_Housing", (0.16, 0.16, 0.08), (0, 0, 0.11), bevel=0.01)
    for s in (-1, 1):
        k.box("InspCam_Yoke%s_Bracket" % ("F" if s < 0 else "B"), (0.03, 0.02, 0.22), (0, s * 0.09, 0.26), bevel=0.004)
    k.box("InspCam_Housing", (0.14, 0.15, 0.12), (0, 0, 0.32), bevel=0.012)
    k.lathe("InspCam_Lens_Barrel", [(0.0, 0.0), (0.05, 0.0), (0.05, 0.06), (0.045, 0.08), (0.0, 0.08)], 40,
            loc=(0, -0.075, 0.32), align=(0, -1, 0))
    k.cyl("InspCam_Front_Lens", 0.04, 0.008, (0, -0.158, 0.32), axis='Y', seg=40)
    k.torus("InspCam_Ring_LED", 0.052, 0.006, (0, -0.157, 0.32), axis='Y', seg=40, rseg=6)
    k.cable("InspCam_SnakeProbe_Conduit", [(0.08, 0.0, 0.12), (0.2, 0.0, 0.18), (0.28, -0.05, 0.35), (0.25, -0.1, 0.5)], 0.012)
    k.cyl("InspCam_ProbeTip_Housing", 0.017, 0.045, (0.25, -0.1, 0.52), seg=20)
    k.cyl("InspCam_ProbeTip_Lens", 0.012, 0.004, (0.25, -0.1, 0.545), seg=20)


def tl06_radiation(k):
    coupling(k)
    k.box("RadScan_Electronics", (0.26, 0.2, 0.18), (0, 0, 0.17), bevel=0.012)
    k.cyl("RadScan_Gamma_Detector_Housing", 0.05, 0.3, (-0.07, -0.02, 0.26), base=True, seg=32)
    k.cyl("RadScan_Gamma_Window_Glass", 0.046, 0.005, (-0.07, -0.02, 0.562), seg=32)
    k.cyl("RadScan_Moderator_Paint", 0.06, 0.22, (0.07, 0.03, 0.26), base=True, seg=32)
    for i, (x, y) in enumerate(((0.05, 0.01), (0.09, 0.01), (0.07, 0.05))):
        k.cyl("RadScan_Neutron%d_Aluminum" % i, 0.016, 0.34, (x, y, 0.26), base=True, seg=16)
    k.lathe("RadScan_FluxTelescope_Housing", [(0.03, 0.0), (0.05, 0.08), (0.055, 0.1), (0.0, 0.1)], 32,
            loc=(0.07, -0.1, 0.2), align=(0, -1, 0))
    for i in range(3):
        k.ring("RadScan_Collimator%d_Ring" % i, 0.05, 0.035, 0.006, (0.07, -0.13 - i * 0.02, 0.2), axis='Y', seg=32)
    k.box("RadScan_Status_Screen", (0.12, 0.004, 0.07), (-0.04, -0.102, 0.17), bevel=0.0)
    k.box("RadScan_StatusLED", (0.03, 0.004, 0.01), (0.1, -0.102, 0.24), bevel=0.0)


def tl07_leak(k):
    coupling(k)
    k.lathe("LeakScan_Body", [(0.0, 0.07), (0.1, 0.07), (0.11, 0.09), (0.11, 0.2), (0.0, 0.2)], 40)
    k.lathe("LeakScan_Dish_Housing", [(0.0, 0.2), (0.06, 0.21), (0.13, 0.25), (0.15, 0.285), (0.14, 0.29), (0.06, 0.255),
                                      (0.0, 0.25)], 48)
    pts = []
    for ring_r, n in ((0.0, 1), (0.04, 6), (0.08, 12)):
        for i in range(n):
            a = i / n * TAU
            pts.append((math.cos(a) * ring_r, math.sin(a) * ring_r, 0.255 + ring_r * 0.35))
    k.clamps("LeakScan_Transducers_Sensor", pts, 0.013)
    k.box("LeakScan_ThermalCam_Housing", (0.07, 0.08, 0.08), (0.14, 0, 0.14), bevel=0.008)
    k.cyl("LeakScan_ThermalCam_Lens", 0.022, 0.01, (0.14, -0.045, 0.14), axis='Y', seg=24)
    k.cyl("LeakScan_MassSpec_Probe_Titanium", 0.008, 0.25, (-0.12, 0.0, 0.15), base=True, seg=12)
    k.cyl("LeakScan_IonGauge_Housing", 0.03, 0.09, (-0.12, 0.0, 0.1), base=True, seg=24)


def tl08_lee(k):
    coupling(k)
    k.lathe("LEE_Shell_Paint", [(0.16, 0.07), (0.2, 0.1), (0.2, 0.58), (0.19, 0.6), (0.17, 0.6), (0.17, 0.12)], 56, cap=False)
    k.lathe("LEE_Floor_Plate", [(0.0, 0.11), (0.17, 0.11), (0.17, 0.125), (0.0, 0.125)], 48)
    k.torus("LEE_Mouth_Ring", 0.185, 0.012, (0, 0, 0.6), seg=56, rseg=8)
    k.ring("LEE_Snare_Ring", 0.17, 0.155, 0.03, (0, 0, 0.5), seg=48)
    for i in range(3):
        a = i / 3 * TAU
        p0 = (math.cos(a) * 0.16, math.sin(a) * 0.16, 0.5)
        p1 = (math.cos(a + 2.1) * 0.16, math.sin(a + 2.1) * 0.16, 0.5)
        mid = (math.cos(a + 1.05) * 0.05, math.sin(a + 1.05) * 0.05, 0.46)
        k.cable("LEE_Snare%d_Cable" % i, [p0, mid, p1], 0.005)
    k.box("LEE_SideCam_Housing", (0.06, 0.07, 0.08), (0.22, 0, 0.45), bevel=0.006)
    k.cyl("LEE_SideCam_Lens", 0.016, 0.01, (0.22, -0.04, 0.45), axis='Y', seg=24)
    k.torus("LEE_Status_LED", 0.2, 0.004, (0, 0, 0.3), seg=56, rseg=6)


BUILDERS = {"TL01": tl01_gripper, "TL02": tl02_welder, "TL03": tl03_cutter, "TL04": tl04_drill,
            "TL05": tl05_inspection, "TL06": tl06_radiation, "TL07": tl07_leak, "TL08": tl08_lee}


def build_tool(k, key, M, bone=None):
    """Build tool `key` inside kit k, placed by matrix M. Returns the created objects."""
    old_prefix, old_bone = k.prefix, k.bone
    k.prefix = "%s_%s" % (old_prefix, key) if old_prefix else key
    if bone is not None:
        k.bone = bone
    start = len(k.all)
    BUILDERS[key](k)
    k.transform_since(start, M)
    objs = k.all[start:]
    for o in objs:
        o["lmsp_tool"] = key
        o["lmsp_spec"] = "%s - %s" % TOOL_SPECS[key]
    k.prefix, k.bone = old_prefix, old_bone
    return objs


def build_tool_library(parent_coll=None, origin=(-24.0, -15.0, 0.0)):
    """All eight tools side by side (export: PHMA_ToolHeads.glb). Returns {key: [objects]}."""
    col = coll("PHMA_ToolHeads", parent_coll)
    k = Kit(col, "")
    out = {}
    for i, key in enumerate(sorted(BUILDERS)):
        M = Matrix.Translation(Vector(origin) + Vector((i * 0.75, 0, 0)))
        out[key] = build_tool(k, key, M)
        # a display stand under each tool (part of the docking station)
    return out, k


def set_visible(objs, visible, frame=None):
    for o in objs:
        o.hide_render = not visible
        o.hide_viewport = not visible
        if frame is not None:
            o.keyframe_insert("hide_render", frame=frame)
            o.keyframe_insert("hide_viewport", frame=frame)
