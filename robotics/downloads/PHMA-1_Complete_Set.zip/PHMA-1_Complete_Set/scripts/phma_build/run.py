"""Stage runner. In Blender (Scripting tab) run:

    import sys; sys.path.insert(0, r"<project>\\scripts"); from phma_build import run; run.build_all()

or call the stages one by one. Builds into the CURRENT (new, empty) file and saves it to a new path.
"""
import bpy, os, sys, math, json, time, traceback
from mathutils import Vector, Matrix

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BLEND = os.path.join(ROOT, "PHMA-1_Robotic_Maintenance_Fleet.blend")
for p in (os.path.join(ROOT, "addon"), os.path.join(ROOT, "scripts")):
    if p not in sys.path:
        sys.path.insert(0, p)

S = bpy.app.driver_namespace.setdefault("phma_state", {})


def addon():
    import lunar_material_studio_pro as L
    if not hasattr(bpy.types.Scene, "lmsp"):
        L.register()
    return L


def main_scene():
    sc = bpy.data.scenes.get("LSAH_Robotics")
    if sc is None:
        sc = bpy.context.scene
        sc.name = "LSAH_Robotics"
    return sc


def _t(fn):
    def w(*a, **k):
        t0 = time.time()
        try:
            r = fn(*a, **k)
            out = {"ok": True, "sec": round(time.time() - t0, 1)}
            if isinstance(r, dict):
                out.update(r)
            return out
        except Exception:
            return {"ok": False, "err": traceback.format_exc()[-3000:]}
    w.__name__ = fn.__name__
    return w


@_t
def stage_materials():
    L = addon()
    sc = main_scene()
    # extra library entry (red E-stop paint) - persisted into the add-on source too
    mp = os.path.join(ROOT, "addon", "lunar_material_studio_pro", "materials.py")
    src = open(mp, encoding="utf-8").read()
    if "PHMA_PaintRed" not in src:
        src = src.replace('        ("PHMA_PaintHazard", lambda: mat_hazard()),',
                          '        ("PHMA_PaintRed", lambda: mat_paint("PHMA_PaintRed", (0.55, 0.02, 0.02), 0.45, wear=1.4)),\n'
                          '        ("PHMA_PaintHazard", lambda: mat_hazard()),')
        open(mp, "w", encoding="utf-8").write(src)
    ap = os.path.join(ROOT, "addon", "lunar_material_studio_pro", "assign.py")
    src = open(ap, encoding="utf-8").read()
    if '"PHMA_PaintRed"' not in src:
        src = src.replace('    "PHMA_PaintHazard": ["hazard", "stripe", "stripes"],',
                          '    "PHMA_PaintHazard": ["hazard", "stripe", "stripes"],\n    "PHMA_PaintRed": ["red", "paintred", "estop"],')
        open(ap, "w", encoding="utf-8").write(src)
    made, errors = L.materials.build_library(sc)
    m = L.materials.mat_paint("PHMA_PaintRed", (0.55, 0.02, 0.02), 0.45, wear=1.4)
    m.use_fake_user = True
    for t in ("red", "paintred", "estop"):
        L.assign.TOKEN_TO_MAT[t] = "PHMA_PaintRed"
    return {"materials": len(made) + 1, "errors": list(errors)}


@_t
def stage_habitat():
    from phma_build import habitat
    from phma_build.common import coll
    site = habitat.build_site()
    inter = habitat.build_interior()
    fl = coll("LGT_Site_Floodlights")
    for lo in site["flood_lights"]:
        for c in list(lo.users_collection):
            c.objects.unlink(lo)
        fl.objects.link(lo)
    S["site"] = {"hero_cam_xy": tuple(site["hero_cam_xy"]), "track_length": site["track_length"]}
    S["interior"] = {"pipe": inter["pipe"]}
    return {"track_length_m": round(site["track_length"], 1), "objects": len(bpy.data.objects)}


@_t
def stage_robots():
    from phma_build import arm, tools, fleet, habitat
    from phma_build.common import parent_kit, coll
    out = {}
    # ---- PHMA-1 exterior
    ext, ke = arm.build_phma('EXT')
    TM = Matrix.Translation((0, 0, arm.TM1))
    tools.build_tool(ke, "TL01", TM, bone="Tool_Mount")
    wl = tools.build_tool(ke, "TL02", TM, bone="Tool_Mount")
    tools.set_visible([o for o in wl if not o.get("lmsp_weld_glow")], False)
    ke.bone = "Tool_Mount"
    ke.cyl("TL02_Spark_Emitter", 0.006, 0.006, (0, 0, arm.TM1 + 0.63), seg=8)
    ke.cyl("Patch_Plate", 0.3, 0.012, (0, 0, arm.TM1 + 0.645), seg=48, bevel=0.003)
    for i, key in enumerate(("TL03", "TL06", "TL07")):
        x = (-0.42, 0.0, 0.42)[i]
        tools.build_tool(ke, key, Matrix.Translation((x, 1.18, 1.2)) @ Matrix.Rotation(math.pi, 4, 'X'), bone="Carriage")
    arm.decorate_phma(ke, True)
    parent_kit(ke, ext)
    ext.matrix_world = Matrix.Translation(habitat.ARM_HOME) @ Matrix.Rotation(-math.pi / 2, 4, 'Z')
    out["ext_parts"] = len(ke.all)
    # ---- PHMA-1i interior (ceiling-mounted, inverted, 0.4 scale)
    intr, ki = arm.build_phma('INT')
    tools.build_tool(ki, "TL01", TM, bone="Tool_Mount")
    arm.decorate_phma(ki, False)
    parent_kit(ki, intr)
    O = habitat.INTERIOR_O
    R = Matrix(((0, 1, 0, 0), (1, 0, 0, 0), (0, 0, -1, 0), (0, 0, 0, 1)))
    intr.matrix_world = Matrix.Translation(O + Vector((-4.5, 0.0, 4.08))) @ R @ Matrix.Scale(0.4, 4)
    out["int_parts"] = len(ki.all)
    # ---- tool library on the dock table
    lib, kl = tools.build_tool_library(origin=(-30.6, 2.5, 0.89))
    # ---- micro robots
    py, pz = S.get("interior", {}).get("pipe", (1.25, 1.55))
    a, _ = fleet.build_mmr_pipe(pipe_r=0.124)
    a.location = O + Vector((-6.0, py, pz))
    a.rotation_euler = (0, 0, -math.pi / 2)
    b, _ = fleet.build_mmr_surface()
    b.location = O + Vector((-4.2, -0.75, 0.76))
    b.rotation_euler = (0, 0, math.pi / 2)
    # ---- EVA exterior robots
    for nm, pre, loc, yaw in (("RIG_EVA3_A", "EVA3A", (27.0, -7.0, 0.0), math.pi),
                              ("RIG_EVA3_B", "EVA3B", (-26.0, -9.0, 0.0), 0.0),
                              ("RIG_EVA3_C", "EVA3C", (25.2, 0.0, 0.0), -math.pi / 2)):
        r, _ = fleet.build_eva(nm, prefix=pre)
        r.location = loc
        r.rotation_euler = (0, 0, yaw)
    bpy.context.view_layer.update()
    out["rigs"] = [o.name for o in bpy.data.objects if o.type == 'ARMATURE']
    return out


KEEP_UV = {"PHMA_ScreenUI", "PHMA_KevlarWire", "PHMA_WeldSeam", "PHMA_WeldHeatTint"}


def clean_uvs(L, objs=None):
    """Smart-UV every mesh that lacks UVs or has overlapping ones (except shaders that need their own UVs)."""
    objs = objs or [o for o in main_scene().objects if o.type == 'MESH' and not o.get("lmsp_decal")
                    and not o.get("lmsp_preview") and o.name != "ENV_Lunar_Terrain"]
    todo = []
    for o in objs:
        m = o.material_slots[0].material.name if o.material_slots and o.material_slots[0].material else ""
        if m in KEEP_UV or m.startswith("PHMA_Decal"):
            continue
        me = o.data
        if not me.uv_layers or (len(me.polygons) < 20000 and L.pipeline.uv_area(me) > 1.02):
            while me.uv_layers:
                me.uv_layers.remove(me.uv_layers[0])
            todo.append(o)
    try:
        return L.pipeline.unwrap(todo)
    except Exception as e:
        return "unwrap failed: %s" % e


@_t
def stage_configure():
    L = addon()
    sc = main_scene()
    ctx = bpy.context
    st = L.pipeline.auto_configure(ctx, 'ALL')
    n_uv = clean_uvs(L)
    # crew-maintained interior: much less dust than vacuum-exposed hardware
    for cn in ("LSAH_Habitat_Interior", "PHMA1_Interior", "MMR_MicroRobots"):
        c = bpy.data.collections.get(cn)
        if c:
            for o in c.all_objects:
                o["lmsp_dust"] = 0.12
                o["lmsp_wear"] = min(float(o.get("lmsp_wear", 1.0)), 0.7)
    return {"assigned": st["assigned"], "fallback": st["fallback"][:60], "n_fallback": len(st["fallback"]),
            "missing": st["missing"][:20], "unwrapped": n_uv, "by_material": st["by_material"]}


@_t
def stage_anim():
    from phma_build import anim, scenes, habitat
    O = habitat.INTERIOR_O
    R = lambda n: bpy.data.objects[n]
    ext, intr = R("RIG_PHMA1_EXT"), R("RIG_PHMA1_INT")
    seam = Vector((1.0, -6.7, 3.2))
    anim.act_deploy(ext, seam)
    ready = anim.solve(ext, seam, 90, ext=0.4)
    anim.act_stow(ext, ready)
    anim.act_idle_scan(ext, seam)
    anim.act_repair_weld(ext, carriage_local=5.0)
    anim.act_repair_weld(ext, carriage_local=5.0, name="PHMA_Repair_Weld_Hero", phi0=45.0, phi1=82.0, ext=1.0)
    bp, bn = scenes.breach()
    em = anim.act_emergency(ext, 0.0, bp, bn)
    ext.animation_data.action = None
    valve = O + Vector((-6.3 + 0.62, -1.0, 1.42))
    sensor = O + Vector((-1.05, -1.3, 1.3))
    anim.act_maintenance_pump(intr, valve, sensor)
    anim.act_deploy(intr, sensor)
    intr.animation_data.action = None
    a, b = R("RIG_MMR2A"), R("RIG_MMR2B")
    anim.act_micro_pipe(a, 2.0, 1, 240, "MMR2A_PipeInspect", local=True)
    anim.act_micro_pipe(a, 2.6, 600, 800, "MMR2A_Emergency_PipeRun")
    anim.act_micro_pipe(b, 0.6, 1, 240, "MMR2B_Crawl", wheel_r=0.035, local=True)
    anim.act_micro_pipe(b, 0.5, 640, 800, "MMR2B_Emergency_Crawl", wheel_r=0.035)
    ea, eb, ec = R("RIG_EVA3_A"), R("RIG_EVA3_B"), R("RIG_EVA3_C")
    anim.act_rover_traverse_local(ea)
    anim.act_rover_doze(ea)
    anim.act_rover_clean(ec)
    anim.act_rover_path(ea, [(27.0, -7.0), (25.5, -13.5), (20.0, -15.0), (10.0, -15.2), (6.5, -15.0)], 380, 640,
                        "EVA3A_Emergency_Drive")
    anim.act_rover_path(eb, [(-26.0, -9.0), (-24.0, -14.5), (-14.0, -15.5), (-4.0, -15.5), (-1.0, -15.2)], 360, 640,
                        "EVA3B_Emergency_Drive")
    for r in (a, b, ea, eb, ec, ext, intr):
        if r.animation_data:
            r.animation_data.action = None
        anim.reset_pose(r)
    return {"actions": sorted(x.name for x in bpy.data.actions)}


@_t
def stage_scenes():
    L = addon()
    from phma_build import scenes, anim, habitat
    sc = main_scene()
    rigs = {o.name: o for o in bpy.data.objects if o.type == 'ARMATURE'}

    class _Site(dict):
        pass
    site = {"terrain": bpy.data.objects["ENV_Lunar_Terrain"], "hero_cam_xy": Vector(S["site"]["hero_cam_xy"])}
    scenes.build_emergency(sc, rigs, S["interior"], site, L)
    new = [o for o in sc.objects if o.type == 'MESH' and not any(sl.material for sl in o.material_slots)]
    L.assign.assign_materials(new)
    L.assign.apply_dust(new)
    L.assign.apply_wear(new)
    clean_uvs(L, new)
    st = anim.push_nla(rigs["RIG_EVA3_C"], bpy.data.actions["EVA3_SolarPanelClean"], 1)
    st.repeat = 6.0
    L.lighting.apply_preset(sc, 'LUNAR_NIGHT')
    sc["lmsp_led_state"] = 0.0
    L.render.apply_render_preset(sc, 'HD')
    sc.render.filepath = "//renders/emergency/LSAH_Emergency_####"
    hero, hrig = scenes.build_hero(sc, L, site, 5.0)
    bpy.context.window.scene = sc
    return {"scenes": [s.name for s in bpy.data.scenes], "markers": len(sc.timeline_markers)}


@_t
def stage_save(path=None):
    path = path or BLEND
    if bpy.data.filepath and os.path.normcase(bpy.data.filepath) != os.path.normcase(path):
        raise RuntimeError("Refusing to save: current file is %s, not the new project file" % bpy.data.filepath)
    bpy.ops.wm.save_as_mainfile(filepath=path, compress=True)
    return {"saved": path, "mb": round(os.path.getsize(path) / 1048576, 1)}


def build_all():
    log = {}
    for fn in (stage_materials, stage_habitat, stage_robots, stage_configure, stage_anim, stage_scenes, stage_save):
        log[fn.__name__] = fn()
        if not log[fn.__name__]["ok"]:
            break
    print(json.dumps(log, indent=1, default=str))
    return log
