"""Movie assembly: 'Micrometeorite at Lunar Night' emergency sequence + 'Lunar Sunrise' hero scene."""
import bpy, bmesh, math
from mathutils import Vector, Matrix
from .common import Kit, coll, parent_to_bone, align_matrix, TAU
from . import anim, habitat
from .arm import TM1

FPS = 24
SEQ_END = 1440
IMPACT_F = 90
ARM_START = 312            # PHMA_Emergency_Response NLA strip start
BEATS = [  # (marker, frame, camera)
    ("01 Impact - lunar night", 1, "CAM_E01_Establish"),
    ("02 Sensors detect damage", 120, "CAM_E02_Sensors"),
    ("03 LUNA AI identifies failure", 216, "CAM_E03_AI"),
    ("04 PHMA-1 deploys automatically", 312, "CAM_E04_ArmDeploy"),
    ("05 EVA robots converge", 528, "CAM_E05_Rovers"),
    ("06 Micro robot pipe inspection", 648, "CAM_E06_PipeRobot"),
    ("07 Crew monitoring", 792, "CAM_E07_Crew"),
    ("08 Automatic repair - laser seal", 936, "CAM_E08_Repair"),
    ("09 Repair wide", 1150, "CAM_E09_RepairWide"),
    ("10 The colony survives", 1320, "CAM_E10_Survive"),
]
BREACH_C = Vector((1.0, -4.2, 3.2))
BREACH_X = 3.0
BREACH_A = math.radians(35)


def breach():
    n = Vector((0, -math.sin(BREACH_A), math.cos(BREACH_A)))
    p = Vector((BREACH_X, BREACH_C.y, BREACH_C.z)) + n * 2.5
    return p, n


def look(cam, loc, target):
    cam.location = loc
    cam.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()


def make_cam(col, name, loc, target, lens=35.0, frame=None, env=None, clip_start=0.05):
    cd = bpy.data.cameras.new(name)
    cd.lens = lens
    cd.clip_start = clip_start
    cd.clip_end = 40000.0
    cd.sensor_width = 36.0
    ob = bpy.data.objects.new(name, cd)
    col.objects.link(ob)
    look(ob, loc, target)
    if frame is not None:
        ob["lmsp_frame"] = frame
    if env:
        ob["lmsp_env"] = env
    return ob


def key_cam(cam, f, loc, target):
    look(cam, loc, target)
    cam.keyframe_insert("location", frame=f)
    cam.keyframe_insert("rotation_euler", frame=f)


def key_vis(objs, f, visible):
    for o in objs:
        o.hide_render = not visible
        o.hide_viewport = not visible
        o.keyframe_insert("hide_render", frame=f)
        o.keyframe_insert("hide_viewport", frame=f)


def particle_source(col, name, mat, scale=(1, 1, 1), subdiv=1):
    if name in bpy.data.objects:
        return bpy.data.objects[name]
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=subdiv, radius=1.0)
    bmesh.ops.scale(bm, vec=scale, verts=bm.verts)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    me.materials.append(bpy.data.materials[mat])
    ob = bpy.data.objects.new(name, me)
    col.objects.link(ob)
    ob.location = (0, 0, -500)
    ob["lmsp_material"] = mat
    return ob


def emitter(col, name, size, loc, normal=None):
    bm = bmesh.new()
    if isinstance(size, (int, float)):
        bmesh.ops.create_icosphere(bm, subdivisions=1, radius=size)
    else:
        bmesh.ops.create_cube(bm, size=1.0)
        bmesh.ops.scale(bm, vec=size, verts=bm.verts)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(name, me)
    col.objects.link(ob)
    ob.location = loc
    if normal is not None:
        ob.rotation_euler = Vector((0, 0, 1)).rotation_difference(Vector(normal)).to_euler()
    ob.show_instancer_for_render = False
    ob.show_instancer_for_viewport = False
    ob["lmsp_preview"] = 1
    return ob


def particles(ob, name, count, f0, f1, life, inst, size, vel_n=0.0, vel_rand=0.0, gravity=1.0, emit='FACE',
              brownian=0.0, life_rand=0.3, size_rand=0.5, align_vel=False):
    mod = ob.modifiers.new(name, 'PARTICLE_SYSTEM')
    ps = ob.particle_systems[-1].settings
    ps.name = name
    ps.count = count
    ps.frame_start, ps.frame_end = f0, f1
    ps.lifetime = life
    ps.lifetime_random = life_rand
    ps.emit_from = emit
    ps.normal_factor = vel_n
    ps.factor_random = vel_rand
    ps.render_type = 'OBJECT'
    ps.instance_object = inst
    ps.particle_size = size
    ps.size_random = size_rand
    ps.brownian_factor = brownian
    ps.effector_weights.gravity = gravity
    try:
        ps.use_render_emitter = False
    except AttributeError:
        pass
    if align_vel:
        ps.use_rotations = True
        ps.rotation_mode = 'VEL'
    return ps


# =========================================================================== emergency sequence
def build_emergency(scene, rigs, interior, site, L):
    """rigs: dict name->rig object. L: add-on module (lighting/materials)."""
    cams = coll("CAM_Emergency_Sequence")
    fx = coll("FX_Emergency")
    src = coll("ENV_ParticleSources")
    scene.frame_start, scene.frame_end = 1, SEQ_END
    scene.render.fps = FPS
    scene.gravity = (0, 0, -1.62)
    bp, bn = breach()
    # ---- breach damage, patch, perimeter weld segments ------------------------------------
    k = Kit(coll("LSAH_Habitat_Exterior"), "LSAH")
    R = 0.5
    bm = bmesh.new()
    bmesh.ops.create_circle(bm, cap_ends=True, segments=48, radius=R)
    me = bpy.data.meshes.new("LSAH_Hab_Expansion_Breach_Damage")
    bm.to_mesh(me)
    bm.free()
    dmg = bpy.data.objects.new(me.name, me)
    k.col.objects.link(dmg)
    dmg.matrix_world = Matrix.Translation(BREACH_C + Vector((BREACH_X - BREACH_C.x, 0, 0)) + bn * 2.55) @ align_matrix(bn)
    dmg["lmsp_material"] = "PHMA_ImpactDamage"
    dmg["lmsp_exterior"] = 1.0
    patch = k.cyl("Hab_Expansion_Patch_Plate", 0.3, 0.012, tuple(bp + bn * 0.075), align=tuple(bn), seg=48, bevel=0.003)
    segs = []
    n_seg = 12
    t1 = Vector((1, 0, 0))
    t2 = bn.cross(t1).normalized()
    for i in range(n_seg):
        pts = []
        for j in range(5):
            a = (i + j / 4) / n_seg * TAU
            pts.append(tuple(bp + bn * 0.08 + t1 * math.cos(a) * 0.3 + t2 * math.sin(a) * 0.3))
        segs.append(k.cable("Hab_Expansion_PatchWeld%02d_Seam" % i, pts, 0.008, res=3))
    for o in [dmg, patch] + segs:
        o["lmsp_exterior"] = 1.0
    press_abs = ARM_START + 250
    weld0, weld1 = ARM_START + 640, ARM_START + 1000
    key_vis([dmg], 1, False)
    key_vis([dmg], IMPACT_F, True)
    key_vis([patch] + segs, 1, False)
    key_vis([patch], press_abs, True)
    for i, s in enumerate(segs):
        key_vis([s], int(weld0 + (weld1 - weld0) * (i + 1) / n_seg), True)
    # ---- impact flash + debris + venting --------------------------------------------------
    fl = particle_source(src, "ENV_Flash_Sphere", "PHMA_ImpactFlash")
    fl.location = bp + bn * 0.1
    fl.scale = (0.25, 0.25, 0.25)
    key_vis([fl], 1, False)
    key_vis([fl], IMPACT_F - 1, True)
    key_vis([fl], IMPACT_F + 12, False)
    em = bpy.data.materials["PHMA_ImpactFlash"].node_tree.nodes.get("Emission")
    if em:
        for f, v in ((IMPACT_F - 1, 0.0), (IMPACT_F, 1500.0), (IMPACT_F + 3, 300.0), (IMPACT_F + 10, 0.0)):
            em.inputs["Strength"].default_value = v
            em.inputs["Strength"].keyframe_insert("default_value", frame=f)
    ld = bpy.data.lights.new("LGT_Impact_Flash", 'POINT')
    ld.color = (1.0, 0.92, 0.85)
    lo = bpy.data.objects.new("LGT_Impact_Flash", ld)
    fx.objects.link(lo)
    lo.location = bp + bn * 0.4
    for f, v in ((IMPACT_F - 1, 0.0), (IMPACT_F, 1.2e4), (IMPACT_F + 3, 2.5e3), (IMPACT_F + 12, 0.0)):
        ld.energy = v
        ld.keyframe_insert("energy", frame=f)
    chunk = particle_source(src, "ENV_Debris_Particle", "PHMA_Aluminum", (1.0, 0.6, 0.15), 0)
    ice = particle_source(src, "ENV_Ice_Particle", "PHMA_PaintWhite", (1, 1, 1), 1)
    e1 = emitter(fx, "FX_Impact_Emitter", 0.05, bp + bn * 0.05)
    particles(e1, "PS_Impact_Debris", 350, IMPACT_F, IMPACT_F + 2, 260, chunk, 0.02, vel_n=6.0, vel_rand=4.0, gravity=1.0)
    e2 = emitter(fx, "FX_Vent_Emitter", 0.04, bp + bn * 0.03)
    particles(e2, "PS_Vent_IcePlume", 5000, IMPACT_F + 2, press_abs, 45, ice, 0.008, vel_n=3.5, vel_rand=0.7, gravity=0.1)
    # ---- arm: NLA strip + tool visibility --------------------------------------------------
    ext = rigs["RIG_PHMA1_EXT"]
    act = bpy.data.actions["PHMA_Emergency_Response"]
    ext.animation_data.action = None
    anim.push_nla(ext, act, ARM_START)
    grip = [o for o in bpy.data.objects if o.name.startswith("PHMA1_EXT_TL01_")]
    weld = [o for o in bpy.data.objects if o.name.startswith("PHMA1_EXT_TL02_") and not o.get("lmsp_weld_glow")]
    glow = [o for o in bpy.data.objects if o.name.startswith("PHMA1_EXT_TL02_") and o.get("lmsp_weld_glow")]
    held = [o for o in bpy.data.objects if o.name.startswith("PHMA1_EXT_Patch_")]
    tc = ARM_START + 330
    key_vis(grip, 1, True)
    key_vis(grip, tc, False)
    key_vis(weld, 1, False)
    key_vis(weld, tc, True)
    key_vis(held, 1, True)
    key_vis(held, press_abs, False)
    key_vis(glow, 1, False)
    for i, f in enumerate(range(weld0, weld1, 6)):
        key_vis(glow, f, i % 5 != 4)
    key_vis(glow, weld1, False)
    sp = bpy.data.objects.get("PHMA1_EXT_TL02_Spark_Emitter")
    spark = particle_source(src, "ENV_Spark_Particle", "PHMA_Spark", (0.15, 0.15, 1.0), 1)
    if sp:
        particles(sp, "PS_Weld_Sparks", 9000, weld0, weld1, 18, spark, 0.006, vel_n=0.0, vel_rand=2.5, gravity=1.0,
                  emit='VERT', align_vel=True)
    # ---- interior arm, micro robots, rovers ----------------------------------------------
    intr = rigs["RIG_PHMA1_INT"]
    intr.animation_data.action = None
    anim.push_nla(intr, bpy.data.actions["PHMA_Maintenance_Pump"], 100)
    for rn, an in (("RIG_MMR2A", "MMR2A_Emergency_PipeRun"), ("RIG_EVA3_A", "EVA3A_Emergency_Drive"),
                   ("RIG_EVA3_B", "EVA3B_Emergency_Drive"), ("RIG_EVA3_C", "EVA3_SolarPanelClean"),
                   ("RIG_MMR2B", "MMR2B_Emergency_Crawl")):
        r = rigs.get(rn)
        if r and an in bpy.data.actions:
            anim.assign_action(r, bpy.data.actions[an])
    # ---- fleet status LEDs + interior alarm -----------------------------------------------
    for f, v in ((1, 0.0), (IMPACT_F + 2, 3.0), (weld0, 1.0), (weld1 + 10, 0.0)):
        scene["lmsp_led_state"] = v
        scene.keyframe_insert('["lmsp_led_state"]', frame=f)
    # per-shot camera exposure: exteriors under earthshine need +2 EV, interiors are lamp-lit
    for f, ev in ((1, 1.8), (120, -0.8), (312, 1.8), (648, -0.5), (792, -0.8), (936, 1.2), (1150, 1.8), (1320, 2.0)):
        scene.view_settings.exposure = ev
        scene.view_settings.keyframe_insert("exposure", frame=f)
    try:
        for fc in anim.fcurves(scene.animation_data.action):
            for kp in fc.keyframe_points:
                kp.interpolation = 'CONSTANT'
    except Exception:
        pass
    O = habitat.INTERIOR_O
    al = bpy.data.lights.new("LGT_Interior_Alarm", 'POINT')
    al.color = (1.0, 0.08, 0.04)
    ao = bpy.data.objects.new("LGT_Interior_Alarm", al)
    coll("LSAH_Habitat_Interior").objects.link(ao)
    ao.location = O + Vector((0, 0, 3.9))
    for f in range(1, SEQ_END, 12):
        on = IMPACT_F + 2 <= f < weld0 and (f // 12) % 2 == 0
        al.energy = 900.0 if on else 0.0
        al.keyframe_insert("energy", frame=f)
    # ---- Earth lit for night (light linking: only Earth receives this sunlight) ----------
    night = coll("LGT_Night")
    sd = bpy.data.lights.new("LGT_EarthSun_NightOnly", 'SUN')
    sd.energy = 5.5
    sd.color = L.lighting.kelvin(5600)
    so = bpy.data.objects.new("LGT_EarthSun_NightOnly", sd)
    night.objects.link(so)
    ed = (bpy.data.objects["ENV_Earth"].location).normalized()
    so.rotation_euler = Vector((0, 0, 1)).rotation_difference(-ed).to_euler()
    try:
        so.light_linking.receiver_collection = bpy.data.collections["ENV_Earth"]
    except Exception:
        pass
    # ---- cameras + markers ---------------------------------------------------------------
    pipe_y, pipe_z = interior["pipe"]
    o = lambda x, y, z: O + Vector((x, y, z))
    c = {}
    c["CAM_E01_Establish"] = make_cam(cams, "CAM_E01_Establish", (24, -34, 4), (2, -4, 3.5), 24)
    key_cam(c["CAM_E01_Establish"], 1, (26, -36, 4.2), (2, -4, 3.5))
    key_cam(c["CAM_E01_Establish"], 120, (22, -31, 3.6), (3, -5, 4.2))
    c["CAM_E02_Sensors"] = make_cam(cams, "CAM_E02_Sensors", o(3.6, -0.7, 1.75), o(5.0, 1.05, 1.75), 32)
    c["CAM_E03_AI"] = make_cam(cams, "CAM_E03_AI", o(4.6, -1.0, 1.55), o(2.3, 0.7, 1.6), 22)
    key_cam(c["CAM_E03_AI"], 216, o(4.8, -1.05, 1.5), o(2.3, 0.7, 1.6))
    key_cam(c["CAM_E03_AI"], 312, o(4.3, -0.9, 1.6), o(2.2, 0.7, 1.7))
    c["CAM_E04_ArmDeploy"] = make_cam(cams, "CAM_E04_ArmDeploy", (-8, -16.5, 1.1), (-3, -10, 4), 24)
    key_cam(c["CAM_E04_ArmDeploy"], 312, (-8, -16.5, 1.1), (-3.5, -10.5, 3.5))
    key_cam(c["CAM_E04_ArmDeploy"], 372, (-7, -16.5, 1.2), (-3, -10.5, 4.5))
    key_cam(c["CAM_E04_ArmDeploy"], 468, (2, -17.0, 1.4), (bp.x, -9, 4.5))
    key_cam(c["CAM_E04_ArmDeploy"], 528, (4, -16.5, 1.8), (bp.x, -6.5, 5))
    c["CAM_E05_Rovers"] = make_cam(cams, "CAM_E05_Rovers", (19, -19, 0.7), (14, -14.5, 0.9), 30)
    key_cam(c["CAM_E05_Rovers"], 528, (19, -19.5, 0.7), (20, -14.0, 0.9))
    key_cam(c["CAM_E05_Rovers"], 648, (14, -20.0, 0.9), (8, -15, 1.2))
    rob = rigs.get("RIG_MMR2A")
    x0 = rob.location.x if rob else O.x - 6
    # tracking shot: camera rides alongside the crawler (child of its rig), outside the transparent pipe
    pc = make_cam(cams, "CAM_E06_PipeRobot", (0, 0, 0), (0, 1, 0), 32)
    c["CAM_E06_PipeRobot"] = pc
    if rob:
        pc.parent = rob
        pc.matrix_parent_inverse = Matrix.Identity(4)
        look(pc, Vector((0.42, -0.22, 0.07)), Vector((0.0, 0.06, 0.0)))
    pc.data.dof.use_dof = True
    pc.data.dof.focus_distance = 0.47
    pc.data.dof.aperture_fstop = 2.8
    c["CAM_E07_Crew"] = make_cam(cams, "CAM_E07_Crew", o(7.2, -0.9, 1.9), o(3.5, 0.5, 1.5), 18)
    c["CAM_E08_Repair"] = make_cam(cams, "CAM_E08_Repair", tuple(bp + Vector((1.6, -2.4, 0.9))), tuple(bp), 50)
    key_cam(c["CAM_E08_Repair"], 936, bp + Vector((1.7, -2.5, 0.9)), bp)
    key_cam(c["CAM_E08_Repair"], 1150, bp + Vector((1.1, -2.2, 1.3)), bp)
    c["CAM_E08_Repair"].data.dof.use_dof = True
    c["CAM_E08_Repair"].data.dof.focus_object = patch
    c["CAM_E08_Repair"].data.dof.aperture_fstop = 4.0
    c["CAM_E09_RepairWide"] = make_cam(cams, "CAM_E09_RepairWide", (12, -21, 6), (2, -6, 4.5), 32)
    c["CAM_E10_Survive"] = make_cam(cams, "CAM_E10_Survive", (-70, -34, 9), (0, -3, 4), 28)
    key_cam(c["CAM_E10_Survive"], 1320, (-62, -30, 6), (0, -3, 4))
    key_cam(c["CAM_E10_Survive"], SEQ_END, (-95, -44, 14), (0, -2, 5))
    scene.timeline_markers.clear()
    for name, f, cn in BEATS:
        m = scene.timeline_markers.new(name, frame=f)
        m.camera = c[cn]
    scene.camera = c["CAM_E01_Establish"]
    # ---- N-panel movie-production shots ----------------------------------------------------
    shots = coll("CAM_Production_Shots")
    make_cam(shots, "CAM_Habitat_Exterior", (36, -40, 12), (0, 0, 3), 24, 1, 'MOON_NOON')
    make_cam(shots, "CAM_Arm_Preview", (bp.x + 4.5, -17.5, 2.6), (bp.x - 1, -9.5, 4.5), 30, ARM_START + 250, 'MOON_SUNRISE')
    make_cam(shots, "CAM_Water_System", o(-3.0, 0.5, 1.9), o(-5.4, -1.0, 1.1), 22, 150)
    make_cam(shots, "CAM_Radiation_System", o(4.6, 0.0, 1.8), o(7.6, 0.0, 2.2), 20, 1)
    make_cam(shots, "CAM_Aquaponics", o(0.3, 0.35, 1.8), o(-1.7, -0.85, 1.6), 26, 1)
    make_cam(shots, "CAM_Colony", (62, -72, 46), (0, 0, 0), 35, 1, 'MOON_SUNRISE')
    return c


# =========================================================================== hero scene
def build_hero(main, L, site, carriage_local):
    hero = bpy.data.scenes.get("LSAH_Hero_LunarSunrise") or bpy.data.scenes.new("LSAH_Hero_LunarSunrise")
    for name in ("ENV_Environment", "LSAH_Habitat_Exterior", "LSAH_Track_System", "ENV_Earth", "EVA_ExteriorRobots",
                 "ENV_ParticleSources"):
        col = bpy.data.collections.get(name)
        if col and col.name not in hero.collection.children:
            hero.collection.children.link(col)
    # hero arm = linked duplicate of the exterior arm with its own action (girth weld)
    hcol = bpy.data.collections.get("PHMA1_Hero") or bpy.data.collections.new("PHMA1_Hero")
    if hcol.name not in hero.collection.children:
        hero.collection.children.link(hcol)
    src = bpy.data.objects["RIG_PHMA1_EXT"]
    vl = bpy.context.view_layer
    for o in vl.objects:
        o.select_set(False)
    objs = [src] + [o for o in src.children_recursive if o.name in vl.objects]
    for o in objs:
        o.hide_set(False)
        o.hide_viewport = False
        o.select_set(True)
    vl.objects.active = src
    bpy.ops.object.duplicate(linked=True)
    new = list(bpy.context.selected_objects)
    hrig = next(o for o in new if o.type == 'ARMATURE')
    hrig.name = "RIG_PHMA1_HERO"
    for o in new:
        for c in list(o.users_collection):
            c.objects.unlink(o)
        hcol.objects.link(o)
        if o is not hrig and o.animation_data:
            o.animation_data_clear()
        if o.name.startswith("PHMA1_EXT_TL01_") or o.name.startswith("PHMA1_EXT_Patch_"):
            o.hide_render = o.hide_viewport = True
        elif o.name.startswith("PHMA1_EXT_TL02_"):
            o.hide_render = o.hide_viewport = bool(o.get("lmsp_weld_glow"))
    for o in vl.objects:
        o.select_set(False)
    hrig.animation_data_clear()
    weld_act = bpy.data.actions.get("PHMA_Repair_Weld_Hero") or bpy.data.actions["PHMA_Repair_Weld"]
    anim.push_nla(hrig, weld_act, 800)
    glow = [o for o in new if o.get("lmsp_weld_glow")]
    w0, w1 = 800 + weld_act["weld_frames"][0], 800 + weld_act["weld_frames"][1]
    for o in glow:
        o.hide_render = o.hide_viewport = True
    for i, f in enumerate(range(w0, w1, 6)):
        key_vis(glow, f, i % 5 != 4)
    key_vis(glow, w1, False)
    # lights (only in this scene) + world
    lg = bpy.data.collections.get("LGT_Hero") or bpy.data.collections.new("LGT_Hero")
    if lg.name not in hero.collection.children:
        hero.collection.children.link(lg)
    sun = bpy.data.lights.new("LGT_Hero_Sun", 'SUN')
    sun.energy = 5.5
    sun.angle = math.radians(0.53)
    sun.color = L.lighting.kelvin(5600)
    so = bpy.data.objects.new("LGT_Hero_Sun", sun)
    lg.objects.link(so)
    sv = L.lighting.sun_vector(1.4, 160.0)   # polar sunrise: the Sun skims the horizon 70 deg from Earth
    so.rotation_euler = Vector((0, 0, 1)).rotation_difference(sv).to_euler()
    es = bpy.data.lights.new("LGT_Hero_Earthshine", 'SUN')
    es.energy = 0.15
    es.color = (0.55, 0.7, 1.0)
    eo = bpy.data.objects.new("LGT_Hero_Earthshine", es)
    lg.objects.link(eo)
    L.lighting.world_space(hero, 0.35, name="LMSP_World_Hero")
    # camera: 300 mm telephoto 270 m away, Earth placed exactly behind the arm
    terrain = site["terrain"]
    cxy = site["hero_cam_xy"]
    cz = habitat.terrain_height(terrain, cxy.x, cxy.y) + 0.55
    cam_loc = Vector((cxy.x, cxy.y, cz))
    hero_frame = w0 + int((w1 - w0) * 0.72)
    hero.frame_set(hero_frame)
    dg = hero.view_layers[0].depsgraph
    dg.update()
    he = hrig.evaluated_get(dg)
    pbs = he.pose.bones
    elbow = he.matrix_world @ pbs["J4_Elbow_Pitch"].head
    wrist = he.matrix_world @ pbs["J5_Wrist_Pitch"].head
    arm_pt = elbow + Vector((0, 0, 1.2))
    target = (elbow + wrist) * 0.5 + Vector((0, 0, -1.4))
    d = (arm_pt - cam_loc).normalized()
    for nm in ("ENV_Earth", "ENV_Earth_Clouds", "ENV_Earth_Atmosphere"):
        ob = bpy.data.objects.get(nm)
        if ob:
            ob.location = cam_loc + d * habitat.EARTH_DIST
    eo.rotation_euler = Vector((0, 0, 1)).rotation_difference(d).to_euler()
    cams = bpy.data.collections.get("CAM_Hero") or bpy.data.collections.new("CAM_Hero")
    if cams.name not in hero.collection.children:
        hero.collection.children.link(cams)
    hc = make_cam(cams, "CAM_Hero", tuple(cam_loc), tuple(target), 300.0, hero_frame, clip_start=1.0)
    hc.data.dof.use_dof = True
    hc.data.dof.focus_distance = (target - cam_loc).length
    hc.data.dof.aperture_fstop = 2.8
    hc.data.dof.aperture_blades = 7
    key_cam(hc, 900, cam_loc + Vector((-1.5, 0, 0)), target)
    key_cam(hc, 1340, cam_loc + Vector((1.5, 0, 0.15)), target)
    hero.camera = hc
    # alternate hero angles
    tip = he.matrix_world @ pbs["Tool_Mount"].tail
    cu = make_cam(cams, "CAM_Hero_Closeup", tuple(tip + Vector((-2.4, -2.6, 0.7))), tuple(tip), 50.0, hero_frame)
    cu.data.dof.use_dof = True
    cu.data.dof.focus_distance = Vector((-2.4, -2.6, 0.7)).length
    cu.data.dof.aperture_fstop = 4.0
    make_cam(cams, "CAM_Hero_Poster", tuple(cam_loc + Vector((0, 60, -0.6))), tuple(target), 135.0)
    # floating lunar dust in the sunlight (electrostatically lofted + kicked up by the rovers)
    dcol = bpy.data.collections.get("FX_Hero_Dust") or bpy.data.collections.new("FX_Hero_Dust")
    if dcol.name not in hero.collection.children:
        hero.collection.children.link(dcol)
    mote = particle_source(bpy.data.collections["ENV_ParticleSources"], "ENV_DustMote_Particle", "PHMA_DustMote", (1, 1, 1), 2)
    box = emitter(dcol, "FX_Hero_DustVolume", (34.0, 16.0, 9.0), (arm_pt.x, arm_pt.y + 2.0, 4.5))
    particles(box, "PS_Hero_LoftedDust", 6000, 700, 701, 3000, mote, 0.012, gravity=0.0, emit='VOLUME', brownian=0.08,
              size_rand=0.8)
    box2 = emitter(dcol, "FX_Hero_DustNear", (8.0, 6.0, 4.0), tuple(target + Vector((0, -4.0, -1.0))))
    particles(box2, "PS_Hero_NearDust", 2500, 700, 701, 3000, mote, 0.006, gravity=0.0, emit='VOLUME', brownian=0.05,
              size_rand=0.8)
    hero.frame_start, hero.frame_end = 900, 1340
    hero.frame_current = hero_frame
    hero["hero_frame"] = hero_frame
    hero.view_settings.exposure = 0.6
    hero.render.fps = FPS
    hero.gravity = (0, 0, -1.62)
    for k in ("lmsp_mission_age", "lmsp_led_state", "lmsp_dust_global", "lmsp_wear_global", "lmsp_impact_global"):
        if k in main.keys():
            hero[k] = main[k]
    L.render.apply_render_preset(hero, 'HERO')
    try:
        hero.view_settings.view_transform = 'AgX'
        hero.view_settings.look = 'AgX - Medium High Contrast'
    except Exception:
        pass
    hero.render.filepath = "//renders/hero/LSAH_Hero_####"
    return hero, hrig
