"""Lunar Smart Adaptive Habitat context for the robot fleet (brand-new geometry, no existing files used).
Exterior site at the world origin; the interior module set sits underground at SET_Interior_Origin."""
import bpy, bmesh, math, random
from mathutils import Vector, Matrix, noise
from mathutils.bvhtree import BVHTree
from .common import Kit, coll, TAU
from .fleet import merged_boxes

TRACK_Z = 0.85
EARTH_AZ, EARTH_EL, EARTH_DIST = 80.0, 1.6, 20000.0
ARM_HOME = Vector((-4.0, -11.0, TRACK_Z))          # PHMA1_EXT carriage home on the south straight
HERO_CAM = None                                    # filled by build_site
INTERIOR_O = Vector((0.0, 0.0, -40.0))


def earth_dir():
    e, a = math.radians(EARTH_EL), math.radians(EARTH_AZ)
    return Vector((math.cos(e) * math.sin(a), math.cos(e) * math.cos(a), math.sin(e)))


# ------------------------------------------------------------------ terrain
def _crater(d, R):
    x = d / R
    if x < 1.0:
        return -0.18 * R * (1 - x * x) + 0.04 * R * math.exp(-((x - 1) / 0.15) ** 2)
    return 0.04 * R * math.exp(-((x - 1) / 0.22) ** 2)


def build_terrain(col, N=260, A=70.0, B=1700.0, seed=7):
    rnd = random.Random(seed)
    craters = [(Vector((rnd.uniform(-900, 900), rnd.uniform(-900, 900), 0)), rnd.choice((6, 9, 14, 22, 35, 60, 90)))
               for _ in range(70)]
    craters = [(c, R) for c, R in craters if c.length > R + 70]
    craters += [(Vector((38, 30, 0)), 7.0), (Vector((-55, 42, 0)), 11.0), (Vector((60, -45, 0)), 5.0),
                (Vector((-40, -60, 0)), 9.0)]
    ed = earth_dir()
    ed2 = Vector((ed.x, ed.y)).normalized()
    cam2 = Vector((ARM_HOME.x, ARM_HOME.y)) - ed2 * 270.0
    arm2 = Vector((ARM_HOME.x, ARM_HOME.y))

    def f(u):
        return math.copysign(A * abs(u) + B * abs(u) ** 3, u)
    bm = bmesh.new()
    grid = []
    for j in range(N + 1):
        row = []
        for i in range(N + 1):
            x, y = f(-1 + 2 * i / N), f(-1 + 2 * j / N)
            p = Vector((x, y))
            r = p.length
            flat = min(1.0, max(0.0, (r - 45.0) / 110.0)) ** 1.5
            # keep the hero line of sight (arm -> camera) low and clear
            seg = cam2 - arm2
            t = max(0.0, min(1.0, (p - arm2).dot(seg) / seg.length_squared))
            lat = (p - (arm2 + seg * t)).length
            corridor = math.exp(-(lat / 35.0) ** 2) if t > 0 else 0.0
            # distant massifs, low saddle toward Earth
            ang = math.degrees(math.acos(max(-1, min(1, p.normalized().dot(ed2))))) if r > 1 else 180
            amp = 9.0 if ang < 22 else 9.0 + 36.0 * min(1.0, (ang - 22) / 30.0)
            hills = noise.fractal(Vector((x / 420.0, y / 420.0, 0.3)), 1.0, 2.0, 5) * amp * min(1.0, r / 900.0) ** 1.2
            undul = noise.fractal(Vector((x / 60.0, y / 60.0, 1.7)), 1.0, 2.0, 4) * 1.6
            micro = noise.fractal(Vector((x / 6.0, y / 6.0, 4.1)), 0.9, 2.0, 3) * 0.12
            z = (hills + undul) * flat * (1.0 - 0.85 * corridor) + micro * (0.3 + 0.7 * flat)
            for c, R in craters:
                d = (p - c.xy).length
                if d < R * 2.2:
                    z += _crater(d, R) * (0.4 if r < 120 else 1.0)
            row.append(bm.verts.new((x, y, z)))
        grid.append(row)
    for j in range(N):
        for i in range(N):
            f_ = bm.faces.new((grid[j][i], grid[j][i + 1], grid[j + 1][i + 1], grid[j + 1][i]))
            f_.smooth = True
    me = bpy.data.meshes.new("ENV_Lunar_Terrain")
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new("ENV_Lunar_Terrain", me)
    col.objects.link(ob)
    ob["lmsp_exterior"] = 1.0
    ob["lmsp_material"] = "PHMA_Regolith"
    return ob, cam2


_BVH = {}


def terrain_height(terrain, x, y):
    """Ray-cast down onto the terrain mesh (object space == world space)."""
    t = _BVH.get(terrain.name)
    if t is None:
        me = terrain.data
        t = BVHTree.FromPolygons([v.co.copy() for v in me.vertices], [tuple(p.vertices) for p in me.polygons])
        _BVH[terrain.name] = t
    loc, n, i, d = t.ray_cast(Vector((x, y, 500.0)), Vector((0, 0, -1)))
    return loc.z if loc is not None else 0.0


def scatter_rocks(col, terrain, n=420, seed=3):
    rnd = random.Random(seed)
    bm = bmesh.new()
    for _ in range(n):
        r = rnd.uniform(14, 120) if rnd.random() < 0.85 else rnd.uniform(2, 14)
        a = rnd.uniform(0, TAU)
        x, y = math.cos(a) * r, math.sin(a) * r
        if abs(y) < 12.5 and abs(x) < 23.5:
            continue
        s = rnd.choice((0.06, 0.1, 0.15, 0.25, 0.4)) * rnd.uniform(0.7, 1.4)
        g = bmesh.ops.create_icosphere(bm, subdivisions=2, radius=1.0)
        for v in g["verts"]:
            v.co = Vector((v.co.x * rnd.uniform(0.7, 1.3), v.co.y * rnd.uniform(0.7, 1.3), v.co.z * rnd.uniform(0.45, 0.8)))
        z = terrain_height(terrain, x, y)
        M = Matrix.Translation((x, y, z + s * 0.15)) @ Matrix.Rotation(rnd.uniform(0, TAU), 4, 'Z') @ Matrix.Scale(s, 4)
        bmesh.ops.transform(bm, matrix=M, verts=g["verts"])
    for f in bm.faces:
        f.smooth = True
    me = bpy.data.meshes.new("ENV_Rocks_Regolith")
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new("ENV_Rocks_Regolith", me)
    col.objects.link(ob)
    ob["lmsp_exterior"] = 1.0
    return ob


# ------------------------------------------------------------------ track (120 m loop, titanium rail)
def track_points(Lx=32.0, Ly=10.0, R=6.0, step=0.5):
    pts = []
    hx, hy = Lx / 2, Ly / 2
    def line(a, b):
        n = max(2, int((b - a).length / step))
        return [a + (b - a) * (i / n) for i in range(n)]
    def arc(c, a0):
        n = int(R * math.pi / 2 / step)
        return [c + Vector((math.cos(a0 + i / n * math.pi / 2) * R, math.sin(a0 + i / n * math.pi / 2) * R, 0)) for i in range(n)]
    pts += line(Vector((-hx, -hy - R, 0)), Vector((hx, -hy - R, 0)))
    pts += arc(Vector((hx, -hy, 0)), -math.pi / 2)
    pts += line(Vector((hx + R, -hy, 0)), Vector((hx + R, hy, 0)))
    pts += arc(Vector((hx, hy, 0)), 0.0)
    pts += line(Vector((hx, hy + R, 0)), Vector((-hx, hy + R, 0)))
    pts += arc(Vector((-hx, hy, 0)), math.pi / 2)
    pts += line(Vector((-hx - R, hy, 0)), Vector((-hx - R, -hy, 0)))
    pts += arc(Vector((-hx, -hy, 0)), math.pi)
    return pts


def _profile_segment(name, col, L, section, cuts=8, y_offsets=(0.0,)):
    """Extrude a list of (y,z) rectangles along X. section: list of (y0,y1,z0,z1)."""
    bm = bmesh.new()
    for yo in y_offsets:
        for (y0, y1, z0, z1) in section:
            g = bmesh.ops.create_cube(bm, size=1.0)
            bmesh.ops.scale(bm, vec=(L, y1 - y0, z1 - z0), verts=g["verts"])
            bmesh.ops.translate(bm, vec=(L / 2, yo + (y0 + y1) / 2, (z0 + z1) / 2), verts=g["verts"])
    edges = [e for e in bm.edges if abs(e.verts[0].co.x - e.verts[1].co.x) > L * 0.5]
    bmesh.ops.subdivide_edges(bm, edges=edges, cuts=cuts, use_grid_fill=True)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(name, me)
    col.objects.link(ob)
    return ob


def _along(ob, path, spacing=None, merge=True):
    a = ob.modifiers.new("Array", 'ARRAY')
    a.fit_type = 'FIT_CURVE'
    a.curve = path
    if spacing:
        a.use_relative_offset = False
        a.use_constant_offset = True
        a.constant_offset_displace = (spacing, 0, 0)
    a.use_merge_vertices = merge
    c = ob.modifiers.new("Curve", 'CURVE')
    c.object = path
    c.deform_axis = 'POS_X'
    ob["lmsp_exterior"] = 1.0


def build_track(col, terrain):
    pts = track_points()
    cu = bpy.data.curves.new("LSAH_Track_Path", 'CURVE')
    cu.dimensions = '3D'
    sp = cu.splines.new('POLY')
    sp.points.add(len(pts) - 1)
    for p, v in zip(sp.points, pts):
        p.co = (v.x, v.y, TRACK_Z, 1.0)
    sp.use_cyclic_u = True
    path = bpy.data.objects.new("LSAH_Track_Path", cu)
    col.objects.link(path)
    path.hide_render = True
    length = sum((pts[(i + 1) % len(pts)] - pts[i]).length for i in range(len(pts)))
    path["track_length_m"] = round(length, 1)
    # rail: head 70x60 mm, web 22x200 mm, foot 130x30 mm, 0.75 m gauge
    rail = [(-0.035, 0.035, -0.06, 0.0), (-0.011, 0.011, -0.26, -0.06), (-0.065, 0.065, -0.29, -0.26)]
    r = _profile_segment("LSAH_Track_Rails_Track", col, 2.0, rail, 8, (-0.375, 0.375))
    _along(r, path)
    ties = _profile_segment("LSAH_Track_Ties_Tie", col, 0.14, [(-0.62, 0.62, -0.37, -0.29)], 1)
    _along(ties, path, spacing=1.0, merge=False)
    bus = _profile_segment("LSAH_Track_Busbar_Copper", col, 2.0, [(0.6, 0.64, -0.08, -0.04)], 8)
    _along(bus, path)
    ins = _profile_segment("LSAH_Track_Busbar_Insulators", col, 0.05, [(0.6, 0.64, -0.29, -0.08), (0.58, 0.66, -0.33, -0.29)], 1)
    _along(ins, path, spacing=1.0, merge=False)
    cover = _profile_segment("LSAH_Track_Busbar_Cover", col, 2.0, [(0.57, 0.67, -0.035, -0.025), (0.665, 0.675, -0.1, -0.025)], 8)
    _along(cover, path)
    pyl = _profile_segment("LSAH_Track_Pylon_Strut", col, 0.18, [(-0.09, 0.09, -TRACK_Z - 0.4, -0.37)], 1)
    _along(pyl, path, spacing=4.0, merge=False)
    pad = _profile_segment("LSAH_Track_Footing_Block", col, 0.7, [(-0.35, 0.35, -TRACK_Z - 0.45, -TRACK_Z + 0.05)], 1)
    _along(pad, path, spacing=4.0, merge=False)
    enc = _profile_segment("LSAH_Track_EncoderStrip_Hazard", col, 2.0, [(-0.4, -0.385, -0.2, -0.16)], 8)
    _along(enc, path)
    return path, length


# ------------------------------------------------------------------ modules & infrastructure
def _module(k, name, center, length, radius, axis='X', end_caps=True, mat="Hull"):
    c = Vector(center)
    prof = [(radius * 0.92, -length / 2 - 0.25), (radius, -length / 2), (radius, length / 2), (radius * 0.92, length / 2 + 0.25)]
    ob = k.lathe("%s_%s" % (name, mat), prof, 64, loc=tuple(c), axis=axis, cap=True)
    for z in [-length / 2 + i * length / 6 for i in range(7)]:
        off = {'X': Vector((z, 0, 0)), 'Y': Vector((0, z, 0)), 'Z': Vector((0, 0, z))}[axis]
        k.ring("%s_Rib%d_Ring" % (name, int((z + length) * 10)), radius + 0.05, radius - 0.01, 0.12, tuple(c + off), axis=axis, seg=64)
    return ob


def build_site(parent_coll=None):
    col = coll("LSAH_Habitat_Exterior", parent_coll)
    env = coll("ENV_Environment", parent_coll)
    terrain, cam2 = build_terrain(env)
    scatter_rocks(env, terrain)
    tcol = coll("LSAH_Track_System", parent_coll)
    path, length = build_track(tcol, terrain)
    k = Kit(col, "LSAH")
    # modules: core (north), expansion under construction (south), node + airlock (west)
    _module(k, "Hab_Core", (2.0, 4.0, 3.4), 16.0, 3.0)
    exp = _module(k, "Hab_Expansion", (1.0, -4.2, 3.2), 12.0, 2.5)
    k.lathe("Hab_Node_Module", [(2.1, -5.0), (2.3, -4.8), (2.3, 4.8), (2.1, 5.0)], 64, loc=(-9.0, 0.0, 3.4), axis='Y')
    for y, nm in ((4.0, "Core"), (-4.2, "Expansion")):
        k.cyl("Hab_%sBerth_Adapter_Hull" % nm, 1.15, 1.7, (-6.15, y, 3.4 if nm == "Core" else 3.2), axis='X', seg=48)
        k.ring("Hab_%sBerth_Flange_Ring" % nm, 1.32, 1.12, 0.12, (-5.3, y, 3.4 if nm == "Core" else 3.2), axis='X', seg=64)
    for nm, x, y, h in (("Core", 2.0, 4.0, 3.4), ("Expansion", 1.0, -4.2, 3.2), ("Node", -9.0, 0.0, 3.4)):
        for i, dx in enumerate((-5.0, 0.0, 5.0) if nm != "Node" else (0.0,)):
            for s in (-1, 1):
                k.cyl("Hab_%s_Leg%d%s_Strut" % (nm, i, "L" if s < 0 else "R"), 0.12, h - 0.4, (x + dx, y + s * 1.8, 0.0),
                      base=True, seg=16)
                k.cyl("Hab_%s_Foot%d%s_Plate" % (nm, i, "L" if s < 0 else "R"), 0.45, 0.06, (x + dx, y + s * 1.8, 0.0), seg=24)
    # MMOD / thermal outfitting being installed on the expansion module
    k.lathe("Hab_Expansion_MMOD_BetaCloth", [(2.56, -4.5), (2.56, -0.5)], 64, loc=(1.0, -4.2, 3.2), axis='X',
            a0=0.3, a1=3.4, cap=False, solid=0.03)
    k.lathe("Hab_Expansion_Outfit_MLI", [(2.53, 0.6), (2.53, 3.0)], 64, loc=(1.0, -4.2, 3.2), axis='X', a0=0.6, a1=2.8,
            cap=False, solid=0.015)
    k.box("Hab_Expansion_Window_Frame", (0.7, 0.2, 0.7), (4.5, -6.6, 3.6), bevel=0.04)
    k.cyl("Hab_Expansion_Window_Glass", 0.28, 0.05, (4.5, -6.72, 3.6), axis='Y', seg=40)
    # weld seam at the berthing flange (the PHMA-1 repair target)
    sp = [(-5.24, -4.2 + math.cos(a) * 1.17, 3.2 + math.sin(a) * 1.17) for a in [i / 48 * TAU for i in range(49)]]
    seam = k.cable("Hab_Expansion_Berth_Weld_Seam", sp, 0.012, res=4)
    gp = [(1.0, -4.2 + math.cos(a) * 2.515, 3.2 + math.sin(a) * 2.515) for a in [i / 96 * TAU for i in range(97)]]
    k.cable("Hab_Expansion_Girth_Weld_Seam", gp, 0.016, res=4)
    k.ring("Hab_Expansion_GirthLand_Ring", 2.53, 2.49, 0.09, (1.0, -4.2, 3.2), axis='X', seg=96)
    # radiation shielding: printed regolith block arches over the core module
    items = []
    for i in range(26):
        x = -5.6 + i * 0.6
        for j in range(21):
            if 11 <= i <= 13 and 4 <= j <= 6:
                continue     # missing/damaged blocks: inspection target
            a = math.pi * (j + 0.5) / 21
            M = (Matrix.Translation((x, 4.0 + math.cos(a) * 3.65, 3.4 + math.sin(a) * 3.65)) @ Matrix.Rotation(a - math.pi / 2, 4, 'X'))
            items.append(((0.56, 0.5, 0.55), M))
    merged_boxes(k, "Shield_Regolith_Blocks", items, bevel=0.03)
    # airlock + suitports + dust mitigation
    k.cyl("Airlock_Module_Hull", 1.3, 3.0, (-12.8, 0.0, 3.0), axis='X', seg=48)
    k.lathe("Airlock_Hatch_Paint", [(0.0, 0.0), (0.75, 0.0), (0.8, 0.05), (0.8, 0.12), (0.0, 0.12)], 40,
            loc=(-14.32, 0.0, 2.7), align=(-1, 0, 0))
    k.box("Airlock_Porch_Deck", (2.2, 2.6, 0.12), (-15.4, 0.0, 1.6), bevel=0.02)
    k.box("Airlock_EDS_Grid_Copper", (2.0, 2.2, 0.01), (-15.4, 0.0, 1.665), bevel=0.0)
    for s in (-1, 1):
        k.ring("Airlock_Suitport%s_Ring" % ("L" if s < 0 else "R"), 0.42, 0.34, 0.12, (-12.2, s * 1.28, 3.0), axis='Y', seg=40)
        k.cable("Airlock_%s_Handrail" % ("L" if s < 0 else "R"), [(-16.4, s * 1.2, 1.7), (-16.4, s * 1.2, 2.7),
                                                                    (-14.5, s * 1.2, 2.7), (-14.4, s * 1.1, 2.4)], 0.025)
    k.box("Airlock_Steps_Frame", (1.2, 1.6, 0.06), (-17.0, 0.0, 0.85), rotx=0.0, roty=0.5, bevel=0.01)
    # PHMA dock: self-cleaning parking station over the west straight (x = -22)
    for y in (-2.6, 2.6):
        for x in (-23.9, -20.1):
            k.cyl("Dock_Column_Strut", 0.12, 4.4, (x, y, 0.0), base=True, seg=16)
    k.box("Dock_Roof_Panel", (4.2, 5.6, 0.12), (-22.0, 0.0, 4.45), bevel=0.02)
    k.box("Dock_Roof_Radiator_OSR", (3.6, 4.8, 0.02), (-22.0, 0.0, 4.52), bevel=0.0)
    for x in (-23.9, -20.1):
        k.box("Dock_EDS_Curtain_Glass", (0.02, 5.0, 3.0), (x, 0.0, 2.6), bevel=0.0)
        k.box("Dock_Brush%s_Pad" % ("W" if x < -22 else "E"), (0.12, 4.6, 0.12), (x + (0.2 if x < -22 else -0.2), 0.0, 1.0), bevel=0.02)
    k.box("Dock_ChargeCoupler_Electronics", (0.4, 0.3, 0.6), (-20.4, 2.2, 1.3), bevel=0.02)
    k.box("Dock_Status_Screen", (0.01, 0.5, 0.3), (-20.18, 2.2, 1.9), bevel=0.0)
    k.box("Dock_Beacon_LED", (0.2, 0.2, 0.06), (-22.0, 0.0, 4.36), bevel=0.0)
    k.box("Dock_ToolTable_Frame", (6.0, 0.9, 0.08), (-27.9, 2.5, 0.85), bevel=0.01)
    for x in (-30.7, -25.1):
        for y in (2.1, 2.9):
            k.cyl("Dock_ToolTable_Leg_Strut", 0.04, 0.85, (x, y, 0.0), base=True, seg=10)
    # solar: three vertical sun-tracking arrays (polar sun is near the horizon) + a low array field
    for i, (x, y) in enumerate(((-38.0, 15.0), (-27.0, 22.0), (-15.0, 26.0))):
        k.cyl("Solar%d_Mast_Strut" % i, 0.22, 14.0, (x, y, 0.0), base=True, seg=20)
        k.box("Solar%d_Wing_Cells" % i, (0.05, 3.0, 9.0), (x + 0.3, y, 9.0), rotz=math.radians(-18), bevel=0.0)
        k.box("Solar%d_Wing_Frame" % i, (0.08, 3.1, 0.1), (x + 0.3, y, 13.55), rotz=math.radians(-18), bevel=0.0)
        k.cyl("Solar%d_Gimbal_Drive" % i, 0.35, 0.5, (x, y, 14.0), seg=24)
        k.box("Solar%d_Base_Block" % i, (1.4, 1.4, 0.4), (x, y, 0.2), bevel=0.04)
    for r in range(2):
        for c in range(4):
            k.box("SolarField_R%dC%d_Cells" % (r, c), (0.04, 2.0, 1.4), (27.0 + r * 4.0, -4.0 + c * 2.2, 1.25),
                  roty=math.radians(-20), bevel=0.0)
            k.cyl("SolarField_R%dC%d_Leg_Strut" % (r, c), 0.05, 0.6, (27.0 + r * 4.0, -4.0 + c * 2.2, 0.0), base=True, seg=10)
    for i, (x, y) in enumerate(((12.5, 7.5), (12.5, 0.5))):
        k.box("Radiator%d_Panel_OSR" % i, (0.06, 4.5, 3.2), (x, y, 3.0), bevel=0.0)
        k.cyl("Radiator%d_Mast_Strut" % i, 0.08, 1.5, (x, y, 0.0), base=True, seg=12)
    k.cyl("Comms_Mast_Strut", 0.15, 8.0, (14.0, 14.5, 0.0), base=True, seg=16)
    ed = earth_dir()
    k.lathe("Comms_Dish_Aluminum", [(0.0, 0.0), (0.6, 0.12), (1.2, 0.45), (1.25, 0.5), (0.0, 0.08)], 48,
            loc=(14.0, 14.5, 8.3), align=tuple(ed))
    lights = []
    for i, (x, y, tx, ty) in enumerate(((-13.0, -17.0, -4.0, -5.0), (16.0, -16.0, 4.0, -4.0), (-16.0, 13.0, -3.0, 2.0),
                                         (18.0, 14.0, 5.0, 4.0))):
        k.cyl("FloodMast%d_Strut" % i, 0.1, 7.0, (x, y, 0.0), base=True, seg=12)
        k.box("FloodMast%d_Housing" % i, (0.6, 0.3, 0.35), (x, y, 7.1), bevel=0.03)
        k.box("FloodMast%d_Emitter" % i, (0.5, 0.02, 0.25), (x, y + (0.16 if ty > y else -0.16), 7.1), bevel=0.0)
        d = Vector((tx - x, ty - y, 3.0 - 7.1))
        lights.append(k.light("FloodMast%d_Spot" % i, 'SPOT', 700, (1.0, 0.95, 0.88), (x, y, 7.0), d, math.radians(55), 0.3))
    # cargo pallet with grapple fixture (TL08 target)
    k.box("Cargo_Pallet_Frame", (2.2, 1.4, 0.15), (9.0, -16.0, 0.1), bevel=0.02)
    for i, (dx, dy, h) in enumerate(((-0.5, 0.0, 0.9), (0.55, -0.2, 0.7), (0.55, 0.35, 0.5))):
        k.box("Cargo_Container%d_BetaCloth" % i, (0.95, 0.9, h), (9.0 + dx, -16.0 + dy, 0.18 + h / 2), bevel=0.04)
    k.cyl("Cargo_GrappleFixture_Titanium", 0.05, 0.3, (8.5, -16.0, 1.08), base=True, seg=20)
    k.lathe("Cargo_GrappleFixture_Plate", [(0.0, 1.06), (0.22, 1.06), (0.22, 1.09), (0.0, 1.09)], 32, loc=(8.5, -16.0, 0))
    for ob in k.all:
        ob["lmsp_exterior"] = 1.0
    # Earth (true angular size ~1.9 deg) + clouds + atmosphere
    ecol = coll("ENV_Earth", parent_coll)
    ek = Kit(ecol, "ENV")
    ep = ed * EARTH_DIST
    R = EARTH_DIST * math.tan(math.radians(0.95))
    bmesh_sphere(ek, "Earth", R, ep)
    bmesh_sphere(ek, "Earth_Clouds", R * 1.004, ep)
    bmesh_sphere(ek, "Earth_Atmosphere", R * 1.025, ep)
    bpy.data.objects["ENV_Earth"].rotation_euler = (math.radians(23.4), 0, math.radians(40))
    return {"terrain": terrain, "path": path, "track_length": length, "hero_cam_xy": cam2, "flood_lights": lights,
            "seam": seam, "expansion": exp, "kit": k}


def bmesh_sphere(k, name, R, center):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=96, v_segments=48, radius=R)
    for f in bm.faces:
        f.smooth = True
    full = "%s_%s" % (k.prefix, name)
    me = bpy.data.meshes.new(full)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(full, me)
    k.col.objects.link(ob)
    ob.location = center
    ob.visible_shadow = False
    k.all.append(ob)
    return ob


# ------------------------------------------------------------------ interior module set
def build_interior(parent_coll=None):
    O = INTERIOR_O
    col = coll("LSAH_Habitat_Interior", parent_coll)
    emp = bpy.data.objects.new("SET_Interior_Origin", None)
    col.objects.link(emp)
    emp.location = O
    k = Kit(col, "SET")
    zc = O.z + 2.2
    o = lambda x, y, z: (O.x + x, O.y + y, O.z + z)
    k.lathe("Interior_Hull_Liner", [(2.2, -8.0), (2.2, 8.0)], 64, loc=o(0, 0, 2.2), axis='X', cap=False, solid=0.06)
    for s in (-1, 1):
        k.cyl("Interior_EndBulkhead%s_Wall" % ("W" if s < 0 else "E"), 2.25, 0.08, o(s * 8.0, 0, 2.2), axis='X', seg=64)
        k.lathe("Interior_Hatch%s_Frame" % ("W" if s < 0 else "E"), [(0.55, 0.0), (0.65, 0.0), (0.65, 0.1), (0.55, 0.1)], 40,
                loc=o(s * 7.95, 0, 1.6), align=(-s, 0, 0), cap=False)
    k.box("Interior_Floor", (16.0, 3.0, 0.08), o(0, 0, 0.6), bevel=0.01)
    for i in range(8):
        x = -7.0 + i * 2.0
        k.ring("Interior_Rib%d_Ring" % i, 2.2, 2.1, 0.08, o(x, 0, 2.2), axis='X', seg=64)
        k.box("Interior_Ceiling%d_LightPanel" % i, (1.2, 0.6, 0.03), o(x + 1.0, -1.0, 3.95), rotx=math.radians(-25), bevel=0.0)
        k.box("Interior_CeilingB%d_LightPanel" % i, (1.2, 0.6, 0.03), o(x + 1.0, 1.0, 3.95), rotx=math.radians(25), bevel=0.0)
        k.light("Interior_Lamp%d" % i, 'AREA', 120, (1.0, 0.96, 0.9), o(x + 1.0, 0.0, 3.8), (0, 0, -1), size=0.8)
    # ceiling rail for PHMA1_INT (same titanium rail profile, 14 m)
    for y in (-0.375 * 0.4, 0.375 * 0.4):
        k.box("Interior_CeilingRail_Track", (14.0, 0.03, 0.03), o(0, y, 4.12), bevel=0.002)
    k.box("Interior_CeilingRail_Mount_Bracket", (14.0, 0.4, 0.04), o(0, 0, 4.2), bevel=0.004)
    # --- WATER PUMPING CENTER (x -7..-3.5, south side)
    k.box("Water_PumpSkid_Frame", (2.8, 0.9, 0.12), o(-5.4, -1.0, 0.7), bevel=0.02)
    for i, x in enumerate((-6.3, -4.6)):
        k.lathe("Water_Pump%d_Motor" % i, [(0.0, 0.0), (0.18, 0.0), (0.2, 0.03), (0.2, 0.45), (0.15, 0.5), (0.0, 0.5)], 40,
                loc=o(x, -1.0, 0.95), axis='X')
        k.lathe("Water_Pump%d_Volute_Pump" % i, [(0.0, -0.12), (0.24, -0.12), (0.26, -0.08), (0.26, 0.08), (0.24, 0.12),
                                                  (0.0, 0.12)], 40, loc=o(x + 0.62, -1.0, 0.95), axis='X')
        k.box("Water_Pump%d_StatusLED" % i, (0.06, 0.01, 0.02), o(x + 0.25, -1.21, 1.18), bevel=0.0)
        k.torus("Water_Pump%d_Valve" % i, 0.11, 0.015, o(x + 0.62, -1.0, 1.42), seg=32, rseg=8)
        k.cyl("Water_Pump%d_Riser_Valve" % i, 0.05, 0.36, o(x + 0.62, -1.0, 1.08), base=True, seg=20)
    k.cyl("Water_Header_Manifold", 0.08, 3.0, o(-5.4, -1.0, 1.45), axis='X', seg=32)
    k.box("Water_FlowMeter_Display", (0.2, 0.01, 0.12), o(-5.4, -1.46, 1.2), bevel=0.0)
    k.box("Water_Control_Screen", (0.5, 0.01, 0.3), o(-3.9, -1.58, 1.6), bevel=0.0)
    # transparent water pipes along the north wall (micro robot route) with water inside
    pipe_y, pipe_z = 1.25, 1.55
    k.ring("Water_MainPipe_Glass", 0.14, 0.124, 13.0, o(-0.5, pipe_y, pipe_z), axis='X', seg=64)
    k.cyl("Water_MainPipe_Water", 0.1235, 12.98, o(-0.5, pipe_y, pipe_z), axis='X', seg=64)
    for i, x in enumerate([-6.5 + j * 2.5 for j in range(6)]):
        k.ring("Water_PipeFlange%d_Ring" % i, 0.19, 0.14, 0.05, o(x, pipe_y, pipe_z), axis='X', seg=48)
        k.box("Water_PipeHanger%d_Bracket" % i, (0.05, 0.08, 0.6), o(x, pipe_y + 0.12, pipe_z + 0.4), bevel=0.004)
    k.ring("Water_ReturnPipe_Glass", 0.07, 0.062, 13.0, o(-0.5, pipe_y - 0.05, pipe_z - 0.38), axis='X', seg=40)
    k.cyl("Water_ReturnPipe_Water", 0.0615, 12.98, o(-0.5, pipe_y - 0.05, pipe_z - 0.38), axis='X', seg=40)
    # --- AQUAPONICS (x -3.2..0.2, south)
    k.ring("Aqua_FishTank_Acrylic", 0.62, 0.6, 1.1, o(-1.7, -0.85, 1.19), seg=64)
    k.cyl("Aqua_FishTank_Base_Plate", 0.64, 0.05, o(-1.7, -0.85, 0.64), base=True, seg=64)
    k.cyl("Aqua_FishTank_Water", 0.598, 0.95, o(-1.7, -0.85, 0.69), base=True, seg=64)
    k.ring("Aqua_FishTank_Rim_Ring", 0.64, 0.6, 0.04, o(-1.7, -0.85, 1.74), seg=64)
    k.box("Aqua_GrowBed_Frame", (1.4, 0.8, 0.18), o(-1.7, -0.85, 2.15), bevel=0.02)
    k.box("Aqua_Sensor_Box", (0.15, 0.08, 0.1), o(-1.05, -1.3, 1.3), bevel=0.01)
    k.box("Aqua_Quality_Display", (0.12, 0.005, 0.07), o(-1.05, -1.342, 1.32), bevel=0.0)
    rnd = random.Random(11)
    leaves = []
    for i in range(70):
        M = (Matrix.Translation(o(-1.7 + rnd.uniform(-0.6, 0.6), -0.85 + rnd.uniform(-0.33, 0.33), 2.3 + rnd.uniform(0, 0.25)))
             @ Matrix.Rotation(rnd.uniform(0, TAU), 4, 'Z') @ Matrix.Rotation(rnd.uniform(0.3, 1.1), 4, 'X'))
        leaves.append(((0.06, 0.12, 0.004), M))
    merged_boxes(k, "Aqua_Crop_Leaves", leaves)
    fish = []
    for i in range(9):
        M = Matrix.Translation(o(-1.7 + rnd.uniform(-0.4, 0.4), -0.85 + rnd.uniform(-0.4, 0.4), 0.9 + rnd.uniform(0, 0.5))) @ \
            Matrix.Rotation(rnd.uniform(0, TAU), 4, 'Z')
        fish.append(((0.16, 0.04, 0.06), M))
    merged_boxes(k, "Aqua_Tilapia_Aluminum", fish, bevel=0.015)
    # --- HYDROPONICS racks (x 0.5..4, south)
    for r in range(2):
        x = 1.2 + r * 1.7
        for t in range(3):
            z = 0.85 + t * 0.65
            k.box("Hydro_Rack%d_Shelf%d_Aluminum" % (r, t), (1.5, 0.6, 0.05), o(x, -1.05, z), bevel=0.006)
            k.box("Hydro_Rack%d_Light%d_GrowLight" % (r, t), (1.4, 0.12, 0.02), o(x, -1.05, z + 0.55), bevel=0.0)
            lv = []
            for i in range(18):
                M = (Matrix.Translation(o(x + rnd.uniform(-0.65, 0.65), -1.05 + rnd.uniform(-0.25, 0.25), z + 0.05 + rnd.uniform(0, 0.2)))
                     @ Matrix.Rotation(rnd.uniform(0, TAU), 4, 'Z') @ Matrix.Rotation(rnd.uniform(0.2, 1.0), 4, 'X'))
                lv.append(((0.05, 0.1, 0.004), M))
            merged_boxes(k, "Hydro_Rack%d_Tier%d_Plants" % (r, t), lv)
        for dx in (-0.73, 0.73):
            k.box("Hydro_Rack%d_Post_Strut" % r, (0.04, 0.04, 2.0), o(x + dx, -1.05, 1.7), bevel=0.0)
        k.cable("Hydro_Rack%d_Nutrient_Hose" % r, [o(x - 0.7, -0.75, 0.9), o(x - 0.7, -0.7, 1.6), o(x - 0.7, -0.75, 2.2)], 0.012)
        k.light("Hydro_Rack%d_Glow" % r, 'AREA', 60, (1.0, 0.3, 0.8), o(x, -1.05, 2.3), (0, 0, -1), size=1.4)
    # --- AI SERVERS + CREW MONITORING (north side x 0.5..4)
    k.box("AI_Server_Rack_Anodized", (1.6, 0.7, 1.9), o(2.3, 1.0, 1.6), bevel=0.02)
    blades = [((1.5, 0.02, 0.08), Matrix.Translation(o(2.3, 0.64, 0.9 + i * 0.11))) for i in range(15)]
    merged_boxes(k, "AI_Server_Blades_Electronics", blades)
    k.box("AI_Server_StatusLED", (0.02, 0.01, 1.6), o(1.55, 0.635, 1.6), bevel=0.0)
    k.box("AI_Server_StatusLED_B", (0.02, 0.01, 1.6), o(3.05, 0.635, 1.6), bevel=0.0)
    k.box("Crew_Console_Frame", (1.2, 0.6, 0.08), o(5.0, 0.8, 1.35), bevel=0.02)
    for i, dx in enumerate((-0.38, 0.38)):
        k.box("Crew_Console%d_Screen" % i, (0.6, 0.02, 0.36), o(5.0 + dx, 1.05, 1.75), rotx=math.radians(-12), bevel=0.0)
    k.box("Crew_Chair_Frame", (0.5, 0.5, 0.08), o(5.0, 0.2, 1.05), bevel=0.03)
    for i, x in enumerate((-6.0, -1.0, 4.0)):
        k.box("Crew_LUNA%d_Sensor_Housing" % i, (0.14, 0.06, 0.1), o(x, 0.0, 4.25), bevel=0.01)
        k.cyl("Crew_LUNA%d_Lens" % i, 0.02, 0.01, o(x, 0.0, 4.195), seg=24)
        k.box("Crew_LUNA%d_StatusLED" % i, (0.06, 0.005, 0.01), o(x + 0.03, -0.031, 4.25), bevel=0.0)
    # --- MEDICAL (south x 4.5..6)
    k.box("Med_Bed_Frame", (1.9, 0.8, 0.12), o(5.3, -1.0, 1.1), bevel=0.02)
    k.box("Med_Bed_Mattress_Paint", (1.85, 0.75, 0.1), o(5.3, -1.0, 1.21), bevel=0.04)
    k.cyl("Med_Monitor_Arm_Strut", 0.02, 1.2, o(6.2, -1.3, 1.1), base=True, seg=10)
    k.box("Med_Monitor_Screen", (0.4, 0.02, 0.28), o(6.0, -1.25, 2.2), rotz=math.radians(25), bevel=0.0)
    k.box("Med_Ultrasound_Electronics", (0.4, 0.4, 0.6), o(4.1, -1.15, 0.95), bevel=0.02)
    # --- RADIATION STORM SHELTER: water-wall panels (x 6.2..7.9 both sides)
    for s in (-1, 1):
        for j in range(4):
            a = (-0.55 + j * 0.37) * (1 if s > 0 else 1)
            y = s * 2.0 * math.cos(a)
            z = 2.2 + 2.0 * math.sin(a)
            k.box("RadShield_Panel%s%d_WaterShield" % ("N" if s > 0 else "S", j), (1.6, 0.14, 0.7),
                  o(7.0, y, z), rotx=(a if s > 0 else -a), bevel=0.03)
    k.box("RadShield_Dosimeter_Display", (0.2, 0.01, 0.12), o(6.4, -1.5, 1.6), bevel=0.0)
    for ob in k.all:
        ob["lmsp_exterior"] = 0.0
    return {"origin": O, "pipe": (pipe_y, pipe_z), "kit": k}
