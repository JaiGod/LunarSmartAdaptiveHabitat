"""PHMA fleet builder - shared part factory. Every part is its own named object so the
Lunar Material Studio Pro auto-assigner can read its material from the name suffix."""
import bpy, bmesh, math
from mathutils import Vector, Matrix

TAU = math.tau


def coll(name, parent=None):
    c = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    p = parent or bpy.context.scene.collection
    if c.name not in p.children:
        p.children.link(c)
    return c


def align_matrix(direction):
    d = Vector(direction).normalized()
    return Vector((0, 0, 1)).rotation_difference(d).to_matrix().to_4x4()


AXIS = {'Z': Matrix.Identity(4), 'X': Matrix.Rotation(math.pi / 2, 4, 'Y'), 'Y': Matrix.Rotation(-math.pi / 2, 4, 'X')}


class Kit:
    def __init__(self, collection, prefix, bevel_scale=1.0):
        self.col = collection
        self.prefix = prefix
        self.bone = None
        self.parts = {}
        self.all = []
        self.bevel_scale = bevel_scale

    # ---------------------------------------------------------------- core
    def _obj(self, name, bm, M, bevel=None, props=None, solid=None):
        full = "%s_%s" % (self.prefix, name) if self.prefix else name
        bmesh.ops.transform(bm, matrix=M, verts=bm.verts)
        me = bpy.data.meshes.new(full)
        bm.to_mesh(me)
        bm.free()
        ob = bpy.data.objects.new(full, me)
        self.col.objects.link(ob)
        if bevel:
            m = ob.modifiers.new("Bevel", 'BEVEL')
            m.width = bevel * self.bevel_scale
            m.segments = 2
            m.limit_method = 'ANGLE'
            m.angle_limit = math.radians(40)
            m.harden_normals = True
            try:
                m.miter_outer = 'MITER_ARC'
            except Exception:
                pass
        if solid:
            s = ob.modifiers.new("Solidify", 'SOLIDIFY')
            s.thickness = solid
            s.offset = 1.0
        for k, v in (props or {}).items():
            ob[k] = v
        self.parts.setdefault(self.bone, []).append(ob)
        self.all.append(ob)
        return ob

    @staticmethod
    def _place(loc=(0, 0, 0), axis='Z', align=None):
        R = align_matrix(align) if align is not None else AXIS[axis]
        return Matrix.Translation(loc) @ R

    # ---------------------------------------------------------------- primitives
    def cyl(self, name, r, h, loc=(0, 0, 0), axis='Z', align=None, seg=32, r2=None, base=False, bevel=None, props=None):
        bm = bmesh.new()
        bmesh.ops.create_cone(bm, cap_ends=True, segments=seg, radius1=r, radius2=r if r2 is None else r2, depth=h)
        if base:
            bmesh.ops.translate(bm, vec=(0, 0, h / 2), verts=bm.verts)
        for f in bm.faces:
            f.smooth = abs(f.normal.z) < 0.95
        return self._obj(name, bm, self._place(loc, axis, align), bevel=bevel, props=props)

    def box(self, name, size, loc=(0, 0, 0), bevel=0.008, rotz=0.0, rotx=0.0, roty=0.0, props=None):
        bm = bmesh.new()
        bmesh.ops.create_cube(bm, size=1.0)
        bmesh.ops.scale(bm, vec=size, verts=bm.verts)
        uvl = bm.loops.layers.uv.new("UVMap")
        for f in bm.faces:
            ax = max(range(3), key=lambda i: abs(f.normal[i]))
            u_ax, v_ax = [i for i in range(3) if i != ax]
            if ax == 0:
                u_ax, v_ax = 1, 2
            elif ax == 1:
                u_ax, v_ax = 0, 2
            flip = f.normal[ax] < 0
            for l in f.loops:
                co = l.vert.co
                u = co[u_ax] / max(size[u_ax], 1e-9) + 0.5
                v = co[v_ax] / max(size[v_ax], 1e-9) + 0.5
                l[uvl].uv = ((1.0 - u) if (flip != (ax == 1)) else u, v)
        R = Matrix.Rotation(rotz, 4, 'Z') @ Matrix.Rotation(roty, 4, 'Y') @ Matrix.Rotation(rotx, 4, 'X')
        return self._obj(name, bm, Matrix.Translation(loc) @ R, bevel=bevel, props=props)

    def lathe(self, name, prof, seg=48, loc=(0, 0, 0), axis='Z', align=None, a0=0.0, a1=TAU, cap=True,
              solid=None, bevel=None, props=None):
        bm = bmesh.new()
        full = abs(a1 - a0) >= TAU - 1e-6
        n = seg if full else seg + 1
        rings = []
        for (r, z) in prof:
            ring = []
            for i in range(n):
                a = a0 + (a1 - a0) * i / seg
                ring.append(bm.verts.new((r * math.cos(a), r * math.sin(a), z)))
            rings.append(ring)
        for k in range(len(rings) - 1):
            (r1, z1), (r2, z2) = prof[k], prof[k + 1]
            sm = abs(z2 - z1) > 0.3 * abs(r2 - r1)
            for i in range(seg):
                j = (i + 1) % n if full else i + 1
                try:
                    f = bm.faces.new((rings[k][i], rings[k][j], rings[k + 1][j], rings[k + 1][i]))
                    f.smooth = sm
                except ValueError:
                    pass
        if full and cap:
            if prof[0][0] > 1e-6:
                bm.faces.new(rings[0])
            if prof[-1][0] > 1e-6:
                bm.faces.new(list(reversed(rings[-1])))
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        return self._obj(name, bm, self._place(loc, axis, align), bevel=bevel, solid=solid, props=props)

    def ring(self, name, r_out, r_in, h, loc=(0, 0, 0), axis='Z', align=None, seg=48, props=None, bevel=None):
        prof = [(r_in, -h / 2), (r_out, -h / 2), (r_out, h / 2), (r_in, h / 2), (r_in, -h / 2)]
        return self.lathe(name, prof, seg, loc, axis, align, cap=False, props=props, bevel=bevel)

    def torus(self, name, R, r, loc=(0, 0, 0), axis='Z', align=None, seg=48, rseg=12, props=None):
        prof = [(R + r * math.cos(t), r * math.sin(t)) for t in [i / rseg * TAU for i in range(rseg + 1)]]
        return self.lathe(name, prof, seg, loc, axis, align, cap=False, props=props)

    def bellows(self, name, r_in, r_out, z0, z1, folds=8, loc=(0, 0, 0), axis='Z', align=None, seg=48, props=None):
        prof = []
        n = folds * 2
        for i in range(n + 1):
            z = z0 + (z1 - z0) * i / n
            prof.append((r_out if i % 2 else r_in, z))
        return self.lathe(name, prof, seg, loc, axis, align, cap=False, props=props)

    def plate(self, name, pts, thick, loc=(0, 0, 0), plane='YZ', bevel=0.006, props=None):
        """Extrude a 2D outline. plane 'YZ' -> extrude along X, 'XZ' -> along Y, 'XY' -> along Z."""
        bm = bmesh.new()
        vs = []
        for (u, v) in pts:
            if plane == 'YZ':
                vs.append(bm.verts.new((-thick / 2, u, v)))
            elif plane == 'XZ':
                vs.append(bm.verts.new((u, -thick / 2, v)))
            else:
                vs.append(bm.verts.new((u, v, -thick / 2)))
        f = bm.faces.new(vs)
        nvec = {'YZ': (thick, 0, 0), 'XZ': (0, thick, 0), 'XY': (0, 0, thick)}[plane]
        ext = bmesh.ops.extrude_face_region(bm, geom=[f])
        bmesh.ops.translate(bm, vec=nvec, verts=[e for e in ext["geom"] if isinstance(e, bmesh.types.BMVert)])
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        return self._obj(name, bm, Matrix.Translation(loc), bevel=bevel, props=props)

    def bolts(self, name, positions, normal, r=0.012, h=0.01, props=None):
        """Hex bolt heads + washers merged into one mesh."""
        bm = bmesh.new()
        for i, p in enumerate(positions):
            nv = Vector(normal[i] if isinstance(normal, list) else normal).normalized()
            g = bmesh.ops.create_cone(bm, cap_ends=True, segments=6, radius1=r, radius2=r, depth=h)
            M = Matrix.Translation(Vector(p) + nv * h / 2) @ align_matrix(nv)
            bmesh.ops.transform(bm, matrix=M, verts=g["verts"])
            w = bmesh.ops.create_cone(bm, cap_ends=True, segments=12, radius1=r * 1.25, radius2=r * 1.25, depth=h * 0.25)
            M2 = Matrix.Translation(Vector(p) + nv * h * 0.12) @ align_matrix(nv)
            bmesh.ops.transform(bm, matrix=M2, verts=w["verts"])
        return self._obj(name, bm, Matrix.Identity(4), props=props)

    def bolt_circle(self, name, n, radius, z, axis='Z', r=0.012, h=0.01, center=(0, 0, 0), flip=False, phase=0.0):
        A = AXIS[axis]
        pts, nrm = [], []
        for i in range(n):
            a = phase + i / n * TAU
            p = A @ Vector((radius * math.cos(a), radius * math.sin(a), z))
            pts.append(Vector(center) + p)
            nrm.append(A.to_3x3() @ Vector((0, 0, -1 if flip else 1)))
        return self.bolts(name, pts, nrm, r, h)

    def cable(self, name, pts, r, res=10, props=None):
        cu = bpy.data.curves.new(name + "_tmp", 'CURVE')
        cu.dimensions = '3D'
        cu.bevel_depth = r
        cu.bevel_resolution = 2
        cu.resolution_u = res
        cu.use_fill_caps = True
        sp = cu.splines.new('BEZIER')
        sp.bezier_points.add(len(pts) - 1)
        for bp, p in zip(sp.bezier_points, pts):
            bp.co = p
            bp.handle_left_type = bp.handle_right_type = 'AUTO'
        tmp = bpy.data.objects.new(name + "_tmp", cu)
        self.col.objects.link(tmp)
        dg = bpy.context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg))
        bpy.data.objects.remove(tmp, do_unlink=True)
        bpy.data.curves.remove(cu)
        full = "%s_%s" % (self.prefix, name) if self.prefix else name
        me.name = full
        for p in me.polygons:
            p.use_smooth = True
        ob = bpy.data.objects.new(full, me)
        self.col.objects.link(ob)
        L = sum((Vector(pts[i + 1]) - Vector(pts[i])).length for i in range(len(pts) - 1))
        ob["lmsp_len"] = L
        for k, v in (props or {}).items():
            ob[k] = v
        self.parts.setdefault(self.bone, []).append(ob)
        self.all.append(ob)
        return ob

    def clamps(self, name, pts, r, normal=(0, 0, 1)):
        bm = bmesh.new()
        for p in pts:
            g = bmesh.ops.create_cone(bm, cap_ends=True, segments=16, radius1=r, radius2=r, depth=r * 0.9)
            bmesh.ops.transform(bm, matrix=Matrix.Translation(p) @ align_matrix(normal), verts=g["verts"])
        return self._obj(name, bm, Matrix.Identity(4))

    def light(self, name, kind, energy, color, loc, direction, spot=math.radians(60), size=0.05):
        ld = bpy.data.lights.new("%s_%s" % (self.prefix, name), kind)
        ld.energy = energy
        ld.color = color
        if kind == 'SPOT':
            ld.spot_size = spot
            ld.spot_blend = 0.5
        if kind == 'AREA':
            ld.size = size
        else:
            ld.shadow_soft_size = size
        ob = bpy.data.objects.new(ld.name, ld)
        self.col.objects.link(ob)
        ob.location = loc
        # lights shine along their local -Z
        ob.rotation_euler = Vector((0, 0, 1)).rotation_difference(-Vector(direction).normalized()).to_euler()
        self.parts.setdefault(self.bone, []).append(ob)
        self.all.append(ob)
        return ob

    def transform_since(self, start, M):
        """Apply matrix M to every mesh created since index `start` (used to place tools)."""
        for ob in self.all[start:]:
            if ob.type == 'MESH':
                ob.data.transform(M)
            else:
                ob.matrix_world = M @ ob.matrix_world


def parent_to_bone(ob, rig, bone):
    ob.parent = rig
    ob.parent_type = 'BONE'
    ob.parent_bone = bone
    pb = rig.pose.bones[bone]
    pm = rig.matrix_world @ pb.matrix @ Matrix.Translation((0, pb.bone.length, 0))
    ob.matrix_parent_inverse = pm.inverted()


def parent_kit(kit, rig):
    for bone, obs in kit.parts.items():
        if bone is None:
            continue
        for ob in obs:
            if ob.parent is None:
                parent_to_bone(ob, rig, bone)


def make_rig(name, coll_, bones):
    arm = bpy.data.armatures.new(name)
    rig = bpy.data.objects.new(name, arm)
    coll_.objects.link(rig)
    rig.show_in_front = True
    arm.display_type = 'OCTAHEDRAL'
    vl = bpy.context.view_layer
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for o in vl.objects:
        o.select_set(False)
    vl.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    for bn, head, tail, parent, connect in bones:
        eb = arm.edit_bones.new(bn)
        eb.head = head
        eb.tail = tail
        eb.roll = 0.0
        if parent:
            eb.parent = arm.edit_bones[parent]
            eb.use_connect = connect
    bpy.ops.object.mode_set(mode='OBJECT')
    for pb in rig.pose.bones:
        pb.rotation_mode = 'XYZ'
    return rig
