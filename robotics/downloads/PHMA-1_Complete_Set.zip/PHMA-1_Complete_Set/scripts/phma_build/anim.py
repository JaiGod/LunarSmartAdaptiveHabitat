"""Animation library: analytic arm solver + named actions for every robot (exported to GLB as clips)."""
import bpy, math
from mathutils import Vector, Matrix
from .arm import SH_Z, L_UPPER, L_FORE, L_WRIST

RAD = math.radians
JMAP = {"C": ("Carriage", "location", 1), "J1": ("J1_Turret_Yaw", "rotation_euler", 1),
        "J2": ("J2_Shoulder_Pitch", "rotation_euler", 0), "J3": ("J3_Boom_Roll", "rotation_euler", 1),
        "E1": ("E1_Telescope", "location", 1), "J4": ("J4_Elbow_Pitch", "rotation_euler", 0),
        "J5": ("J5_Wrist_Pitch", "rotation_euler", 0), "J6": ("J6_Wrist_Yaw", "rotation_euler", 2),
        "J7": ("J7_Wrist_Roll", "rotation_euler", 1)}
STOWED = dict(C=0.0, J1=0.0, J2=RAD(-30), J3=0.0, E1=0.0, J4=RAD(150), J5=RAD(60), J6=0.0, J7=0.0)


def _channelbag(action):
    try:
        from bpy_extras import anim_utils
        ad = action
        slot = action.slots[0] if len(action.slots) else None
        return anim_utils.action_get_channelbag_for_slot(action, slot) if slot else None
    except Exception:
        return None


def fcurves(action):
    cb = _channelbag(action)
    if cb is not None:
        return cb.fcurves
    return getattr(action, "fcurves", [])


def reset_pose(obj):
    if obj.type != 'ARMATURE':
        return
    for pb in obj.pose.bones:
        pb.location = (0, 0, 0)
        pb.rotation_euler = (0, 0, 0)
        pb.rotation_quaternion = (1, 0, 0, 0)
        pb.scale = (1, 1, 1)


def new_action(obj, name):
    if obj.animation_data is None:
        obj.animation_data_create()
    reset_pose(obj)
    old = bpy.data.actions.get(name)
    if old:
        bpy.data.actions.remove(old)
    obj.animation_data.action = None
    return name


def finish_action(obj, name, ease=True):
    act = obj.animation_data.action
    if act is None:
        return None
    act.name = name
    act.use_fake_user = True
    try:
        act.use_frame_range = True
        fr = act.frame_range
        act.frame_start, act.frame_end = fr[0], fr[1]
    except Exception:
        pass
    for fc in fcurves(act):
        for kp in fc.keyframe_points:
            kp.interpolation = 'BEZIER'
            kp.easing = 'AUTO'
            kp.handle_left_type = kp.handle_right_type = 'AUTO_CLAMPED'
    return act


def key_pose(rig, frame, pose):
    pb = rig.pose.bones
    for k, v in pose.items():
        bone, path, idx = JMAP[k]
        b = pb[bone]
        vec = getattr(b, path)
        vec[idx] = v
        b.keyframe_insert(path, index=idx, frame=frame, group=bone)


def full(p):
    q = dict(STOWED)
    q.update(p)
    return q


def solve(rig, target_world, tool_angle_deg, carriage=0.0, ext=0.0, tool_len=0.6, standoff=0.0, elbow_up=True,
          extra=None):
    """Planar IK. tool_angle: direction of the tool in the arm plane measured from straight up
    (90 = horizontal forward, 180 = straight down). Returns a full pose dict in radians."""
    t = rig.matrix_world.inverted() @ Vector(target_world)
    S = Vector((0.0, carriage, SH_Z))
    d = t - S
    psi = math.atan2(d.x, -d.y)
    r = math.hypot(d.x, d.y)
    th3 = math.radians(tool_angle_deg)
    reach = L_WRIST + tool_len + standoff
    wr = r - math.sin(th3) * reach
    wz = d.z - math.cos(th3) * reach
    L1, L2 = L_UPPER + ext, L_FORE
    D = math.hypot(wr, wz)
    D = max(abs(L1 - L2) + 1e-3, min(L1 + L2 - 1e-3, D))
    cb = (D * D - L1 * L1 - L2 * L2) / (2 * L1 * L2)
    beta = math.acos(max(-1.0, min(1.0, cb))) * (1 if elbow_up else -1)
    th1 = math.atan2(wr, wz) - math.atan2(L2 * math.sin(beta), L1 + L2 * math.cos(beta))
    gam = th3 - th1 - beta
    p = dict(C=carriage, J1=psi, J2=th1, J4=beta, J5=gam, E1=ext, J3=0.0, J6=0.0, J7=0.0)
    if extra:
        p.update(extra)
    return p


def unwrap_yaw(prev, cur):
    while cur - prev > math.pi:
        cur -= 2 * math.pi
    while cur - prev < -math.pi:
        cur += 2 * math.pi
    return cur


def keys(rig, seq):
    last = None
    for f, p in seq:
        p = full(p)
        if last is not None:
            p["J1"] = unwrap_yaw(last["J1"], p["J1"])
        key_pose(rig, f, p)
        last = p


# --------------------------------------------------------------------------- PHMA actions
def act_deploy(rig, toward_world):
    name = new_action(rig, "PHMA_Deploy")
    ready = solve(rig, toward_world, 90, ext=0.4)
    keys(rig, [(1, STOWED), (30, STOWED),
               (80, dict(J2=RAD(-8), J4=RAD(120), J5=RAD(60))),
               (130, dict(J2=RAD(5), J4=RAD(70), J5=RAD(40), J1=ready["J1"] * 0.6)),
               (190, dict(ready, E1=0.2)), (240, ready)])
    return finish_action(rig, name)


def act_stow(rig, from_pose):
    name = new_action(rig, "PHMA_Stow")
    keys(rig, [(1, from_pose), (60, dict(J2=RAD(5), J4=RAD(70), J5=RAD(40), J1=from_pose["J1"] * 0.5)),
               (120, dict(J2=RAD(-8), J4=RAD(120), J5=RAD(60))), (180, STOWED)])
    return finish_action(rig, name)


def act_idle_scan(rig, toward_world):
    name = new_action(rig, "PHMA_Idle_Scan")
    base = solve(rig, toward_world, 100, ext=0.2)
    seq = []
    for i, f in enumerate(range(1, 242, 40)):
        p = dict(base)
        p["J1"] = base["J1"] + RAD(14) * math.sin(i * 1.3)
        p["J5"] = base["J5"] + RAD(8) * math.cos(i * 1.7)
        p["J7"] = RAD(25) * math.sin(i * 0.9)
        seq.append((f, p))
    seq.append((241, base))
    keys(rig, seq)
    return finish_action(rig, name)


def girth_seam_point(phi_deg, cx=1.0, cy=-4.2, cz=3.2, R=2.515):
    a = math.radians(phi_deg)
    p = Vector((cx, cy - R * math.cos(a), cz + R * math.sin(a)))
    tool_angle = 90.0 + phi_deg     # tool points radially into the hull
    return p, tool_angle


def act_repair_weld(rig, carriage_local, approach=136, weld_len=376, name="PHMA_Repair_Weld", phi0=-25.0, phi1=45.0,
                    ext=0.3):
    """Laser girth weld along the expansion-module ring seam (south quadrant), driven by the solver."""
    nm = new_action(rig, name)
    p0, a0 = girth_seam_point(phi0)
    pre = solve(rig, p0, a0, carriage=carriage_local, standoff=0.35, ext=ext)
    seq = [(1, dict(pre, J2=pre["J2"] - RAD(15), J4=pre["J4"] + RAD(25))), (approach - 40, pre)]
    n = 16
    for i in range(n + 1):
        phi = phi0 + (phi1 - phi0) * i / n
        p, a = girth_seam_point(phi)
        q = solve(rig, p, a, carriage=carriage_local, standoff=0.03, ext=ext, extra={"J7": RAD(6) * math.sin(i)})
        seq.append((approach + int(weld_len * i / n), q))
    pe, ae = girth_seam_point(phi1)
    seq.append((approach + weld_len + 50, solve(rig, pe, ae, carriage=carriage_local, standoff=0.5, ext=ext)))
    keys(rig, seq)
    act = finish_action(rig, nm)
    act["weld_frames"] = [approach, approach + weld_len]
    return act


def breach_frame(breach, normal):
    n = Vector(normal).normalized()
    t1 = Vector((1, 0, 0))
    t2 = n.cross(t1).normalized()
    return n, t1, t2


def act_emergency(rig, home_c, breach_world, breach_normal, rack_local=(0.0, 1.18, 1.22), name="PHMA_Emergency_Response"):
    """Deploy -> 2 m/s dash along the track -> place pre-loaded patch -> tool change at own rack ->
    laser-seal the patch perimeter -> retract. Local frames (NLA strip offsets it in the movie)."""
    nm = new_action(rig, name)
    n, t1, t2 = breach_frame(breach_world, breach_normal)
    bw = Vector(breach_world)
    # where along the track is the breach?
    bl = rig.matrix_world.inverted() @ bw
    c_b = bl.y
    travel = abs(c_b - home_c)
    travel_frames = max(24, int(travel / 2.0 * 24))   # 2 m/s spec speed
    # tool angle in the arm plane: arm faces the breach horizontally, tool points along -n
    def tool_angle_for(target):
        tl = rig.matrix_world.inverted().to_3x3() @ (-n)
        S = Vector((0, c_b, SH_Z))
        dl = (rig.matrix_world.inverted() @ target) - S
        fwd = Vector((dl.x, dl.y, 0)).normalized()
        rr = tl.x * fwd.x + tl.y * fwd.y
        return math.degrees(math.atan2(rr, tl.z))
    ta = tool_angle_for(bw)
    transit = dict(STOWED, J2=RAD(5), J4=RAD(70), J5=RAD(40))
    approach = solve(rig, bw + n * 0.3, ta, carriage=c_b, tool_len=0.62, ext=0.5)
    press = solve(rig, bw, ta, carriage=c_b, tool_len=0.62, standoff=0.0, ext=0.5)
    rack = Vector(rack_local)
    rack_w = rig.matrix_world @ Vector((rack.x, c_b + rack.y, rack.z + 0.9))
    at_rack = solve(rig, rack_w, 180, carriage=c_b, tool_len=0.0, ext=0.0)
    at_rack["J1"] = unwrap_yaw(press["J1"], at_rack["J1"])
    seq = [(1, dict(STOWED, C=home_c)), (20, dict(STOWED, C=home_c)), (60, dict(transit, C=home_c)),
           (60 + travel_frames, dict(transit, C=c_b)), (216, approach), (250, press), (262, press),
           (300, dict(approach)), (330, at_rack), (560, at_rack), (624, solve(rig, bw + n * 0.25, ta, carriage=c_b,
                                                                                tool_len=0.6, ext=0.5))]
    m = 20
    for i in range(m + 1):
        a = i / m * math.tau
        p = bw + t1 * (math.cos(a) * 0.27) + t2 * (math.sin(a) * 0.27)
        seq.append((640 + int(360 * i / m), solve(rig, p, tool_angle_for(p), carriage=c_b, tool_len=0.6, standoff=0.03,
                                                  ext=0.5, extra={"J7": RAD(4) * math.sin(i)})))
    seq += [(1040, solve(rig, bw + n * 0.8, ta, carriage=c_b, tool_len=0.6, ext=0.5)),
            (1110, dict(transit, C=c_b))]
    keys(rig, seq)
    act = finish_action(rig, nm)
    act["press_frame"] = 250
    act["tool_change_frame"] = 330
    act["weld_frames"] = [640, 1000]
    return act


def act_maintenance_pump(rig, valve_world, sensor_world, name="PHMA_Maintenance_Pump"):
    """Interior arm: travel to the pump skid, turn the isolation valve, swap the flow sensor."""
    nm = new_action(rig, name)
    vl = rig.matrix_world.inverted() @ Vector(valve_world)
    sl = rig.matrix_world.inverted() @ Vector(sensor_world)
    cv, cs = vl.y - 1.2, sl.y - 1.2
    # the interior arm hangs inverted: rig "up" (tool angle 0) points at the floor
    above = solve(rig, valve_world, 0, carriage=cv, standoff=0.25, ext=0.3)
    grip = solve(rig, valve_world, 0, carriage=cv, standoff=0.02, ext=0.3)
    seq = [(1, STOWED), (40, dict(STOWED, C=0.0)), (110, dict(STOWED, C=cv)), (150, above), (175, grip)]
    for i, f in enumerate(range(185, 290, 15)):
        seq.append((f, dict(grip, J7=RAD(-90 * (i + 1)))))
    seq += [(300, dict(above, J7=RAD(-630))), (330, solve(rig, sensor_world, 70, carriage=cs, standoff=0.2, ext=0.3)),
            (360, solve(rig, sensor_world, 70, carriage=cs, standoff=0.01, ext=0.3)),
            (400, solve(rig, sensor_world, 70, carriage=cs, standoff=0.25, ext=0.3)), (460, dict(STOWED, C=cs))]
    keys(rig, seq)
    return finish_action(rig, nm)


# --------------------------------------------------------------------------- fleet actions
def _key_bone(rig, bone, path, idx, val, frame):
    b = rig.pose.bones[bone]
    getattr(b, path)[idx] = val
    b.keyframe_insert(path, index=idx, frame=frame, group=bone)


def act_rover_path(rig, waypoints, f0, f1, name, wheel_r=0.26, z=0.0, lift_blade=True):
    """Object-level drive along world waypoints with heading + wheel spin (one action)."""
    nm = new_action(rig, name)
    pts = [Vector((p[0], p[1], z)) for p in waypoints]
    L = [0.0]
    for i in range(1, len(pts)):
        L.append(L[-1] + (pts[i] - pts[i - 1]).length)
    total = L[-1]
    prev_h = None
    for i, p in enumerate(pts):
        f = f0 + (f1 - f0) * (L[i] / total if total else 0)
        d = (pts[min(i + 1, len(pts) - 1)] - pts[max(i - 1, 0)])
        h = math.atan2(-d.x, d.y)
        if prev_h is not None:
            h = unwrap_yaw(prev_h, h)
        prev_h = h
        rig.location = p
        rig.rotation_euler = (0, 0, h)
        rig.keyframe_insert("location", frame=f)
        rig.keyframe_insert("rotation_euler", index=2, frame=f)
        spin = L[i] / wheel_r
        for b in rig.pose.bones:
            if b.name.startswith("Wheel_"):
                _key_bone(rig, b.name, "rotation_euler", 1, -spin if b.name.endswith("L") else -spin, f)
        if "Mast_Pan" in rig.pose.bones:
            _key_bone(rig, "Mast_Pan", "rotation_euler", 1, RAD(18) * math.sin(i * 1.1), f)
        if lift_blade and "Blade_Pitch" in rig.pose.bones:
            _key_bone(rig, "Blade_Pitch", "rotation_euler", 0, RAD(-12), f)
    return finish_action(rig, nm)


def act_rover_traverse_local(rig, dist=6.0, frames=240, name="EVA3_Traverse", wheel_r=0.26):
    nm = new_action(rig, name)
    for f, y in ((1, 0.0), (frames, dist)):
        _key_bone(rig, "Root", "location", 1, y, f)
        for b in rig.pose.bones:
            if b.name.startswith("Wheel_"):
                _key_bone(rig, b.name, "rotation_euler", 1, -y / wheel_r, f)
    for f in (1, frames // 2, frames):
        _key_bone(rig, "Mast_Pan", "rotation_euler", 1, RAD(25) * math.sin(f / 40), f)
    return finish_action(rig, nm)


def act_rover_clean(rig, name="EVA3_SolarPanelClean"):
    nm = new_action(rig, name)
    for i, f in enumerate(range(1, 242, 30)):
        s = math.sin(i * 0.8)
        _key_bone(rig, "Arm_Base_Yaw", "rotation_euler", 1, RAD(35) * s, f)
        _key_bone(rig, "Arm_Shoulder", "rotation_euler", 0, RAD(-20 - 15 * abs(s)), f)
        _key_bone(rig, "Arm_Elbow", "rotation_euler", 0, RAD(35), f)
        _key_bone(rig, "Arm_Wrist", "rotation_euler", 0, RAD(-10 + 8 * s), f)
        _key_bone(rig, "Mast_Tilt", "rotation_euler", 0, RAD(-15), f)
    return finish_action(rig, nm)


def act_rover_doze(rig, name="EVA3_RegolithMove", wheel_r=0.26):
    nm = new_action(rig, name)
    for f, y, bl in ((1, 0.0, -0.05), (60, 0.0, 0.18), (180, 3.0, 0.18), (220, 3.0, -0.15), (300, 1.0, -0.15)):
        _key_bone(rig, "Root", "location", 1, y, f)
        _key_bone(rig, "Blade_Pitch", "rotation_euler", 0, bl, f)
        for b in rig.pose.bones:
            if b.name.startswith("Wheel_"):
                _key_bone(rig, b.name, "rotation_euler", 1, -y / wheel_r, f)
    return finish_action(rig, nm)


def act_micro_pipe(rig, dist, f0, f1, name, wheel_r=0.028, local=False):
    nm = new_action(rig, name)
    if local:
        for f, y in ((f0, 0.0), (f1, dist)):
            _key_bone(rig, "Root", "location", 1, y, f)
            for b in rig.pose.bones:
                if b.name.startswith("Wheel_"):
                    _key_bone(rig, b.name, "rotation_euler", 1, y / wheel_r, f)
    else:
        start = rig.location.copy()
        fwd = rig.matrix_world.to_3x3() @ Vector((0, 1, 0))
        for f, y in ((f0, 0.0), (f1, dist)):
            rig.location = start + fwd * y
            rig.keyframe_insert("location", frame=f)
            for b in rig.pose.bones:
                if b.name.startswith("Wheel_"):
                    _key_bone(rig, b.name, "rotation_euler", 1, y / wheel_r, f)
        rig.location = start
    for i, f in enumerate(range(int(f0), int(f1) + 1, max(1, int((f1 - f0) / 6)))):
        if "Cam_Tilt" in rig.pose.bones:
            _key_bone(rig, "Cam_Tilt", "rotation_euler", 0, RAD(10) * math.sin(i * 1.4), f)
    return finish_action(rig, nm)


def push_nla(obj, action, start, track="Movie", extrap='HOLD'):
    ad = obj.animation_data or obj.animation_data_create()
    tr = ad.nla_tracks.get(track) or ad.nla_tracks.new()
    tr.name = track
    st = tr.strips.new(action.name, int(start), action)
    try:
        st.action_slot = action.slots[0]
    except Exception:
        pass
    st.extrapolation = extrap
    st.blend_type = 'REPLACE'
    return st


def assign_action(obj, action):
    ad = obj.animation_data or obj.animation_data_create()
    ad.action = action
    try:
        ad.action_slot = action.slots[0]
    except Exception:
        pass
