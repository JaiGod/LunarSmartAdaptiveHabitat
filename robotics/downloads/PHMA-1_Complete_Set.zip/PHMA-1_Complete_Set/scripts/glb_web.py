"""Shrink a GLB for the web: re-encode embedded textures as JPEG (PNG kept where alpha is used)
and cap their size. Geometry, rig, skins and animation clips are copied byte-for-byte.

usage: python glb_web.py in.glb out.glb [max_px=512] [jpeg_quality=82] [clip_prefix,...]
max_px 0 keeps texture size (lossless PNG re-pack is skipped; images are still JPEG-encoded unless alpha).
"""
import io, json, struct, sys
from PIL import Image


def read_glb(path):
    data = open(path, "rb").read()
    magic, ver, length = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB"
    off, js, binc = 12, None, b""
    while off < length:
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            binc = chunk
        off += 8 + clen
    return js, binc


def write_glb(path, js, binc):
    j = json.dumps(js, separators=(",", ":")).encode("utf-8")
    j += b" " * ((4 - len(j) % 4) % 4)
    binc += b"\0" * ((4 - len(binc) % 4) % 4)
    total = 12 + 8 + len(j) + (8 + len(binc) if binc else 0)
    with open(path, "wb") as f:
        f.write(struct.pack("<III", 0x46546C67, 2, total))
        f.write(struct.pack("<II", len(j), 0x4E4F534A) + j)
        if binc:
            f.write(struct.pack("<II", len(binc), 0x004E4942) + binc)


def alpha_images(js):
    """Indices of images feeding a baseColor texture on a non-opaque material."""
    out = set()
    for m in js.get("materials", []):
        if m.get("alphaMode", "OPAQUE") == "OPAQUE":
            continue
        t = m.get("pbrMetallicRoughness", {}).get("baseColorTexture")
        if t is not None:
            src = js["textures"][t["index"]].get("source")
            if src is not None:
                out.add(src)
    return out


def prune_animations(js, prefixes):
    """Keep only clips for this robot (name prefix) and drop duplicate exports of the same clip."""
    best = {}
    for a in js.get("animations", []):
        if prefixes and not a.get("name", "").startswith(tuple(prefixes)):
            continue
        n = a.get("name", "")
        if n not in best or len(a["channels"]) > len(best[n]["channels"]):
            best[n] = a
    js["animations"] = sorted(best.values(), key=lambda a: a["name"])
    if not js["animations"]:
        js.pop("animations")


def _walk_tex(obj, fn):
    """Call fn on every textureInfo dict ({"index": n, ...}) inside a material."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict) and k.endswith("Texture") and "index" in v:
                fn(v)
            _walk_tex(v, fn)
    elif isinstance(obj, list):
        for v in obj:
            _walk_tex(v, fn)


def keep_default_scene(js):
    """Blender 5.2 writes every scene that holds a selected object; keep only the default scene
    and drop the nodes, meshes, materials, textures and images only the other scenes used."""
    si = js.get("scene", 0)
    scenes = js.get("scenes", [])
    if len(scenes) <= 1:
        return
    N = js["nodes"]
    keep, stack = set(), list(scenes[si]["nodes"])
    while stack:
        i = stack.pop()
        if i in keep:
            continue
        keep.add(i)
        stack += N[i].get("children", [])
    for sk in js.get("skins", []):
        if any(j in keep for j in sk["joints"]):
            keep.update(sk["joints"])
    nmap = {o: n for n, o in enumerate(sorted(keep))}
    new_nodes = []
    for o in sorted(keep):
        nd = N[o]
        if "children" in nd:
            nd["children"] = [nmap[c] for c in nd["children"] if c in nmap]
            if not nd["children"]:
                nd.pop("children")
        new_nodes.append(nd)
    js["nodes"] = new_nodes
    js["scenes"] = [{**scenes[si], "nodes": [nmap[r] for r in scenes[si]["nodes"]]}]
    js["scene"] = 0
    # skins
    sk_keep = [k for k, sk in enumerate(js.get("skins", [])) if all(j in nmap for j in sk["joints"])]
    skmap = {o: n for n, o in enumerate(sk_keep)}
    if "skins" in js:
        js["skins"] = [js["skins"][k] for k in sk_keep]
        for sk in js["skins"]:
            sk["joints"] = [nmap[j] for j in sk["joints"]]
            if "skeleton" in sk:
                sk["skeleton"] = nmap[sk["skeleton"]]
        if not js["skins"]:
            js.pop("skins")
    for nd in js["nodes"]:
        if "skin" in nd:
            nd["skin"] = skmap[nd["skin"]]
    # animations: the exporter may bind a clip to a linked-duplicate rig in the other scene;
    # bones share names, so move such channels onto the kept node of the same name
    by_name = {}
    for o in sorted(keep):
        by_name.setdefault(N[o].get("name"), []).append(o)
    for a in js.get("animations", []):
        for c in a["channels"]:
            t = c["target"].get("node")
            if t is not None and t not in nmap:
                cand = by_name.get(N[t].get("name"), [])
                if len(cand) == 1:
                    c["target"]["node"] = cand[0]
    anims = []
    for a in js.get("animations", []):
        seen, ch = set(), []
        for c in a["channels"]:
            key = (c["target"].get("node"), c["target"].get("path"))
            if c["target"].get("node") in nmap and key not in seen:
                seen.add(key)
                ch.append(c)
        if not ch:
            continue
        used = sorted({c["sampler"] for c in ch})
        smap = {o: n for n, o in enumerate(used)}
        for c in ch:
            c["target"]["node"] = nmap[c["target"]["node"]]
            c["sampler"] = smap[c["sampler"]]
        a["channels"], a["samplers"] = ch, [a["samplers"][k] for k in used]
        anims.append(a)
    if "animations" in js:
        js["animations"] = anims
        if not anims:
            js.pop("animations")
    # meshes -> materials -> textures -> images/samplers
    m_used = sorted({nd["mesh"] for nd in js["nodes"] if "mesh" in nd})
    mmap = {o: n for n, o in enumerate(m_used)}
    js["meshes"] = [js["meshes"][k] for k in m_used]
    for nd in js["nodes"]:
        if "mesh" in nd:
            nd["mesh"] = mmap[nd["mesh"]]
    mat_used = sorted({p["material"] for m in js["meshes"] for p in m["primitives"] if "material" in p})
    matmap = {o: n for n, o in enumerate(mat_used)}
    if "materials" in js:
        js["materials"] = [js["materials"][k] for k in mat_used]
        for m in js["meshes"]:
            for p in m["primitives"]:
                if "material" in p:
                    p["material"] = matmap[p["material"]]
    tex_used = set()
    _walk_tex(js.get("materials", []), lambda t: tex_used.add(t["index"]))
    tex_used = sorted(tex_used)
    tmap = {o: n for n, o in enumerate(tex_used)}
    if "textures" in js:
        js["textures"] = [js["textures"][k] for k in tex_used]
        _walk_tex(js.get("materials", []), lambda t: t.__setitem__("index", tmap[t["index"]]))
        img_used = sorted({t["source"] for t in js["textures"] if "source" in t})
        imap = {o: n for n, o in enumerate(img_used)}
        js["images"] = [js["images"][k] for k in img_used]
        smp_used = sorted({t["sampler"] for t in js["textures"] if "sampler" in t})
        spmap = {o: n for n, o in enumerate(smp_used)}
        if "samplers" in js:
            js["samplers"] = [js["samplers"][k] for k in smp_used]
        for t in js["textures"]:
            if "source" in t:
                t["source"] = imap[t["source"]]
            if "sampler" in t:
                t["sampler"] = spmap[t["sampler"]]
        for k in ("textures", "images", "samplers"):
            if k in js and not js[k]:
                js.pop(k)


def compact(js):
    """Drop accessors and bufferViews nothing references any more (after pruning clips)."""
    used = set()
    for m in js.get("meshes", []):
        for p in m["primitives"]:
            used.update(p.get("attributes", {}).values())
            if "indices" in p:
                used.add(p["indices"])
            for t in p.get("targets", []):
                used.update(t.values())
    for sk in js.get("skins", []):
        if "inverseBindMatrices" in sk:
            used.add(sk["inverseBindMatrices"])
    for a in js.get("animations", []):
        for smp in a["samplers"]:
            used.update((smp["input"], smp["output"]))
    acc_map, accs = {}, []
    for i, ac in enumerate(js.get("accessors", [])):
        if i in used:
            acc_map[i] = len(accs)
            accs.append(ac)
    js["accessors"] = accs
    for m in js.get("meshes", []):
        for p in m["primitives"]:
            p["attributes"] = {k: acc_map[v] for k, v in p.get("attributes", {}).items()}
            if "indices" in p:
                p["indices"] = acc_map[p["indices"]]
            if "targets" in p:
                p["targets"] = [{k: acc_map[v] for k, v in t.items()} for t in p["targets"]]
    for sk in js.get("skins", []):
        if "inverseBindMatrices" in sk:
            sk["inverseBindMatrices"] = acc_map[sk["inverseBindMatrices"]]
    for a in js.get("animations", []):
        for smp in a["samplers"]:
            smp["input"], smp["output"] = acc_map[smp["input"]], acc_map[smp["output"]]
    bv_used = {ac["bufferView"] for ac in accs if "bufferView" in ac}
    bv_used |= {im["bufferView"] for im in js.get("images", []) if "bufferView" in im}
    for ac in accs:
        sp = ac.get("sparse")
        if sp:
            bv_used |= {sp["indices"]["bufferView"], sp["values"]["bufferView"]}
    return bv_used


def shrink(src, dst, max_px=512, q=82, prefixes=None):
    js, binc = read_glb(src)
    keep_default_scene(js)
    if prefixes is not None:
        prune_animations(js, prefixes)
    bv_used = compact(js)
    keep_alpha = alpha_images(js) if js.get("textures") else set()
    views = js.get("bufferViews", [])
    new_payload = {}
    for i, img in enumerate(js.get("images", [])):
        if "bufferView" not in img:
            continue
        bv = views[img["bufferView"]]
        raw = binc[bv.get("byteOffset", 0): bv.get("byteOffset", 0) + bv["byteLength"]]
        im = Image.open(io.BytesIO(raw))
        im.load()
        if max_px and max(im.size) > max_px:
            s = max_px / max(im.size)
            im = im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.LANCZOS)
        buf = io.BytesIO()
        if i in keep_alpha and im.mode in ("RGBA", "LA", "P"):
            im.save(buf, "PNG", optimize=True)
            img["mimeType"] = "image/png"
        else:
            im.convert("RGB").save(buf, "JPEG", quality=q, optimize=True, progressive=False)
            img["mimeType"] = "image/jpeg"
        new_payload[img["bufferView"]] = buf.getvalue()
    # rebuild the binary chunk: only referenced views, 4-byte aligned, indices remapped
    out, bv_map, new_views = bytearray(), {}, []
    for vi, bv in enumerate(views):
        if vi not in bv_used:
            continue
        start = bv.get("byteOffset", 0)
        payload = new_payload.get(vi, binc[start: start + bv["byteLength"]])
        while len(out) % 4:
            out += b"\0"
        bv["byteOffset"] = len(out)
        bv["byteLength"] = len(payload)
        out += payload
        bv_map[vi] = len(new_views)
        new_views.append(bv)
    js["bufferViews"] = new_views
    for ac in js.get("accessors", []):
        if "bufferView" in ac:
            ac["bufferView"] = bv_map[ac["bufferView"]]
        sp = ac.get("sparse")
        if sp:
            sp["indices"]["bufferView"] = bv_map[sp["indices"]["bufferView"]]
            sp["values"]["bufferView"] = bv_map[sp["values"]["bufferView"]]
    for im in js.get("images", []):
        if "bufferView" in im:
            im["bufferView"] = bv_map[im["bufferView"]]
    js["buffers"][0]["byteLength"] = len(out)
    write_glb(dst, js, bytes(out))
    return len(binc), len(out)


if __name__ == "__main__":
    a = sys.argv[1:]
    print(shrink(a[0], a[1], int(a[2]) if len(a) > 2 else 512, int(a[3]) if len(a) > 3 else 82,
                 a[4].split(",") if len(a) > 4 else None))
