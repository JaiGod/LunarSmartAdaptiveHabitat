"""Background still render: blender -b file.blend --python render_job.py -- <scene> <frame> <samples> <resx> <resy> <out.png> [camera] [age]"""
import bpy, sys, os
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "addon"))
try:
    import lunar_material_studio_pro as L
    L.register()
except Exception as e:
    print("addon", e)
a = sys.argv[sys.argv.index("--") + 1:]
scene = bpy.data.scenes[a[0]]
frame, samples, rx, ry, outp = int(a[1]), int(a[2]), int(a[3]), int(a[4]), a[5]
cam = a[6] if len(a) > 6 and a[6] != "-" else None
age = float(a[7]) if len(a) > 7 else None
main = bpy.data.scenes.get("LSAH_Robotics")
if age is not None and main:
    main["lmsp_mission_age"] = age
if cam:
    scene.camera = bpy.data.objects[cam]
scene.render.engine = 'CYCLES'
try:
    prefs = bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type = 'OPTIX'
    prefs.refresh_devices()
    for d in prefs.devices:
        d.use = d.type == 'OPTIX'
    scene.cycles.device = 'GPU'
except Exception as e:
    print("gpu", e)
scene.cycles.samples = samples
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True
scene.render.resolution_x, scene.render.resolution_y = rx, ry
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = outp
scene.frame_set(frame)

bpy.ops.render.render(write_still=True, scene=scene.name)
print("RENDER_DONE", outp, flush=True)
