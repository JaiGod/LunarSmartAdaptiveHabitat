"""Background GLB export: blender -b PHMA-1_Robotic_Maintenance_Fleet.blend --python export_job.py -- <outdir> [quick]"""
import bpy, sys, os, json, time, traceback
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "addon"))
import lunar_material_studio_pro as L
L.register()
argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
out = argv[0] if argv else os.path.join(ROOT, "exports_glb")
quick = "quick" in argv
os.makedirs(out, exist_ok=True)
sc = bpy.data.scenes["LSAH_Robotics"]
log = []


def clips(rig, prefixes):
    ad = rig.animation_data or rig.animation_data_create()
    ad.action = None
    for t in list(ad.nla_tracks):
        ad.nla_tracks.remove(t)
    names = [a.name for a in bpy.data.actions if a.name.startswith(prefixes) and "Emergency_Drive" not in a.name
             and "Emergency_PipeRun" not in a.name and "Emergency_Crawl" not in a.name]
    for n in names:
        a = bpy.data.actions[n]
        tr = ad.nla_tracks.new()
        tr.name = n
        st = tr.strips.new(n, 1, a)
        try:
            st.action_slot = a.slots[0]
        except Exception:
            pass
        tr.mute = True
    return names


JOBS = [
    ("PHMA1_Exterior", ["PHMA1_Exterior"], "RIG_PHMA1_EXT", ("PHMA_",), 1024, None),
    ("PHMA1_Interior", ["PHMA1_Interior"], "RIG_PHMA1_INT", ("PHMA_",), 1024, None),
    ("MMR2A_PipeCrawler", ["MMR_MicroRobots"], "RIG_MMR2A", ("MMR2A_",), 512, None),
    ("MMR2B_SurfaceCrawler", ["MMR_MicroRobots"], "RIG_MMR2B", ("MMR2B_",), 512, None),
    ("EVA3_ExteriorRobot", ["EVA_ExteriorRobots"], "RIG_EVA3_A", ("EVA3_",), 1024, None),
    ("PHMA1_Exterior_LOD1", ["PHMA1_Exterior"], "RIG_PHMA1_EXT", ("PHMA_",), 512, 0.35),
]
for name, cols, rig_name, pre, res, lod in JOBS:
    t0 = time.time()
    try:
        rig = bpy.data.objects.get(rig_name) if rig_name else None
        cl = clips(rig, pre) if rig else []
        r = L.pipeline.export_glb(name, cols, [rig] if rig else [], os.path.join(out, name + ".glb"),
                                  bake=not quick, max_res=res if not quick else 256, lod_ratio=lod, log=log)
        r["clips"] = cl
        log.append(r)
    except Exception:
        log.append({"job": name, "err": traceback.format_exc()[-1500:]})
    print("EXPORT", name, round(time.time() - t0, 1), flush=True)
# ---- each tool head as its own GLB, coupling face at the origin (+Y up in glTF)
from mathutils import Matrix, Vector
lib = bpy.data.collections.get("PHMA_ToolHeads")
for i, key in enumerate(sorted({o.get("lmsp_tool") for o in (lib.all_objects if lib else []) if o.get("lmsp_tool")})):
    t0 = time.time()
    try:
        objs = [o for o in lib.all_objects if o.get("lmsp_tool") == key and o.type == "MESH" and not o.get("lmsp_weld_glow")]
        off = Vector((-30.6 + i * 0.75, 2.5, 0.89))
        for o in objs:
            o.data.transform(Matrix.Translation(-off))
        r = L.pipeline.export_glb(key, [], [], os.path.join(out, "tools", key + ".glb"), bake=not quick,
                                  max_res=512 if not quick else 256, extra_objects=objs, log=log)
        for o in objs:
            o.data.transform(Matrix.Translation(off))
        r["tool"] = key
        log.append(r)
    except Exception:
        log.append({"job": key, "err": traceback.format_exc()[-1500:]})
    print("EXPORT", key, round(time.time() - t0, 1), flush=True)
json.dump(log, open(os.path.join(out, "export_log.json"), "w"), indent=1, default=str)
print("EXPORT_DONE", flush=True)
