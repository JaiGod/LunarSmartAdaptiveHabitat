"""Background render queue: blender -b file.blend --python render_queue.py -- <queue.json>
queue.json: [{"scene":..., "frame":..., "samples":..., "res":[x,y], "out":..., "camera":optional, "age":optional}]"""
import bpy, sys, os, json, time
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "addon"))
try:
    import lunar_material_studio_pro as L
    L.register()
except Exception as e:
    print("addon", e)
q = json.load(open(sys.argv[sys.argv.index("--") + 1]))
try:
    prefs = bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type = 'OPTIX'
    prefs.refresh_devices()
    for d in prefs.devices:
        d.use = d.type == 'OPTIX'
except Exception as e:
    print("gpu", e)
main = bpy.data.scenes.get("LSAH_Robotics")
for job in q:
    t0 = time.time()
    sc = bpy.data.scenes[job["scene"]]
    if "age" in job and main:
        main["lmsp_mission_age"] = float(job["age"])
    sc.render.engine = 'CYCLES'
    sc.cycles.device = 'GPU'
    sc.cycles.samples = job["samples"]
    sc.cycles.use_adaptive_sampling = True
    sc.render.use_persistent_data = False
    sc.cycles.use_denoising = True
    sc.render.resolution_x, sc.render.resolution_y = job["res"]
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = 'PNG'
    sc.render.filepath = job["out"]
    sc.frame_set(job["frame"])
    if job.get("camera"):
        sc.camera = bpy.data.objects[job["camera"]]
    bpy.ops.render.render(write_still=True, scene=sc.name)
    print("RENDERED", job["out"], round(time.time() - t0, 1), flush=True)
print("QUEUE_DONE", flush=True)
