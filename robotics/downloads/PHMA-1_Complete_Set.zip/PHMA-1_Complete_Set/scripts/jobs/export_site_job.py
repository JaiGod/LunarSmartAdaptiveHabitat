"""Whole-site GLBs: blender -b PHMA-1_Robotic_Maintenance_Fleet.blend --python export_site_job.py -- <outdir>"""
import bpy, sys, os, json, time, traceback
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "addon"))
import lunar_material_studio_pro as L
L.register()
argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
out = argv[0] if argv else os.path.join(ROOT, "exports_glb")
os.makedirs(out, exist_ok=True)
sc = bpy.data.scenes["LSAH_Robotics"]
bpy.context.window.scene = sc if bpy.context.window else sc
sc.frame_set(1)
log = []
JOBS = [
    ("LSAH_Exterior_Site", ["ENV_Environment", "LSAH_Habitat_Exterior", "LSAH_Track_System", "PHMA1_Exterior", "EVA_ExteriorRobots"],
     ["RIG_PHMA1_EXT", "RIG_EVA3_A", "RIG_EVA3_B", "RIG_EVA3_C"]),
    ("LSAH_Interior_Module", ["LSAH_Habitat_Interior", "PHMA1_Interior", "MMR_MicroRobots"],
     ["RIG_PHMA1_INT", "RIG_MMR2A", "RIG_MMR2B"]),
]
for name, cols, rigs in JOBS:
    t0 = time.time()
    try:
        rr = [bpy.data.objects[r] for r in rigs if r in bpy.data.objects]
        for r in rr:
            if r.animation_data:
                r.animation_data.action = None
                for t in list(r.animation_data.nla_tracks):
                    r.animation_data.nla_tracks.remove(t)
        res = L.pipeline.export_glb(name, cols, rr, os.path.join(out, name + ".glb"), bake=False, max_res=256, log=log)
        log.append(res)
    except Exception:
        log.append({"job": name, "err": traceback.format_exc()[-1500:]})
    print("EXPORT", name, round(time.time() - t0, 1), flush=True)
json.dump(log, open(os.path.join(out, "export_site_log.json"), "w"), indent=1, default=str)
print("EXPORT_DONE", flush=True)
