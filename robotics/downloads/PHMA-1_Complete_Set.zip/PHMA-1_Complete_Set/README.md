# PHMA-1 Robotic Maintenance Fleet — Lunar Smart Adaptive Habitat

**NASA HUNCH · Jaineil R.** (small credit: Angel C., Farhan K.)

A rigged, animated Blender robot fleet that maintains the Lunar Smart Adaptive Habitat, plus **Lunar Material Studio Pro**, a Blender add-on that generates and manages every material procedurally.

Everything here is new. It was built in a blank file, and no earlier habitat file was opened or changed.

## Folder layout
| Path | What it is |
|---|---|
| `PHMA-1_Robotic_Maintenance_Fleet.blend` | The project file. Scenes: `LSAH_Robotics` (emergency sequence) and `LSAH_Hero_LunarSunrise` |
| `addon/lunar_material_studio_pro/` | The material pipeline add-on. Zip this folder to install it (Edit ▸ Preferences ▸ Add-ons ▸ Install) |
| `scripts/phma_build/` | The scripts that build the whole project from an empty file |
| `scripts/jobs/` | Background render and GLB-export jobs |
| `exports_glb/` | Game-ready GLBs with baked PBR textures and animation clips. Tool heads are in `exports_glb/tools/` |
| `renders/` | Stills and sequence frames |
| `website/` | Three.js viewer for GitHub Pages (`website/models/` holds the GLBs) |

## Rebuild from an empty file
In Blender 4.2 or later (tested target: 5.2 LTS), open the Scripting tab in a **new empty file** and run:
```python
import sys; sys.path.insert(0, r"<this folder>\scripts")
from phma_build import run; run.build_all()
```

## The fleet
### Type 1: PHMA-1 Primary Habitat Engineering Arm (exterior) and PHMA-1i (interior)
| | |
|---|---|
| Reach | 8.5 m, including a telescoping boom that extends 1.0 m |
| Stowed / retracted | 3.2 m class "Z-fold" parking pose |
| Base | 1.8 m slewing ring with 48 bolts and a dust bellows |
| Lift | 2,500 kg in lunar gravity (shoulder hydraulic assist). Precision handling 0.1–100 kg |
| Mass | 1,450 kg |
| Axes | J1 turret yaw (continuous through a slip ring), J2 shoulder ±180°, J3 boom roll ±180°, E1 telescope 0–1 m, J4 elbow ±160°, J5 wrist pitch ±180°, J6 wrist yaw ±180°, J7 wrist roll ±270° |
| Rig | `RIG_PHMA1_EXT` / `RIG_PHMA1_INT`. Locked axes, limit constraints, Damped-Track hydraulic pistons, and an IK chain to `IK_Target` (set its influence to 1 for IK posing) |
| Track | 121.7 m loop with 0.75 m gauge. Hardened titanium I-rail on pylons, a covered 120 VDC bus bar, an absolute position encoder strip, and anti-derail capture wheels so the same carriage also works wall- or ceiling-mounted. Top speed 2 m/s |
| Materials | Ti-6Al-4V frame (~60% of structure), CFRP booms, aluminised-Kapton / Mylar MLI, OSR radiators, ceramic hybrid bearings, Kevlar-sleeved harnesses |
| Dust | Bellows on every joint, wiper seal on the telescope, sealed bearings, skirts on the bogies, and EDS grids. The dock straddles the track with EDS curtains and brushes |
| Safety | E-stop, keyed manual override panel and T-pull handle, EVA-yellow handrails, hazard and pinch-point labels |

**Interchangeable tools** all use one quick-change coupling with 3 alignment pins and a latch ring:
TL01 precision gripper (0.6 × 0.3 m) · TL02 smart welder (3.5 kW fibre laser + arc torch) · TL03 hydraulic cutter (0.8 m, 120 kN) · TL04 core drill · TL05 inspection camera with snake probe · TL06 radiation scanner (25 m: CZT gamma, He-3 neutron, particle flux) · TL07 leak detector (ultrasonic array, LWIR camera, mass-spec sniffer) · TL08 cargo manipulator (3-wire snare latching end effector for grapple fixtures).

### Type 2: Micro maintenance robots
- **MMR-2A in-pipe crawler.** Three spring-loaded wheel legs, so it climbs pipes without needing magnets. It carries a camera, ultrasonic wall-thickness and acoustic leak sensors, and inspects the transparent water network.
- **MMR-2B surface crawler.** Magnetic wheels for ferritic steel, plus an electroadhesive pad because the habitat is mostly non-magnetic aluminium and titanium. It carries an eddy-current array and a thermal camera for electrical diagnostics.

### Type 3: EVA-3 exterior robot
Rocker-bogie chassis, 6 titanium chevron wheels **with fenders** (Apollo 17 lesson), and a 4-DOF arm with an electrodynamic dust-shield (EDS) wand and brush for solar arrays. It also carries a regolith dozer blade, a gamma/neutron pod for shielding inspection, a stereo mast with LIDAR, and a high-gain antenna.

## Habitat integration
The arm and robots service the water pumping centre (pumps, valves, manifold), transparent water pipes, aquaponics tank and grow bed, hydroponic racks, the storm-shelter water walls and regolith-block shielding, solar arrays, LUNA AI server rack, crew-monitoring sensors and console, medical bay, EVA airlock (suitports, EDS porch), the self-cleaning PHMA dock, and a cargo pallet with a grapple fixture.

## Realism choices (deliberate)
- **No orange sunrise.** The Moon has no atmosphere, so sunlight stays white (5600 K) and the sky stays black. The sun disc is 0.53° (the true value).
- **Stars are camera-only.** They don't light anything, and they disappear in sunlit exposures as in real photos.
- **Earth is its true size (~1.9°).** The hero shot uses a 300 mm lens from 270 m away, the same telephoto trick that makes Earth look huge behind the arm. At lunar night Earth is nearly full, so earthshine is the fill light.
- **Lunar gravity** (−1.62 m/s²) drives the weld sparks, debris, and the venting ice plume from the breach.
- **Laser welding works in vacuum.** Arc welding is only for pressurised interiors.
- **Dust in the hero shot** is lofted and kicked up. There is no volumetric haze, because there is no air to hold any.

## Lunar Material Studio Pro (add-on)
Find it in the 3D Viewport sidebar under the **Lunar MSP** tab. The panel is called **Lunar Habitat Material Control Center**.
- **AUTO CONFIGURE ASSETS** builds the library, assigns materials from object names, collections and custom properties, applies dust and wear tags, and validates the scene.
- **Material library.** 52 procedural PBR node trees with your spec values. Examples: titanium (anisotropic, brushed, machining rings), CFRP 2×2 twill with per-tow anisotropy, AR-coated optics, quilted MLI, chrome hydraulics with oil and seal wear, regolith dust, LED states, worn paint, hazard stripes, micrometeorite damage, procedural weld beads and heat tint.
- **One weathering engine.** The `LMSP_Weathering` node group is driven by the **Mission Age slider (0–20 yr)**. It controls up-facing (>20°) and crevice dust, edge wear, scratches, heat discoloration, and micrometeorite pitting (85% small / 14% medium / 1% major; exterior parts only). It changes shading only, never topology. Per-object overrides: `lmsp_dust`, `lmsp_wear`, `lmsp_exterior`, `lmsp_age_ovr`.
- **Decals.** Warning labels, asset IDs, serials, inspection and maintenance stickers, QR-style ID tags and docking targets, drawn into images by a built-in font.
- **Tools.** Material browser with thumbnails and status, preview geometry, highlight overlays, texture diagnostics, validation report, Cycles quality analyzer, asset inspector, NEW / 1 / 5 / 10 year comparison, lighting presets, render presets (Quick → Hero 4K 2.39:1), movie-shot cameras, LOD generation, and **baked game-ready GLB export** (parts merged per bone and material, base / ORM / normal maps).

The QR tags are scannable-looking patterns. They do not encode real data yet.

## Movie scenes
- **`LSAH_Robotics`, "Micrometeorite at lunar night"** (1–1440 frames, 24 fps). Camera cuts are set by timeline markers:
  1 impact · 2 sensors · 3 LUNA AI · 4 PHMA-1 deploys · 5 EVA robots converge · 6 pipe robot · 7 crew monitoring · 8–9 automatic laser repair · 10 the colony survives.
- **`LSAH_Hero_LunarSunrise`** (900–1340 frames). PHMA-1 laser-welds the expansion module's girth seam at sunrise, silhouetted against Earth, with floating dust.
